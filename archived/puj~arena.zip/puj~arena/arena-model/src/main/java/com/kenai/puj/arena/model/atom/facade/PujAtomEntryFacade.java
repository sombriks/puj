package com.kenai.puj.arena.model.atom.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.atom.EntryType;

@Local
public interface PujAtomEntryFacade extends PujAtomFacade<EntryType> {
}