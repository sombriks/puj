package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity.CompetitionStatus;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;

@Stateless
public class PujCompetitionFacadeImpl extends
		CRUDEntityFacade<PujCompetitionEntity> implements PujCompetitionFacade {
	@Override
	public Collection<PujCompetitionEntity> findByInstitution(String acronym,
			int start, int max) throws IllegalStateException,
			IllegalArgumentException {
		Query query = manager
				.createNamedQuery(PujCompetitionEntity.FIND_BY_INSTITUTION);
		query.setParameter(PujCompetitionEntity.PARAM_INSTITUTION_ACRONYM,
				acronym);
		query.setFirstResult(start);
		query.setMaxResults(max);
		return getResultList(query);
	}

	@Override
	public Collection<PujCompetitionEntity> findByStatus(
			CompetitionStatus status, int sorted) {
		return null;
	}
}
