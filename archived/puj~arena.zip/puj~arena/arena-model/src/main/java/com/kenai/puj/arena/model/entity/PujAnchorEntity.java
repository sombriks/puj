package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
public class PujAnchorEntity extends PujAbstractEntity {
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public enum Type {
		PHONE, LOGOTYPE, TWITTER, EMAIL, FACEBOOK, ORKUT, HOMEPAGE, BLOG, UNKNOWN
	}

	@XmlTransient
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;

	@XmlAttribute
	@Enumerated(EnumType.STRING)
	@Column(name = "ANCHOR_TYPE", columnDefinition = "VARCHAR(20) DEFAULT 'NEW'")
	public PujAnchorEntity.Type anchorType;

	public PujAnchorEntity.Type getAnchorType() {
		return anchorType;
	}

	public void setAnchorType(PujAnchorEntity.Type anchorType) {
		this.anchorType = anchorType;
	}

	@XmlAttribute
	@Column
	public String content;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
