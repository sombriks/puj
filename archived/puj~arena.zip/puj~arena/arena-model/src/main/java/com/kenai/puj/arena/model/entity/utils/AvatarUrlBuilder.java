package com.kenai.puj.arena.model.entity.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;

/**
 * This class must be reviewed and implemented thread safe for diverse types of
 * avatars.
 * 
 * @see <a href="http://en.gravatar.com/site/implement/java">Gravatar Java
 *      code.</a>
 * 
 */
public class AvatarUrlBuilder {
	enum AVATAR_TYPE {
		GRAVATAR, MONSTER, PUJ
	}

	private static final Logger LOGGER = Logger
			.getLogger(AvatarUrlBuilder.class.getName());

	private static final String JPG = ".jpg";
	private static final String UTF8 = "UTF-8";
	private static final String GRAVATAR_URL = "http://www.gravatar.com/avatar/";

	public static String hex(byte[] array) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < array.length; ++i) {
			sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(
					1, 3));
		}
		return sb.toString();
	}

	public static String hashGravatar(String email) {
		return hashGravatar(email, UTF8);
	}

	public static String hashGravatar(String email, String charset) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			return hex(md.digest(email.getBytes(charset)));
		} catch (NoSuchAlgorithmException e) {
			LOGGER.warning("failed to create avatar to the email '" + email
					+ "', error: " + e.getMessage());
		} catch (UnsupportedEncodingException e) {
			LOGGER.warning("failed to create avatar to the email '" + email
					+ "', error: " + e.getMessage());
		}
		return null;
	}

	public static void main(String[] args) throws NoSuchAlgorithmException {
		System.out
				.println(GRAVATAR_URL
						+ AvatarUrlBuilder
								.hashGravatar("andersonsevero@gmail.com") + JPG);
	}
}
