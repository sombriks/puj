package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujEvaluation;

@Local
public interface PujHomeworkEvaluationFacade extends
		PujEntityFacade<PujEvaluation> {
	Collection<PujEvaluation> readAllByCompetition(String pujId);
}