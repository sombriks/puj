package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujGroupEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;
import com.kenai.puj.arena.model.entity.facade.PujGroupFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujGroupFacadeImpl extends CRUDEntityFacade<PujGroupEntity>
		implements PujGroupFacade {

	@Override
	public PujGroupEntity addToGroup(PujUserEntity user, GROUP role) {
		/*
		 * PujGroupEntity group = new PujGroupEntity();
		 * group.setGroup(role.name()); group.setLogin(user.getLogin());
		 * EntityManager manager = emf.createEntityManager();
		 * manager.persist(group); manager.flush(); return group;
		 */
		return null;
	}
}
