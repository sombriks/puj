package com.kenai.puj.arena.model.atom.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.atom.CategoryType;

@Local
public interface PujAtomCategoryFacade extends PujAtomFacade<CategoryType> {
}