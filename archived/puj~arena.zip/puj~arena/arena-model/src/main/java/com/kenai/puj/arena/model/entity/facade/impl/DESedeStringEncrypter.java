package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 * @see <a
 *      href='http://www.devx.com/Java/10MinuteSolution/21385/1763/page/1'>Encry
 *      p t Sensitive Configuration Data with Java</a>
 * 
 */
public class DESedeStringEncrypter {
	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	private transient KeySpec keySpec;
	private transient SecretKeyFactory keyFactory;
	private transient Cipher cipher;
	private static final String CHARSET_UTF8 = "UTF-8";

	/**
	 * 
	 * @param encryptionScheme
	 * @param encryptionKey
	 * @throws GeneralSecurityException
	 */
	public DESedeStringEncrypter(String encryptionKey)
			throws GeneralSecurityException {
		byte[] keyAsBytes;
		try {
			keyAsBytes = encryptionKey.getBytes(CHARSET_UTF8);
		} catch (UnsupportedEncodingException e) {
			throw new GeneralSecurityException(e);
		}
		keySpec = new DESedeKeySpec(keyAsBytes);
		keyFactory = SecretKeyFactory.getInstance(DESEDE_ENCRYPTION_SCHEME);
		cipher = Cipher.getInstance(DESEDE_ENCRYPTION_SCHEME);
	}

	/**
	 * 
	 * @param unencryptedString
	 * @return
	 * @throws GeneralSecurityException
	 * @throws UnsupportedEncodingException
	 */
	public String encrypt(String unencryptedString)
			throws GeneralSecurityException, UnsupportedEncodingException {
		if (unencryptedString == null || unencryptedString.length() == 0) {
			throw new IllegalArgumentException(
					"unencrypted string was null or empty");
		}

		SecretKey key = keyFactory.generateSecret(keySpec);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] cleartext = unencryptedString.getBytes(CHARSET_UTF8);
		byte[] ciphertext = cipher.doFinal(cleartext);
		BASE64Encoder base64encoder = new BASE64Encoder();
		String base64 = base64encoder.encode(ciphertext);
		return URLEncoder.encode(base64, CHARSET_UTF8);
	}

	/**
	 * 
	 * @param encryptedString
	 * @return
	 * @throws GeneralSecurityException
	 * @throws IOException
	 */
	public String decrypt(String encryptedString)
			throws GeneralSecurityException, IOException {
		if (encryptedString == null || encryptedString.trim().length() <= 0) {
			throw new IllegalArgumentException(
					"encrypted string was null or empty");
		}
		SecretKey key = keyFactory.generateSecret(keySpec);
		cipher.init(Cipher.DECRYPT_MODE, key);

		byte[] cleartext = null;
		if (encryptedString.contains("=")) {
			BASE64Decoder base64decoder = new BASE64Decoder();
			cleartext = base64decoder.decodeBuffer(encryptedString);
		} else {
			cleartext = encryptedString.getBytes();
		}

		byte[] ciphertext = cipher.doFinal(cleartext);
		return new String(ciphertext, CHARSET_UTF8);
	}
}