package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries( {
		@NamedQuery(name = PujCompetitionEntity.FIND_BY_COMPETITION_NAME, query = "SELECT c FROM PujCompetitionEntity c WHERE c.name=:"
				+ PujCompetitionEntity.PARAM_COMPETITION_NAME),
		@NamedQuery(name = PujCompetitionEntity.FIND_BY_INSTITUTION, query = "SELECT roles.competition FROM PujInstitutionRoles roles JOIN roles.institution inst WHERE inst.acronym=:"
				+ PujCompetitionEntity.PARAM_INSTITUTION_ACRONYM) })
@XmlRootElement
@Entity
public class PujCompetitionEntity extends PujAbstractRootEntity {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	/**
	 * Searches for an user by his email or by his login. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_GROUP_ID</code>: the id of the institution
	 * that contains competitions</li>
	 * </ul>
	 */
	public static final String FIND_BY_COMPETITION_NAME = "findCompetitionByName";
	public static final String FIND_BY_INSTITUTION = "findCompetitionByInstitution";
	public static final String PARAM_COMPETITION_NAME = "pujName";
	public static final String PARAM_INSTITUTION_ACRONYM = "institutionAcronym";

	public static final String NAME = "name";

	/**
	 *<ul>
	 * <li>{@value CompetitionStatus#NEW} phase means an empty competition, non
	 * insertable and waiting further configurations.</li>
	 * <li>Homework submissions are only accepted during the
	 * {@value CompetitionStatus#CALL_FOR_PAPERS} phase</li>
	 * <li>Homework grades only accepted during the
	 * {@value CompetitionStatus#EVALUATION} phase</li>
	 * <li>Once {@value CompetitionStatus#HISTORY}, no more changes in the
	 * database are accepted</li>
	 * </ul>
	 */
	@XmlEnum(String.class)
	public enum CompetitionStatus {
		@XmlEnumValue("NEW")
		NEW, @XmlEnumValue("CALL_FOR_PAPERS")
		CALL_FOR_PAPERS, @XmlEnumValue("EVALUATION")
		EVALUATION, @XmlEnumValue("HISTORY")
		HISTORY
	}

	@XmlAttribute
	@Id
	@Column(name = NAME, length = 12)
	public String name;

	/**
	 * @see <a
	 *      href="http://www.summa-tech.com/blog/2009/02/24/speed-up-xml-programming-with-jaxb/">Speed
	 *      up XML programming with JAXB</a> TODO: why it do not serialize ?
	 */
	// @Column(columnDefinition = "VARCHAR(20) NOT NULL DEFAULT 'NEW'")
	@XmlAttribute
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "VARCHAR(20) DEFAULT 'NEW'")
	public CompetitionStatus status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PujCompetitionEntity.CompetitionStatus getStatus() {
		return status;
	}

	public void setStatus(PujCompetitionEntity.CompetitionStatus status) {
		this.status = status;
	}

	@Override
	public boolean equals(Object arg0) {
		if (arg0 == null || !(arg0 instanceof PujCompetitionEntity)) {
			return false;
		}
		return ((PujCompetitionEntity) arg0).getVersion() == this.getVersion()
				&& ((PujCompetitionEntity) arg0).getName().equals(
						this.getName());
	}

	@Override
	public int hashCode() {
		return getVersion();
	}
}
