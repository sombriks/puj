package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
@Entity
public class PujRelationEntity extends PujAbstractEntity {
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;


	@XmlTransient
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;

	@XmlTransient
	@Column(length = 32)
	private String rel;

	public enum HttpMethod {
		POST, PUT, GET, DELETE
	}
	@XmlTransient
	@Enumerated(EnumType.STRING)
	@Column
	private PujRelationEntity.HttpMethod method;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRel() {
		return rel;
	}

	public void setRel(String rel) {
		this.rel = rel;
	}

	public PujRelationEntity.HttpMethod getMethod() {
		return method;
	}

	public void setMethod(PujRelationEntity.HttpMethod method) {
		this.method = method;
	}
}
