package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujInstitutionDetailsEntity;

@Local
public interface PujInstitutionDetailsFacade extends
		PujEntityFacade<PujInstitutionDetailsEntity> {
}