package com.kenai.puj.arena.model.entity.utils;

import sun.misc.BASE64Encoder;

public class BasicAuthenticationUtils {
	public static final String AUTHENTICATION_HEADER = "Authorization";

	/**
	 * <p>
	 * Convenience string for Base 64 encoding.
	 * </p>
	 */
	// private static final String BASE64_CHARS =
	// "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	/**
	 * <p>
	 * Encode the specified credentials into a String as required by HTTP Basic
	 * Authentication (<a
	 * href="http://www.ietf.org/rfc/rfc2617.txt">RFC2617</a>).
	 * </p>
	 * 
	 * @param username
	 *            Username to be encoded
	 * @param password
	 *            Password to be encoded
	 */
	public static String encodeCredentialsBasic(String username, String password) {
		String encode = username + ":" + password;
		/*
		 * int paddingCount = (3 - (encode.length() % 3)) % 3; encode +=
		 * "\0\0".substring(0, paddingCount); StringBuilder encoded = new
		 * StringBuilder(); for (int i = 0; i < encode.length(); i += 3) { int j
		 * = (encode.charAt(i) << 16) + (encode.charAt(i + 1) << 8) +
		 * encode.charAt(i + 2); encoded.append(BASE64_CHARS.charAt((j >> 18) &
		 * 0x3f)); encoded.append(BASE64_CHARS.charAt((j >> 12) & 0x3f));
		 * encoded.append(BASE64_CHARS.charAt((j >> 6) & 0x3f));
		 * encoded.append(BASE64_CHARS.charAt(j & 0x3f)); }
		 */
		BASE64Encoder enc = new BASE64Encoder();
		return "Basic " + enc.encode(encode.getBytes());
	}
}
