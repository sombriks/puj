package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;

import org.eclipse.persistence.expressions.ExpressionBuilder;
import org.eclipse.persistence.jpa.JpaEntityManager;
import org.eclipse.persistence.queries.ObjectLevelReadQuery;
import org.eclipse.persistence.queries.ReadAllQuery;

import com.kenai.puj.arena.model.entity.PujAbstractEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujEntityFacade;

/**
 * CRUD operations shared by the Entity Facades.
 * 
 * @see <a
 *      href='http://en.wikipedia.org/wiki/Create,_read,_update_and_delete'>Crea
 *      t e , read, update and delete (CRUD)</a>
 */
@Stateless
public abstract class CRUDEntityFacade<T extends PujAbstractEntity> implements
		PujEntityFacade<T> {

	@PersistenceContext
	protected EntityManager manager;

	private transient final Class<T> entityClass;

	@SuppressWarnings("unchecked")
	public CRUDEntityFacade() {
		entityClass = (Class<T>) ((java.lang.reflect.ParameterizedType) this
				.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}

	@Override
	public T create(final T entity) throws EntityExistsException,
			IllegalStateException, IllegalArgumentException,
			TransactionRequiredException {
		manager.persist(entity);
		manager.flush();
		return entity;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public Collection<T> readAll(Class<T> type, int start, int max)
			throws IllegalStateException, IllegalArgumentException {
		if (start < 0) {
			start = 0;
		}
		if (max < 1 || max > EntityFacadeConstants.PAGINATION_MAX_SIZE) {
			max = EntityFacadeConstants.PAGINATION_MAX_SIZE;
		}

		Query query = manager.createQuery("select e from "
				+ type.getSimpleName() + " e");
		query.setFirstResult(start);
		query.setMaxResults(max);
		return getResultList(query);
	}

	public Query getNamedQuery(String queryName) {
		return manager.createNamedQuery(queryName);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public T read(Class<T> type, final Object primaryKey)
			throws IllegalStateException, IllegalArgumentException {
		return manager.find(type, primaryKey);
	}

	@Override
	public void delete(Class<T> type, final Object id)
			throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException, PersistenceException {
		T attached = manager.find(type, id);
		manager.remove(attached);
		manager.flush();
	}

	@Override
	public void deleteAll(final Collection<T> entities)
			throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException, PersistenceException {
		for (T t : entities) {
			manager.remove(t);
		}
		manager.flush();
	}

	@Override
	public T update(final T entity) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			PersistenceException {
		return manager.merge(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getResultList(Query query) throws IllegalStateException,
			IllegalArgumentException {
		List<T> response = query.getResultList();
		if (response == null) {
			response = new ArrayList<T>();
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getSingleresult(Query query) throws IllegalStateException,
			IllegalArgumentException {
		return (T) query.getSingleResult();
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public long count(Class<T> type) throws IllegalStateException,
			IllegalArgumentException {
		Query query = manager.createQuery("select count(e) from "
				+ type.getSimpleName() + " e");
		Number countResult = (Number) query.getSingleResult();
		return countResult.longValue();
	}

	protected String sqlEscape(String query) {
		return query.replaceAll("'", "''");
	}

	public Collection<T> findByCriteria(
			Map<String, ? extends Serializable> parameters, int start, int max)
			throws IllegalStateException, IllegalArgumentException {
		ExpressionBuilder builder = new ExpressionBuilder();
		ReadAllQuery query = new ReadAllQuery(entityClass, builder);
		return findByCriteria(parameters, start, max, query);
	}

	@SuppressWarnings("unchecked")
	public Collection<T> findByCriteria(
			Map<String, ? extends Serializable> parameters, int start, int max,
			ObjectLevelReadQuery query) throws IllegalStateException,
			IllegalArgumentException {
		ExpressionBuilder builder;

		if (query == null) {
			builder = new ExpressionBuilder();
			query = new ReadAllQuery(entityClass, builder);
		} else {
			builder = query.getExpressionBuilder();
		}

		if (start < 0 || max < 0) {
			throw new IllegalArgumentException(
					"pagination does not support negative values: start="
							+ start + ", max=" + max);
		} else if (max < start
				|| max - start > EntityFacadeConstants.PAGINATION_MAX_SIZE) {
			max = start + EntityFacadeConstants.PAGINATION_MAX_SIZE;
		}

		query.setFirstResult(start);
		query.setMaxRows(max);
		Iterator entries = parameters.entrySet().iterator();
		while (entries.hasNext()) {
			Map.Entry<String, ?> entry = (Map.Entry<String, ?>) entries.next();
			query.setSelectionCriteria(builder.get(entry.getKey()).equal(
					entry.getValue()));
		}

		Query dbQuery = ((JpaEntityManager) manager.getDelegate())
				.createQuery(query);
		return dbQuery.getResultList();
	}

	public T find(Object pk) {
		return manager.find(entityClass, pk);
	}
}
