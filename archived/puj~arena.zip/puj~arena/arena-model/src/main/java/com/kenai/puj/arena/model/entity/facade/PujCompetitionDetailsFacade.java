package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujCompetitionDetailsEntity;

@Local
public interface PujCompetitionDetailsFacade extends
		PujEntityFacade<PujCompetitionDetailsEntity> {
}