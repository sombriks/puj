package com.kenai.puj.arena.model.entity;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
public class PujScoreCard extends PujAbstractEntity {
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;

	@XmlElement
	@Temporal(TemporalType.DATE)
	@Column(nullable = true)
	private Date lastUpdated;

	@XmlElement
	@OneToOne
	private PujHomeworkRef homework;

	@XmlElement
	@OneToMany(orphanRemoval = true)
	private Collection<PujEvaluation> evaluation;

	@XmlElement
	@Column
	private double harmonicMean;

	@XmlElement
	@Column
	private double aritmeticMean;

	@XmlElement
	@Column
	private double stdDeviation;

	@XmlElement
	@Column
	private char trend;

	public double getHarmonicMean() {
		return harmonicMean;
	}

	public void setHarmonicMean(double harmonicMean) {
		this.harmonicMean = harmonicMean;
	}

	public double getAritmeticMean() {
		return aritmeticMean;
	}

	public void setAritmeticMean(double aritmeticMean) {
		this.aritmeticMean = aritmeticMean;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getLastUpdated() {
		return new Date(lastUpdated.getTime());
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = new Date(lastUpdated.getTime());
	}

	public double getStdDeviation() {
		return stdDeviation;
	}

	public void setStdDeviation(double stdDeviation) {
		this.stdDeviation = stdDeviation;
	}

	public char getTrend() {
		return trend;
	}

	public void setTrend(char trend) {
		this.trend = trend;
	}

	public PujHomeworkRef getHomework() {
		return homework;
	}

	public void setHomework(PujHomeworkRef homework) {
		this.homework = homework;
	}

	public Collection<PujEvaluation> getEvaluation() {
		return evaluation;
	}

	public void setEvaluation(Collection<PujEvaluation> evaluation) {
		this.evaluation = evaluation;
	}
}
