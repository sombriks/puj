package com.kenai.puj.arena.model.entity;

import java.io.Serializable;

public class PujEvaluation_PK implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	private String homework;

	private String evaluator;

	public String getHomework() {
		return homework;
	}

	public void setHomework(String homework) {
		this.homework = homework;
	}

	public String getEvaluator() {
		return evaluator;
	}

	public void setEvaluator(String evaluator) {
		this.evaluator = evaluator;
	}
}
