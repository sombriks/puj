package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;

import javax.ejb.Local;

/**
 * The confirmation of a registration is done through an URL encrypted to ensure
 * a minimum security level.
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 */
@Local
public interface URLDeobfuscator {
	/**
	 * Extract the parameters encrytped in the confirmation URL.
	 * 
	 * @return an encrypted confirmation URL.
	 * @throws GeneralSecurityException
	 * @throws IOException
	 */
	Map<String, String> extractParameters(String obfuscated)
			throws GeneralSecurityException, IOException;
}
