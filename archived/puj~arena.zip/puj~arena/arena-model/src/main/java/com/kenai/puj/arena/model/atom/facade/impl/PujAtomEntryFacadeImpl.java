package com.kenai.puj.arena.model.atom.facade.impl;

import javax.ejb.Stateless;
import javax.persistence.EntityExistsException;
import javax.persistence.TransactionRequiredException;

import com.kenai.puj.arena.model.atom.EntryType;
import com.kenai.puj.arena.model.atom.facade.PujAtomEntryFacade;
import com.kenai.puj.arena.model.entity.facade.impl.CRUDEntityFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujAtomEntryFacadeImpl extends CRUDAtomFacade<EntryType> implements
		PujAtomEntryFacade {
	@Override
	public EntryType create(EntryType entity) throws EntityExistsException,
			IllegalStateException, IllegalArgumentException,
			TransactionRequiredException {
		EntryType entry = super.create(entity);
		manager.flush();

		entry.setContentId(entry.getCategory().getScheme()
				+ entry.getCategory().getTerm() + "/" + entry.getId());
		return update(entry);
	}
}
