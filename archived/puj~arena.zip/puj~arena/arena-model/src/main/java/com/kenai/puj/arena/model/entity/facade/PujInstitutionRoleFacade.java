package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujInstitutionRoles;

@Local
public interface PujInstitutionRoleFacade extends
		PujEntityFacade<PujInstitutionRoles> {
	PujInstitutionRoles create(String competition, String institution,
			String role);
}