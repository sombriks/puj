package com.kenai.puj.arena.model.entity;

import java.io.Serializable;

public class PujInstitutionRoles_PK implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	private String institution;

	private String competition;

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getCompetition() {
		return competition;
	}

	public void setCompetition(String competition) {
		this.competition = competition;
	}
}
