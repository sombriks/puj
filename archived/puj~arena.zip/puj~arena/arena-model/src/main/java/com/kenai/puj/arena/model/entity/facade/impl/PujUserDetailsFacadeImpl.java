package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.persistence.Query;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.PujUserDetailsFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujUserDetailsFacadeImpl extends
		CRUDEntityFacade<PujUserDetailsEntity> implements PujUserDetailsFacade {
	@Override
	public Collection<PujUserDetailsEntity> readHomeworkAuthors(String pujName,
			String homeworkAcronym, String role) {
		Query query = null;
		if (role == null) {
			query = manager
					.createNamedQuery(PujUserDetailsEntity.HOMEWORK_AUTHORS);
		} else {
			query = manager
					.createNamedQuery(PujUserDetailsEntity.HOMEWORK_AUTHORS_BY_ROLE);
			query.setParameter(PujUserDetailsEntity.PARAM_USER_ROLE, role);
		}
		query.setParameter(PujUserDetailsEntity.HOMEWORK_ACRONYM,
				homeworkAcronym);
		return getResultList(query);
	}

	@Override
	public Collection<PujUserDetailsEntity> readAll(String puj, String role,
			int start, int max) {
		Query query = null;
		if (puj == null) {
			query = manager.createNamedQuery(PujUserDetailsEntity.READ_ALL);
		} else if (role == null) {
			query = manager
					.createNamedQuery(PujUserDetailsEntity.FIND_BY_COMPETITION);
			query
					.setParameter(PujUserDetailsEntity.PARAM_COMPETITION_NAME,
							puj);
		} else {
			query = manager
					.createNamedQuery(PujUserDetailsEntity.FIND_BY_COMPETITION_AND_ROLE);
			query.setParameter(PujUserDetailsEntity.PARAM_USER_ROLE, role);
			query
					.setParameter(PujUserDetailsEntity.PARAM_COMPETITION_NAME,
							puj);
		}
		query.setFirstResult(start);
		query.setMaxResults(max);

		Collection<PujUserDetailsEntity> response = getResultList(query);
		return response;
	}
}
