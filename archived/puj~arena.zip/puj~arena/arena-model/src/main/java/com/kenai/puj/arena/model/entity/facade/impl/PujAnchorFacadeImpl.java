package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujAnchorEntity;
import com.kenai.puj.arena.model.entity.facade.PujAnchorFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujAnchorFacadeImpl extends CRUDEntityFacade<PujAnchorEntity>
		implements PujAnchorFacade {
}
