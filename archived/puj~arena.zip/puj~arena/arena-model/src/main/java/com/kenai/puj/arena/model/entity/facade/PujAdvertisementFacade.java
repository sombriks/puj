package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;

@Local
public interface PujAdvertisementFacade extends
		PujEntityFacade<PujAdvertisementEntity> {
	Collection<PujAdvertisementEntity> getAdvertisement(String compName,
			String role, int max);
}