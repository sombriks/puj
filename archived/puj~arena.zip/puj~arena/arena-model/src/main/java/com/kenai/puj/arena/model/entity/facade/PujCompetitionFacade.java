package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity.CompetitionStatus;

@Local
public interface PujCompetitionFacade extends
		PujEntityFacade<PujCompetitionEntity> {
	Collection<PujCompetitionEntity> findByInstitution(String institution,
			int start, int max) throws IllegalStateException,
			IllegalArgumentException;

	Collection<PujCompetitionEntity> findByStatus(CompetitionStatus status,
			int sorted);

}