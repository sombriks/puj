package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jms.JMSException;
import javax.persistence.EntityExistsException;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity.UserStatus;
import com.kenai.puj.arena.model.entity.facade.NotificationFacade;
import com.kenai.puj.arena.model.entity.facade.PujUserFacade;
import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.model.entity.utils.PasswordUtil;

/** @see CRUDEntityFacade */
@Stateless
public class PujUserFacadeImpl extends CRUDEntityFacade<PujUserEntity>
		implements PujUserFacade {
	@EJB
	private URLDeobfuscator urlDeobfuscator;
	@EJB
	private NotificationFacade notification;

	@Override
	public PujUserEntity activate(String key) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			GeneralSecurityException, IOException, JMSException {
		Map<String, String> userData = urlDeobfuscator.extractParameters(key);
		String login = userData.get(RegistrationConstants.LOGIN.value());
		String email = userData.get(RegistrationConstants.EMAIL.value());

		if (login == null || email == null) {
			throw new IllegalArgumentException("Invalid registration key.");
		} else {
			PujUserEntity user = find(login);
			if (user == null) {
				throw new IllegalArgumentException("User " + login
						+ " not found.");
			} else {
				changeStatus(login, email, PujUserEntity.UserStatus.ACTIVE);
				return user;
			}
		}
	}

	@Override
	public void changePassword(String login, String oldPassword,
			String newPassword, String confirmationMessage)
			throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException, GeneralSecurityException, IOException {
		/*
		 * if (login == null || email == null) { throw new
		 * IllegalArgumentException("invalid registration key."); } else {
		 * EntityManager manager = emf.createEntityManager(); try { Query query
		 * = manager .createNamedQuery(PujUserEntity.UPDATE_USER_STATUS);
		 * query.setParameter(PujUserEntity.PARAM_USER_LOGIN, login);
		 * query.setParameter(PujUserEntity.PARAM_USER_EMAIL, email);
		 * query.setParameter(PujUserEntity.PARAM_USER_STATUS,
		 * PujUserEntity.UserStatus.ACTIVE); if (query.executeUpdate() != 1) {
		 * throw new IllegalStateException(
		 * "Unable to update the status of the user " + login); } } finally { if
		 * (manager != null && manager.isOpen()) { manager.close(); } } }
		 */
		throw new IOException("not yet implemented");
	}

	@Override
	public void resetPassword(String key, String newPlainPassword,
			String confirmationMessage) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			GeneralSecurityException, IOException {
		Map<String, String> userData = urlDeobfuscator.extractParameters(key);
		String login = userData.get(RegistrationConstants.LOGIN.value());
		String email = userData.get(RegistrationConstants.EMAIL.value());

		if (login == null || email == null) {
			throw new IllegalArgumentException("invalid registration key.");
		} else {
			Query query = manager
					.createNamedQuery(PujUserEntity.UPDATE_USER_STATUS);
			query.setParameter(PujUserEntity.PARAM_USER_LOGIN, login);
			query.setParameter(PujUserEntity.PARAM_USER_EMAIL, email);
			query.setParameter(PujUserEntity.PARAM_USER_STATUS,
					PujUserEntity.UserStatus.ACTIVE);
			if (query.executeUpdate() != 1) {
				throw new IllegalStateException(
						"Unable to update the status of the user " + login);
			}
		}
	}

	@Override
	public boolean isLoginAndEmailAvailable(String login, String email) {
		if (email == null) {
			email = "";
		}
		if (login == null) {
			login = "";
		}

		Query query = manager
				.createNamedQuery(PujUserDetailsEntity.CHECK_IF_EXISTS_BY_LOGIN_OR_EMAIL);
		query.setParameter(PujUserDetailsEntity.PARAM_LOGIN, login);
		query.setParameter(PujUserDetailsEntity.PARAM_EMAIL, email);
		return getResultList(query).size() == 0;
	}

	@Override
	public boolean isLoginAvailable(String login) {
		return isLoginAndEmailAvailable("", login);
	}

	@Override
	public boolean isEmailAvailable(String email) {
		return isLoginAndEmailAvailable(email, "");
	}

	@Override
	public PujUserEntity registerAndNotify(PujUserDetailsEntity user,
			Properties props) throws EntityExistsException,
			IllegalStateException, IllegalArgumentException,
			TransactionRequiredException, JMSException {
		user.setStatus(PujUserEntity.UserStatus.NEW);
		user.setPassword(PasswordUtil.hashPassword(user.getPassword()));
		manager.persist(user);
		notification.notifyNewUser(user, props);
		manager.flush();
		return user;
	}

	@Override
	public void changeStatus(String login, String email, UserStatus status)
			throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException {
		Query query = manager
				.createNamedQuery(PujUserEntity.UPDATE_USER_STATUS);
		query.setParameter(PujUserEntity.PARAM_USER_LOGIN, login);
		query.setParameter(PujUserEntity.PARAM_USER_EMAIL, email);
		query.setParameter(PujUserEntity.PARAM_USER_STATUS, status);
		if (query.executeUpdate() != 1) {
			throw new IllegalStateException(
					"Unable to update the status of the user " + login);
		}
	}
}
