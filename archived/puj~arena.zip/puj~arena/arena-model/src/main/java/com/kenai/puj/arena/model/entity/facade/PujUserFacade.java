package com.kenai.puj.arena.model.entity.facade;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;

import javax.ejb.Local;
import javax.jms.JMSException;
import javax.persistence.EntityExistsException;
import javax.persistence.TransactionRequiredException;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;

@Local
public interface PujUserFacade extends PujEntityFacade<PujUserEntity> {

	/**
	 * <strong>C</strong><font color='gray'>RUD</font> operation - inserts a new
	 * entity in the database.
	 * 
	 * @param user
	 *            The user to be registered in the database.
	 * @param props
	 *            Properties used in the message creation.
	 * @throws EntityExistsException
	 *             database exception, or incompatible entity.
	 * @throws IllegalStateException
	 *             database exception, or incompatible entity.
	 * @throws IllegalArgumentException
	 *             database exception, or incompatible entity.
	 * @throws TransactionRequiredException
	 *             database exception, or incompatible entity.
	 * @throws JMSException
	 */
	PujUserEntity registerAndNotify(PujUserDetailsEntity user, Properties props)
			throws EntityExistsException, IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			JMSException;

	/**
	 * Activate an account, copying the value of the unconfirmed column to the
	 * password column.
	 * 
	 * @param user
	 *            the owner of the account to be activated
	 * @throws IllegalStateException
	 * @throws IllegalArgumentException
	 * @throws TransactionRequiredException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 * @throws JMSException
	 */
	PujUserEntity activate(String key) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			GeneralSecurityException, IOException, JMSException;

	/**
	 * Reset the password - creates a random new password. The implementation is
	 * not supposed to generate strong passwords, and the user should be
	 * notified to change his password asap.
	 * 
	 * @param key
	 *            The has key sent by email to confirm the authenticity of the
	 *            request.
	 * @param newPlainPassword
	 *            the new password, it will be hashed before stored in the
	 *            database. A confirmation email will be sent to the user.
	 * @throws GeneralSecurityException
	 *             The underneath implementation may use an encryption
	 *             algorithm, and any error should be thrown to the caller
	 *             method.
	 * @throws IllegalStateException
	 *             JPA exception.
	 * @throws IllegalArgumentException
	 *             If the key does not contains the expected information -
	 *             probably a forged key.
	 * @throws TransactionRequiredException
	 *             if the container managed transaction is disabled.
	 * @throws IOException
	 *             a general exception with the streams.
	 */
	public void resetPassword(String key, String newPlainPassword,
			String confirmationMessage) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			GeneralSecurityException, IOException;

	/**
	 * Change password, probably due to a end user request. If the old password
	 * does not match the one provided as parameter, the password is not
	 * changed. If the change password succeed, the user should receive a
	 * confirmation email about that.
	 * 
	 * @param login
	 * @param oldPassword
	 * @param newPassword
	 *            the new password, it will be hashed before stored in the
	 *            database. A confirmation email will be sent to the user.
	 * 
	 * @param confirmationMessage
	 * @throws IllegalStateException
	 * @throws IllegalArgumentException
	 * @throws TransactionRequiredException
	 * @throws GeneralSecurityException
	 * @throws IOException
	 */
	public void changePassword(String login, String oldPassword,
			String newPassword, String confirmationMessage)
			throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException, GeneralSecurityException, IOException;

	/**
	 * Deactivate an account, copying the value of the password column to the
	 * unconfirmed column.
	 * 
	 * @param user
	 * @throws IllegalStateException
	 * @throws IllegalArgumentException
	 * @throws TransactionRequiredException
	 */
	void changeStatus(String login, String email,
			PujUserEntity.UserStatus status) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException;

	/**
	 * Check if an <em>email address</em> can be registered in the database.
	 * This method is useful for client's AJAX call during the form registration
	 * - to warn the new customer about the availability of the typed values.
	 * 
	 * @param email
	 *            the email of a customer.
	 * @return if the email is available, false otherwise.
	 */
	boolean isEmailAvailable(final String email);

	/**
	 * Check if an <em>user name</em> can be registered in the database.This
	 * method is useful for client's AJAX call during the form registration - to
	 * warn the new customer about the availability of the typed values.
	 * 
	 * @param login
	 *            the login of a customer.
	 * @return true if the login is available, false otherwise.
	 */
	boolean isLoginAvailable(final String login);

	/**
	 * Check if a pair <em>login</em> / <em>email</em> can be registered in the
	 * database. This method is useful for internal checking - a double
	 * verification behind the service facade.
	 * 
	 * @param login
	 *            the login of a customer.
	 * @param email
	 *            the email of a customer.
	 * @return true if the login is available, false otherwise.
	 */
	boolean isLoginAndEmailAvailable(String login, String email);

}