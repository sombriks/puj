package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujCompetitionDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionDetailsFacade;

@Stateless
public class PujCompetitionDetailsFacadeImpl extends
		CRUDEntityFacade<PujCompetitionDetailsEntity> implements
		PujCompetitionDetailsFacade {
}
