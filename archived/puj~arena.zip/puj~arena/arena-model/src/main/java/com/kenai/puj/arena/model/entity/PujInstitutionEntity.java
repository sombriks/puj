package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries( {
		@NamedQuery(name = PujInstitutionEntity.FIND_BY_ROLE, query = "SELECT DISTINCT rolesPerPuj.institution FROM PujInstitutionRoles rolesPerPuj WHERE rolesPerPuj.role= :"
				+ PujInstitutionEntity.ROLES),
		@NamedQuery(name = PujInstitutionEntity.CHECK_IF_EXISTS, query = "SELECT count(inst) FROM PujInstitutionDetailsEntity inst WHERE inst.acronym=:"
				+ PujInstitutionEntity.ACRONYM) })
@XmlRootElement
@Entity
public class PujInstitutionEntity extends PujAbstractRootEntity {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;
	public static final String FIND_BY_ROLE = "findInstitutionByRole";
	public static final String CHECK_IF_EXISTS = "checkIfInstitutionExists";
	public static final String ACRONYM = "acronym";
	public static final String NAME = "name";
	public static final String ROLES = "roles";

	@XmlAttribute
	@Id
	@Column(name = ACRONYM, length = 20)
	private String acronym;

	@XmlAttribute
	@Column(name = NAME, nullable = true)
	private String name;

	@XmlElement
	@Column(nullable = true)
	private String logo;

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAcronym() {
		return acronym;
	}

	public void setAcronym(String acronym) {
		this.acronym = acronym;
	}
}
