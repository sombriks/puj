package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;

@Local
public interface PujUserDetailsFacade extends
		PujEntityFacade<PujUserDetailsEntity> {

	/**
	 * Read the authors of a homework.
	 * 
	 * @param pujName
	 *            the competition name.
	 * @param homeworkAcronym
	 *            the homework acronym.
	 * @param role
	 *            (<em>optional</em>) the role of the authors - it can be
	 *            professor, student or null - if this parameter is null, all
	 *            authors of the homework will be returned.
	 * @return a list of the homework authors. Eventually empty, but never null.
	 */
	Collection<PujUserDetailsEntity> readHomeworkAuthors(String pujName,
			String homeworkAcronym, String role);

	/**
	 * Read all users from a competition by Role.
	 * 
	 * @param role
	 *            the role of the user (<em>optional</em>).
	 * @param puj
	 *            The unique name of a competition.
	 * @param start
	 *            the first index of the page
	 * @param max
	 *            the maximum number of users in the response.
	 * @return a collection of users, eventually empty but never null.
	 */
	Collection<PujUserDetailsEntity> readAll(String puj, String role,
			int start, int max);
}