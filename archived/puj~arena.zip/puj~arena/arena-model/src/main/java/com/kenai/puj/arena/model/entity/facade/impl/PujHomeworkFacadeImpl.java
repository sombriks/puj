package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.persistence.Query;
import javax.xml.ws.WebServiceException;

import com.kenai.puj.arena.model.entity.PujHomeworkEntity;
import com.kenai.puj.arena.model.entity.PujScoreCard;
import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujHomeworkFacadeImpl extends CRUDEntityFacade<PujHomeworkEntity>
		implements PujHomeworkFacade {

	@Override
	public PujScoreCard getScoreCard(final int id) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<PujHomeworkEntity> readAllByCompetition(int start,
			int max, String institution, String name) {
		Query query = manager
				.createNamedQuery(PujHomeworkEntity.FIND_BY_COMPETITION);
		if (name == null || name.trim().length() == 0) {
			query
					.setParameter(PujUserDetailsEntity.PARAM_COMPETITION_NAME,
							"*");
		} else {
			query.setParameter(PujUserDetailsEntity.PARAM_COMPETITION_NAME,
					name);
		}

		query.setFirstResult(start);
		query.setMaxResults(max);

		Collection<PujHomeworkEntity> response = getResultList(query);
		return response;
	}

	@Override
	public Collection<PujHomeworkEntity> readAllByCompetition(String name,
			int offset, int chunk) {
		Query query = manager
				.createNamedQuery(PujHomeworkEntity.FIND_BY_COMPETITION);
		query.setParameter(PujHomeworkEntity.PARAM_COMPETITION_ACRONYM, name);
		query.setFirstResult(offset);
		query.setMaxResults(chunk);
		return getResultList(query);
	}

	@Override
	public void addAuthor(String login) {
		throw new WebServiceException("not yet implemented");
	}
}
