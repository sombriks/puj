package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.Query;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujEvaluation;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkEvaluationFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujEvaluationFacadeImpl extends CRUDEntityFacade<PujEvaluation>
		implements PujHomeworkEvaluationFacade {

	@EJB
	private PujCompetitionFacade pujFacade;

	@Override
	public Collection<PujEvaluation> readAllByCompetition(String pujId) {
		PujCompetitionEntity puj = pujFacade.find(pujId);
		if (puj == null) {
			return new ArrayList<PujEvaluation>();
		} else {
			/*
			 * ExpressionBuilder homeworksBuilder = new ExpressionBuilder();
			 * ReportQuery homeworkBycompetition = new ReportQuery(
			 * PujHomeworkEntity.class, homeworksBuilder);
			 * homeworkBycompetition.setSelectionCriteria(homeworksBuilder.get(
			 * "competition").equal(puj));
			 * 
			 * ReadAllQuery allEval = new ReadAllQuery(PujEvaluation.class);
			 * allEval.setSelectionCriteria(allEval.getExpressionBuilder().get(
			 * "homework").in(homeworkBycompetition));
			 * 
			 * Query dbQuery = ((JpaEntityManager) manager.getDelegate())
			 * .createQuery(allEval); return dbQuery.getResultList();
			 */

			/*
			 * CriteriaBuilder queryBuilder = manager.getCriteriaBuilder();
			 * CriteriaQuery qdef =
			 * queryBuilder.createQuery(PujEvaluation.class);
			 * 
			 * 
			 * 
			 * qdef.getRestriction().in()getExpressions().add()where(qdef.
			 * getGroupRestriction());
			 * 
			 * // FROM PujEvaluation eval WHERE eval.homework.competition.name=:
			 */

			Query query = manager
					.createNamedQuery(PujEvaluation.FIND_BY_COMPETITION);
			query.setParameter(PujEvaluation.PARAM_COMPETITION_NAME, pujId);
			return getResultList(query);

		}
	}
}
