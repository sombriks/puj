package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/*
 @NamedQueries( { @NamedQuery(name = PujAdvertisementEntity.FIND_BY_COMPETITION, query = "SELECT adv FROM PujAdvertisementEntity adv WHERE adv.institution IN "
 + "(SELECT roles.institution FROM PujInstitutionRoles roles JOIN roles.competition comp WHERE roles.role = :"
 + PujAdvertisementEntity.PARAM_INSTITUTION_ROLE
 + " AND comp.name = :"
 + PujAdvertisementEntity.PARAM_COMPETITION_NAME + ")") })*/
@XmlRootElement
@Entity
public class PujAdvertisementEntity extends PujAbstractEntity {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public static final String PARAM_INSTITUTION_ROLE = "advRole";
	public static final String PARAM_COMPETITION_NAME = "advCompName";
	public static final String FIND_BY_COMPETITION = "advByCompetition";

	@XmlTransient
	@Id
	@OneToOne(fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn
	public PujInstitutionEntity institution;

	@XmlAttribute
	@Column
	public String url;

	@XmlAttribute
	@Column
	public String thumbnail;

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public PujInstitutionEntity getInstitution() {
		return institution;
	}

	public void setInstitution(PujInstitutionEntity institution) {
		this.institution = institution;
	}
}
