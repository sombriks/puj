package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujRoleEntity;

@Local
public interface PujRoleFacade extends PujEntityFacade<PujRoleEntity> {
}