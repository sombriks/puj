package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionRoles;
import com.kenai.puj.arena.model.entity.PujInstitutionRoles.Role;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionFacade;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionRoleFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujInstitutionRoleFacadeImpl extends
		CRUDEntityFacade<PujInstitutionRoles> implements
		PujInstitutionRoleFacade {
	@EJB
	private PujInstitutionFacade institutionFacade;
	@EJB
	private PujCompetitionFacade competitionFacade;

	@Override
	public PujInstitutionRoles create(String competition, String institution,
			String instRole) {
		Role role = PujInstitutionRoles.Role.valueOf(instRole);
		PujCompetitionEntity comp = competitionFacade.read(
				PujCompetitionEntity.class, competition);
		PujInstitutionEntity inst = institutionFacade.read(
				PujInstitutionEntity.class, institution);
		PujInstitutionRoles joinTable = new PujInstitutionRoles();
		joinTable.setRole(role);
		joinTable.setInstitution(inst);
		joinTable.setCompetition(comp);
		return create(joinTable);
	}
}
