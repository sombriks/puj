package com.kenai.puj.arena.model.entity;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.FetchType;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@MappedSuperclass
public abstract class PujAbstractRootEntity extends PujAbstractEntity {
	/** Transient serialization version UID. */
	public static final long serialVersionUID = 196919661993L;

	@XmlElement(nillable = true)
	@OneToMany(fetch = FetchType.EAGER, orphanRemoval = true)
	public Collection<PujLinkEntity> links;

	public Collection<PujLinkEntity> getLinks() {
		if(links == null) {
			links = new ArrayList<PujLinkEntity>();
		}
		return links;
	}

	public void setLinks(Collection<PujLinkEntity> links) {
		this.links = links;
	}
}
