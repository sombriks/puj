package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujRoleEntity;
import com.kenai.puj.arena.model.entity.facade.PujRoleFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujRoleFacadeImpl extends CRUDEntityFacade<PujRoleEntity>
		implements PujRoleFacade {
}
