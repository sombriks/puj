package com.kenai.puj.arena.model.atom.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.atom.CategoryType;
import com.kenai.puj.arena.model.atom.facade.PujAtomCategoryFacade;
import com.kenai.puj.arena.model.entity.facade.impl.CRUDEntityFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujAtomCategoryFacadeImpl extends CRUDAtomFacade<CategoryType>
		implements PujAtomCategoryFacade {
}
