package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.ejb.Stateless;
import javax.ws.rs.core.UriBuilder;

import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;

/**
 * Default URL obfuscator applies a a simple shift plus the MD5 cypher o the
 * plain information.
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 */
@Stateless
public class DefaultUrlObfuscator implements URLObfuscator, URLDeobfuscator {
	private static final String URL_PARAMS_LOGIN = "&login=";
	private static final String URL_PARAMS_EMAIL = "email=";
	private static final String URL_PARAMS_SEPARATOR = "?&=";
	private transient final DESedeStringEncrypter ENCRYPTER;
	private transient final static String ENCRYPTION_KEY = "todo_to_think_about_this_key_not_hard_code";

	public DefaultUrlObfuscator() throws GeneralSecurityException {
		ENCRYPTER = new DESedeStringEncrypter(ENCRYPTION_KEY);
	}

	@Override
	public URL createObfuscatedUrl(String login, String email, String baseUrl)
			throws MalformedURLException, GeneralSecurityException,
			UnsupportedEncodingException {
		StringBuffer buffer = new StringBuffer();
		buffer.append(URL_PARAMS_EMAIL);
		buffer.append(email);
		buffer.append(URL_PARAMS_LOGIN);
		buffer.append(login);
		String hashKey = ENCRYPTER.encrypt(buffer.toString());
		return UriBuilder.fromPath(baseUrl).queryParam(
				RegistrationConstants.CONFIRMATION_KEY.value(), hashKey)
				.build().toURL();
	}

	@Override
	public Map<String, String> extractParameters(String obfuscated)
			throws GeneralSecurityException, IOException {
		Map<String, String> parameters = new HashMap<String, String>();
		String plain = ENCRYPTER.decrypt(obfuscated);
		StringTokenizer parametersTokenizer = new StringTokenizer(plain,
				URL_PARAMS_SEPARATOR, false);
		while (parametersTokenizer.hasMoreTokens()) {
			String token = parametersTokenizer.nextToken();
			if (token.equals(RegistrationConstants.EMAIL.value())
					&& parametersTokenizer.hasMoreTokens()) {
				parameters.put(RegistrationConstants.EMAIL.value(),
						parametersTokenizer.nextToken());
			} else if (token.equals(RegistrationConstants.LOGIN.value())
					&& parametersTokenizer.hasMoreTokens()) {
				parameters.put(RegistrationConstants.LOGIN.value(),
						parametersTokenizer.nextToken());
			}
		}
		return parameters;
	}

	public static void main(String[] args) throws GeneralSecurityException,
			IOException {
		DefaultUrlObfuscator oo = new DefaultUrlObfuscator();
		System.out
				.println(oo
						.extractParameters("JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BhPgrMl1AhnGA%3D%3D"));
	}
}
