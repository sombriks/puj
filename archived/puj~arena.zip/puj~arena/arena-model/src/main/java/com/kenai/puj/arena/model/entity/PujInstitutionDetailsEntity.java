package com.kenai.puj.arena.model.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
public class PujInstitutionDetailsEntity extends PujInstitutionEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@Column(nullable = true)
	private String website;

	@XmlElement
	@Column(nullable = true)
	private String email;

	@XmlElement
	@Column(nullable = true)
	private String contact;

	@XmlElement
	@Column(nullable = true)
	private String phone;

	@XmlElement
	@OneToOne(cascade = CascadeType.ALL, optional = true)
	private PujAddressEntity address;

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public PujAddressEntity getAddress() {
		return address;
	}

	public void setAddress(PujAddressEntity address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
}
