package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujHomeworkEntity;
import com.kenai.puj.arena.model.entity.PujScoreCard;

@Local
public interface PujHomeworkFacade extends PujEntityFacade<PujHomeworkEntity> {
	PujScoreCard getScoreCard(final int id);

	Collection<PujHomeworkEntity> readAllByCompetition(int start, int max,
			String institution, String name);

	Collection<PujHomeworkEntity> readAllByCompetition(String name, int start,
			int max);

	/**
	 * Add an author to a homework. This method first lookup the author using
	 * the JPA method <em>find</em>, so if the author do not exists it will
	 * throw an IllegalArgumentException.
	 * 
	 * @param login
	 *            a login of a registered user. Despite we designed this method
	 *            to accept the roles <em>professor</em> or <em>student</em> the
	 *            system do not check the role of the author.
	 * @throws IllegalArgumentException
	 *             if there is not author with the provided login.
	 */
	void addAuthor(String login) throws IllegalArgumentException;
}