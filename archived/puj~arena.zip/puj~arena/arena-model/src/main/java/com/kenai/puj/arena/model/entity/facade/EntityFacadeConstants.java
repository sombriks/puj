package com.kenai.puj.arena.model.entity.facade;

public final class EntityFacadeConstants {
	public static final String NAMESPACE = "http://kenai.com/projects/puj/arena/entity";

	public static final String PARAM_NULL = "null";
	public static final String PARAM_START = "start";
	public static final String PARAM_MAX = "max";
	public static final String PARAM_START_DEFAULT_VALUE = "0";
	public static final String PARAM_MAX_DEFAULT_VALUE = "50";
	public static final int PAGINATION_MAX_SIZE = 50;

}
