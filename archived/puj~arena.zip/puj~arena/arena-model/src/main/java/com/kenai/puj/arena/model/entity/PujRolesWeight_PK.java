package com.kenai.puj.arena.model.entity;

import java.io.Serializable;

public class PujRolesWeight_PK implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	private String competition;

	private String role;

	public String getCompetition() {
		return competition;
	}

	public void setCompetition(String competition) {
		this.competition = competition;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
