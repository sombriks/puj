package com.kenai.puj.arena.model.entity.facade.impl;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.GeneralSecurityException;

import javax.ejb.Local;

/**
 * The confirmation of a registration is done through an URL encrypted to ensure
 * a minimum security level.
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 */
@Local
public interface URLObfuscator {
	/**
	 * Convert a response URL in a plain text.
	 * 
	 * @param baseUrl
	 * 
	 * @return a plain confirmation URL.
	 * @throws MalformedURLException
	 * @throws GeneralSecurityException
	 * @throws UnsupportedEncodingException
	 */
	URL createObfuscatedUrl(String login, String email, String baseUrl)
			throws MalformedURLException, GeneralSecurityException,
			UnsupportedEncodingException;
}
