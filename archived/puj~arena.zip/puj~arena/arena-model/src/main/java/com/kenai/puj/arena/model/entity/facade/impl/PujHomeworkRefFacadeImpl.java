package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujHomeworkRef;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkRefFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujHomeworkRefFacadeImpl extends CRUDEntityFacade<PujHomeworkRef>
		implements PujHomeworkRefFacade {
}
