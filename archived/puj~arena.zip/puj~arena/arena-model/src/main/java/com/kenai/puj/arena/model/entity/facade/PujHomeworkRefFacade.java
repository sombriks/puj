package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujHomeworkRef;

@Local
public interface PujHomeworkRefFacade extends PujEntityFacade<PujHomeworkRef> {
}