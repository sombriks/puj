package com.kenai.puj.arena.model.atom;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * 
 * The Atom entry construct is defined in section 4.1.2 of the format spec.
 * 
 * 
 * <p>
 * Java class for entryType complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="entryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice maxOccurs="unbounded">
 *         &lt;element name="author" type="{http://www.w3.org/2005/Atom}personType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="category" type="{http://www.w3.org/2005/Atom}categoryType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="content" type="{http://www.w3.org/2005/Atom}contentType" minOccurs="0"/>
 *         &lt;element name="contributor" type="{http://www.w3.org/2005/Atom}personType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2005/Atom}idType"/>
 *         &lt;element name="link" type="{http://www.w3.org/2005/Atom}linkType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="published" type="{http://www.w3.org/2005/Atom}dateTimeType" minOccurs="0"/>
 *         &lt;element name="rights" type="{http://www.w3.org/2005/Atom}textType" minOccurs="0"/>
 *         &lt;element name="source" type="{http://www.w3.org/2005/Atom}textType" minOccurs="0"/>
 *         &lt;element name="summary" type="{http://www.w3.org/2005/Atom}textType" minOccurs="0"/>
 *         &lt;element name="title" type="{http://www.w3.org/2005/Atom}textType"/>
 *         &lt;element name="updated" type="{http://www.w3.org/2005/Atom}dateTimeType"/>
 *         &lt;any/>
 *       &lt;/choice>
 *       &lt;attGroup ref="{http://www.w3.org/2005/Atom}commonAttributes"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */

@NamedQueries( { @NamedQuery(name = EntryTypeView.QUERY_CHECK_EXPIRE_DATE, query = "SELECT e FROM EntryType e WHERE e.expire >= CURRENT_DATE") })
@Entity
@XmlRootElement(name = "entry")
public class EntryTypeView extends AbstractAtomElement {
	private static final long serialVersionUID = 196919661993L;

	public static final String QUERY_CHECK_EXPIRE_DATE = "QueryCheckExpireDate";
	public static final String PRAM_CHECK_EXPIRE_DATE = "ExpireDateParam";

	@XmlTransient
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;

	@OneToOne(optional = true, cascade = CascadeType.ALL)
	@XmlElement(nillable = false, required = true, name = "title")
	private TextType title;

	@OneToOne(optional = true, cascade = CascadeType.REFRESH)
	@XmlElement(nillable = false, name = "category")
	private CategoryType category;

	@XmlElement(name = "id", nillable = true, required = false)
	@Column(nullable = true)
	private String contentId;

	@XmlElement(nillable = true, required = false)
	@OneToOne(optional = false, cascade = CascadeType.PERSIST)
	private PersonType contributor;

	@XmlElement(nillable = true, required = false)
	@OneToOne(optional = true, cascade = CascadeType.ALL)
	private LinkType link;

	@XmlTransient
	@Temporal(TemporalType.DATE)
	@Column(nullable = false, columnDefinition = "DATETIME DEFAULT '2020-1-1 00:00:00'")
	private Calendar expire = new GregorianCalendar(2020, 01, 01);

	@OneToOne(optional = true, cascade = CascadeType.ALL)
	@XmlElement(nillable = true, required = false, name = "summary")
	private TextType summary;

	@OneToOne(optional = true, cascade = CascadeType.ALL)
	@XmlElement(nillable = true, required = false, name = "rights")
	private TextType rights;

	@OneToOne(optional = true, cascade = CascadeType.ALL)
	@XmlElement(nillable = true, required = false, name = "content")
	private TextType content;

	@XmlElement(nillable = false, name = "updated", required = true)
	@XmlJavaTypeAdapter(Adapter1.class)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(columnDefinition = "timestamp not null default now()")
	private Calendar updated;

	public Calendar getUpdated() {
		return updated;
	}

	public void setUpdated(Calendar updated) {
		this.updated = updated;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TextType getSummary() {
		return summary;
	}

	public void setSummary(TextType summary) {
		this.summary = summary;
	}

	public TextType getRights() {
		return rights;
	}

	public void setRights(TextType rights) {
		this.rights = rights;
	}

	public TextType getContent() {
		return content;
	}

	public void setContent(TextType content) {
		this.content = content;
	}

	public PersonType getContributor() {
		return contributor;
	}

	public void setContributor(PersonType contributor) {
		this.contributor = contributor;
	}

	public TextType getTitle() {
		return title;
	}

	public void setTitle(TextType title) {
		this.title = title;
	}

	public CategoryType getCategory() {
		return category;
	}

	public void setCategory(CategoryType category) {
		this.category = category;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public LinkType getLink() {
		return link;
	}

	public void setLink(LinkType link) {
		this.link = link;
	}

	public Calendar getExpire() {
		return expire;
	}

	public void setExpire(Calendar expire) {
		this.expire = expire;
	}
}
