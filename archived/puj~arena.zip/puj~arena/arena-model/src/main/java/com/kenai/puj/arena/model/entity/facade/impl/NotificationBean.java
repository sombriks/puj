package com.kenai.puj.arena.model.entity.facade.impl;

import java.net.URL;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.Topic;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.NotificationFacade;
import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.model.entity.utils.JmsConstants;

/**
 * This class must be reviewed and implemented thread safe for diverse types of
 * avatars.
 * 
 * @see <a href="http://en.gravatar.com/site/implement/java">Gravatar Java
 *      code.</a>
 * 
 */
@Stateless
public class NotificationBean implements NotificationFacade {
	@Resource(mappedName = JmsConstants.PUJ_NOTIFICATION_FACTORY)
	private transient QueueConnectionFactory notificationConnectionFactory;

	@Resource(mappedName = JmsConstants.PUJ_NOTIFICATION_QUEUE)
	private transient Queue notificationQueue;

	@Resource(mappedName = JmsConstants.PUJ_NOTIFICATION_TOPIC_FACTORY)
	private transient QueueConnectionFactory topicConnectionFactory;

	@Resource(mappedName = JmsConstants.PUJ_NOTIFICATION_TOPIC)
	private transient Topic notificationTopic;

	@EJB
	private URLObfuscator urlObfuscator;

	/**
	 * Send an email to the new customer, asking him to confirm the
	 * registration.
	 * 
	 * @param confirmationBaseUrl
	 * 
	 * @param registration
	 *            the original message containing the customer information.
	 * @throws JMSException
	 *             a general messaging exception.
	 */
	public void notifyNewUser(PujUserDetailsEntity user, Properties props)
			throws JMSException {
		Connection connection = null;
		Session notificationSession = null;

		try {
			connection = notificationConnectionFactory.createConnection();
			notificationSession = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher = notificationSession
					.createProducer(notificationQueue);
			MapMessage registrationRequest = notificationSession
					.createMapMessage();

			registrationRequest.setStringProperty(RegistrationConstants.LOGIN
					.value(), user.getLogin());
			registrationRequest.setStringProperty(RegistrationConstants.NAME
					.value(), user.getName());
			registrationRequest.setStringProperty(RegistrationConstants.EMAIL
					.value(), user.getEmail());
			registrationRequest.setStringProperty(
					RegistrationConstants.REGISTRATION_MSG.value(), props
							.getProperty(RegistrationConstants.REGISTRATION_MSG
									.value()));

			try {
				URL confirmationUrl = urlObfuscator.createObfuscatedUrl(user
						.getLogin(), user.getEmail(), props
						.getProperty(RegistrationConstants.CONFIRMATION_URL
								.value()));
				registrationRequest.setStringProperty(
						RegistrationConstants.CONFIRMATION_URL.value(),
						confirmationUrl.toString());
			} catch (Exception e) {
				throw new JMSException(e.getMessage());
			}

			registrationRequest
					.setStringProperty(
							RegistrationConstants.REGISTRATION_SUBJECT.value(),
							props
									.getProperty(RegistrationConstants.REGISTRATION_SUBJECT
											.value()));
			publisher.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			publisher.send(registrationRequest);
		} finally {
			if (notificationSession != null) {
				notificationSession.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
	}

	public void postTopicMsg(Map<String, String> params) throws JMSException {
		Connection connection = null;
		Session notificationSession = null;

		try {
			connection = topicConnectionFactory.createConnection();
			notificationSession = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher = notificationSession
					.createProducer(notificationTopic);
			MapMessage topicMsg = notificationSession.createMapMessage();

			connection = topicConnectionFactory.createConnection();
			for (Map.Entry<String, String> map : params.entrySet()) {
				topicMsg.setStringProperty(map.getKey(), map.getValue());
			}
			publisher.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			publisher.send(topicMsg);
		} finally {
			if (notificationSession != null) {
				notificationSession.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
	}

}
