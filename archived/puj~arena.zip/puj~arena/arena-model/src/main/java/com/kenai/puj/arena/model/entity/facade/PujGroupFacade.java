package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujGroupEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;

/**
 * The persistence facade for Category entities.
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 */
@Local
public interface PujGroupFacade extends PujEntityFacade<PujGroupEntity> {
	enum GROUP {
		ADMIN, COORDINATOR, STAFF, STUDENT, PROFESSOR, SENIOR_PROFESSIONAL
	}

	/**
	 * Add an user to a group.
	 * 
	 * @param user
	 *            the user.
	 * @param role
	 *            the group.
	 */
	PujGroupEntity addToGroup(PujUserEntity user, PujGroupFacade.GROUP role);
}