package com.kenai.puj.arena.model.entity;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries( {
		@NamedQuery(name = PujUserDetailsEntity.READ_ALL, query = "SELECT user FROM PujUserEntity user"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_EMAIL, query = "SELECT user FROM PujUserEntity user WHERE user.email= :email"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_GROUP_ID, query = "SELECT user FROM PujUserEntity user WHERE user.role in (SELECT gr.role FROM PujGroupEntity gr WHERE gr.name= :groupId)"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_COMPETITION, query = "SELECT user FROM PujUserEntity user WHERE user IN (SELECT comp.participants from PujCompetitionDetailsEntity comp WHERE comp.name = :"
				+ PujUserDetailsEntity.PARAM_COMPETITION_NAME + ")"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_COMPETITION_AND_ROLE, query = "SELECT user FROM PujUserEntity user WHERE user.role IN (SELECT role FROM PujRoleEntity role WHERE role.name = :"
				+ PujUserDetailsEntity.PARAM_USER_ROLE
				+ ") AND user IN (SELECT comp.participants from PujCompetitionDetailsEntity comp WHERE comp.name = :"
				+ PujUserDetailsEntity.PARAM_COMPETITION_NAME + ")"),
		@NamedQuery(name = PujUserDetailsEntity.CHECK_IF_EXISTS_BY_LOGIN_OR_EMAIL, query = "SELECT user FROM PujUserEntity user WHERE user.email= :email OR user.login= :login"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_LOGIN, query = "SELECT user FROM PujUserEntity user WHERE user.login= :login"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_LOGIN_OR_EMAIL, query = "SELECT user FROM PujUserEntity user WHERE user.email= :email OR user.login= :login"),
		@NamedQuery(name = PujUserDetailsEntity.FIND_BY_LOGIN_AND_EMAIL, query = "SELECT user FROM PujUserEntity user WHERE user.email= :email AND user.login= :login") })
@XmlRootElement
@Entity
public class PujUserDetailsEntity extends PujUserEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	/**
	 * Searches for an user by his email. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of a customer</li>
	 * </ul>
	 */
	public static final String FIND_BY_EMAIL = "findByEmail";

	public static final String READ_ALL = "readAllUsers";
	public static final String ADD_ANCHOR = "addAnchor";

	/**
	 * Searches authors of a homework with a certain role.
	 * <ul>
	 * <li><code>UserEntity.PARAM_AUTHOR_ROLE</code>: the role of the authors.</li>
	 * </ul>
	 */
	public static final String HOMEWORK_AUTHORS_BY_ROLE = "homeworkAuthorsByRole";

	/**
	 * Searches all authors of a homework.
	 * <ul>
	 * <li><code>UserEntity.PARAM_AUTHOR_ROLE</code>: the role of the authors.</li>
	 * </ul>
	 */
	public static final String HOMEWORK_AUTHORS = "homeworkAuthors";

	/**
	 * Check if exists a user with the provided email or login. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_LOGIN</code>: the login of an user</li>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of an user</li>
	 * </ul>
	 */
	public static final String CHECK_IF_EXISTS_BY_LOGIN_OR_EMAIL = "checkLogiOrEmail";

	/** Homework acronym. */
	public static final String HOMEWORK_ACRONYM = "homeworkAcronym";

	/**
	 * The homework authors - usually "<em>professor</em>" or " <em>student</em>
	 * ". .
	 */
	public static final String PARAM_USER_ROLE = "authorRole";

	/**
	 * Searches for an user by his email. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of a customer</li>
	 * </ul>
	 */
	public static final String ACTIVATE_LOGIN = "activateLogin";

	/**
	 * Searches for an user by his email. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of a customer</li>
	 * </ul>
	 */
	// public static final String DEACTIVATE_LOGIN = "deactivateLogin";

	/**
	 * Searches for an user by his login. Parameter:
	 * <ul>
	 * <li><code>UserEntity.PARAM_LOGIN</code>: the login of a customer</li>
	 * </ul>
	 */
	public static final String FIND_BY_LOGIN = "findByLogin";

	public static final String FIND_BY_GROUP_ID = "findByGroupId";

	public static final String FIND_BY_COMPETITION = "findByCompetition";

	public static final String FIND_BY_COMPETITION_AND_ROLE = "findByRole";

	/**
	 * Searches for an user by his email or by his login. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_LOGIN</code>: the login of a customer</li>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of a customer</li>
	 * </ul>
	 */
	public static final String FIND_BY_LOGIN_OR_EMAIL = "findByLoginOrEmail";
	/**
	 * Searches for an user by his email or by his login. Parameters:
	 * <ul>
	 * <li><code>UserEntity.PARAM_LOGIN</code>: the login of a customer</li>
	 * <li><code>UserEntity.PARAM_EMAIL</code>: the email of a customer</li>
	 * </ul>
	 */
	public static final String FIND_BY_LOGIN_AND_EMAIL = "findByLoginAndEmail";
	/** The user's login. */
	public static final String PARAM_LOGIN = "login";
	/** The user's email. */
	public static final String PARAM_EMAIL = "email";
	/** The user's email. */
	public static final String PARAM_GROUP_ID = "groupId";

	public static final String PARAM_COMPETITION_NAME = "competitionName";

	public static final String PARAM_INSTITUTION = "institutionAcronym";

	@XmlElement(nillable = true)
	@OneToMany(orphanRemoval = true)
	@JoinTable(name = "USER_ANCHORS", joinColumns = @JoinColumn(name = "USER_ID"), inverseJoinColumns = @JoinColumn(name = "ANCHOR_ID"))
	private Collection<PujAnchorEntity> anchor;

	@XmlElement
	@Column(nullable = true)
	private String avatar;

	@XmlElement
	@Column(nullable = true)
	private String name;

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAnchor(Collection<PujAnchorEntity> anchor) {
		this.anchor = anchor;
	}

	public Collection<PujAnchorEntity> getAnchor() {
		if (anchor == null) {
			anchor = new ArrayList<PujAnchorEntity>();
		}
		return anchor;
	}
}
