package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.faces.bean.ManagedBean;

import org.eclipse.persistence.expressions.ExpressionBuilder;
import org.eclipse.persistence.jpa.JpaEntityManager;
import org.eclipse.persistence.queries.ReadAllQuery;

import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;
import com.kenai.puj.arena.model.entity.facade.PujAdvertisementFacade;

/** @see CRUDEntityFacade */
@ManagedBean
@Stateless
public class PujAdvertisementFacadeImpl extends
		CRUDEntityFacade<PujAdvertisementEntity> implements
		PujAdvertisementFacade {
	@SuppressWarnings("unchecked")
	@Override
	public Collection<PujAdvertisementEntity> getAdvertisement(String compName,
			String role, int max) {

		ExpressionBuilder advs = new ExpressionBuilder(
				PujAdvertisementEntity.class);
		ReadAllQuery databaseQuery = new ReadAllQuery(
				PujAdvertisementEntity.class, advs);
		databaseQuery.addOrdering(ExpressionBuilder.fromLiteral("RAND()",
				databaseQuery.getExpressionBuilder()));
		databaseQuery.setMaxRows(max);

		return ((JpaEntityManager) manager.getDelegate()).createQuery(
				databaseQuery).getResultList();
	}
}
