package com.kenai.puj.arena.model.entity;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
public class PujCompetitionDetailsEntity extends PujCompetitionEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "COMPETITION_PARTICIPANTS", joinColumns = @JoinColumn(name = "name"), inverseJoinColumns = @JoinColumn(name = "login"))
	private Collection<PujUserEntity> participants;

	@XmlElement(nillable = true)
	@OneToOne(optional = true)
	@JoinTable(name = "COMPETITION_CALENDAR", joinColumns = @JoinColumn(name = "name"), inverseJoinColumns = @JoinColumn(name = "phase"))
	private PujCalendarEntity calendar;

	public PujCalendarEntity getCalendar() {
		return calendar;
	}

	public void setCalendar(PujCalendarEntity calendar) {
		this.calendar = calendar;
	}

	public Collection<PujUserEntity> getParticipants() {
		return participants;
	}

	public void setParticipants(Collection<PujUserEntity> participants) {
		this.participants = participants;
	}

	@Override
	public boolean equals(Object arg0) {
		return super.equals(arg0)
				&& ((PujCompetitionDetailsEntity) arg0).getParticipants()
						.size() == this.getParticipants().size()
				&& ((PujCompetitionDetailsEntity) arg0).getCalendar().equals(
						this.getCalendar())
				&& ((PujCompetitionDetailsEntity) arg0).getParticipants()
						.containsAll(this.getParticipants());
	}

	@Override
	public int hashCode() {
		return super.hashCode()
				+ (participants == null ? 0 : participants.size());
	}
}
