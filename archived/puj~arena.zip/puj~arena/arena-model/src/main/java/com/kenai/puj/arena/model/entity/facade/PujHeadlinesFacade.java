package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujHeadlinesEntity;

/**
 * The persistence facade for {@link PujHeadlinesEntity}.
 * 
 * @author $Author$
 * @version $Rev$ ($Date$)
 */
@Local
public interface PujHeadlinesFacade extends PujEntityFacade<PujHeadlinesEntity> {
}