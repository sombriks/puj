package com.kenai.puj.arena.model.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
public class PujAddressEntity extends PujAddressRef {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@Column(unique = false)
	private String street;
	@XmlElement
	@Column(unique = false)
	private int number;
	@XmlElement
	@Column(nullable = true)
	private String complement;
	@XmlElement
	@Column(nullable = true)
	private String name;
	@XmlElement
	@Column(nullable = false)
	private String zip;
	@XmlElement
	@Column(nullable = false)
	private String state;
	@XmlElement
	@Column(nullable = false)
	private String country;
	@XmlElement
	@Column(nullable = false)
	private String city;
	@XmlElement(nillable = true)
	@OneToOne(cascade = CascadeType.ALL, optional = true)
	private PujGeoLocationEntity coordinates;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getComplement() {
		return complement;
	}

	public void setComplement(String complement) {
		this.complement = complement;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public PujGeoLocationEntity getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(PujGeoLocationEntity coordinates) {
		this.coordinates = coordinates;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
}
