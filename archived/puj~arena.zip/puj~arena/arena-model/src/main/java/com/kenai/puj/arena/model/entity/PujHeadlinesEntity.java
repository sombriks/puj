package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
@Entity
public class PujHeadlinesEntity extends PujAbstractEntity {
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public static final String FIND_AFTER_DATE = "AfterDateQuery";

	public static final String HEADLINE_TYPE = "type";

	public enum HeadlineType {
		JOB, COURSE, PRESS
	}

	@XmlTransient
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;

	@XmlTransient
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "VARCHAR(20) DEFAULT 'PRESS'")
	public PujHeadlinesEntity.HeadlineType type;

	@XmlAttribute
	@Column
	public String title;

	@XmlElement
	@Column(length = 2000)
	public String summary;

	@XmlAttribute
	@Column
	public String url;

	@XmlAttribute
	@Column
	public String thumbnail;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
