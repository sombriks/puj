package com.kenai.puj.arena.model.entity.facade;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujAnchorEntity;

@Local
public interface PujAnchorFacade extends PujEntityFacade<PujAnchorEntity> {
}