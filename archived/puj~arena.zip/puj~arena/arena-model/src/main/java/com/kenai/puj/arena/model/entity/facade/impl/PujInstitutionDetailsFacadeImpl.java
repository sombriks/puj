package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujInstitutionDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionDetailsFacade;

@Stateless
public class PujInstitutionDetailsFacadeImpl extends
		CRUDEntityFacade<PujInstitutionDetailsEntity> implements
		PujInstitutionDetailsFacade {
}
