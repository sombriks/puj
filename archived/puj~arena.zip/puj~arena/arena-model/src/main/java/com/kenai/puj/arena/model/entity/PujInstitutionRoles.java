package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@IdClass(PujInstitutionRoles_PK.class)
public class PujInstitutionRoles extends PujAbstractEntity {
	public static final String INSTITUTION_ACRONYM = "INSTITUTION_ACRONYM";
	public static final String COMPETITION_NAME = "COMPETITION_NAME";
	public static final String ROLE = "role";

	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public enum Role {
		SCHOOL, PUJ_OWNER, SPONSOR, PARTNER
	}

	@XmlAttribute
	@Enumerated(EnumType.STRING)
	@Column(name = ROLE, columnDefinition = "VARCHAR(20)")
	private PujInstitutionRoles.Role role;

	@XmlElement
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = INSTITUTION_ACRONYM, referencedColumnName = "acronym")
	private PujInstitutionEntity institution;

	@XmlElement
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = COMPETITION_NAME, referencedColumnName = "name")
	private PujCompetitionEntity competition;

	public void setInstitution(PujInstitutionEntity institution) {
		this.institution = institution;
	}

	public void setCompetition(PujCompetitionEntity competition) {
		this.competition = competition;
	}

	public PujInstitutionRoles.Role getRole() {
		return role;
	}

	public void setRole(PujInstitutionRoles.Role role) {
		this.role = role;
	}

	public PujInstitutionEntity getInstitution() {
		return institution;
	}

	public PujCompetitionEntity getCompetition() {
		return competition;
	}
}
