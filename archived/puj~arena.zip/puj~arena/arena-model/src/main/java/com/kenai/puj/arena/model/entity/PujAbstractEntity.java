package com.kenai.puj.arena.model.entity;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlType
@MappedSuperclass
public abstract class PujAbstractEntity implements Serializable {
	/** Transient serialization version UID. */
	public static final long serialVersionUID = 196919661993L;

	@Version
	@XmlAttribute
	public int version;

	public void setVersion(int version) {
		this.version = version;
	}

	public int getVersion() {
		return version;
	}
}
