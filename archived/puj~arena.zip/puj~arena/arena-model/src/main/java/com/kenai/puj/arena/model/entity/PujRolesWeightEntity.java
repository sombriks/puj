package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
@IdClass(PujRolesWeight_PK.class)
public class PujRolesWeightEntity extends PujAbstractEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public static final String COMPETITION_ID = "COMPETITION_ID";
	public static final String ROLE_ID = "ROLE_ID";

	@XmlAttribute
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = COMPETITION_ID, referencedColumnName = "name")
	private PujCompetitionEntity competition;

	@XmlElement
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = ROLE_ID, referencedColumnName = "name")
	private PujRoleEntity role;

	@Column
	private int weight;

	public PujCompetitionEntity getCompetition() {
		return competition;
	}

	public void setCompetition(PujCompetitionEntity competition) {
		this.competition = competition;
	}

	public PujRoleEntity getRole() {
		return role;
	}

	public void setRole(PujRoleEntity role) {
		this.role = role;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

}
