package com.kenai.puj.arena.model.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Groups are used to map roles their permissions (authentication).
 */
@XmlRootElement
@Entity
public class PujGroupEntity extends PujAbstractEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlAttribute
	@Id
	@Column(length = 20)
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToMany
	@JoinTable(name = "GROUP_ROLES", joinColumns = @JoinColumn(name = "name"), inverseJoinColumns = @JoinColumn(name = "role"))
	private Set<PujRoleEntity> role = new HashSet<PujRoleEntity>();

	public Set<PujRoleEntity> getRole() {
		return role;
	}

	public void setRole(Set<PujRoleEntity> role) {
		this.role = role;
	}
}
