package com.kenai.puj.arena.model.entity.facade.impl;

import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.Query;
import javax.xml.ws.WebServiceException;

import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionRoles;
import com.kenai.puj.arena.model.entity.PujUserEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionFacade;

@EJB(beanInterface = PujInstitutionFacade.class)
@Stateless
public class PujInstitutionFacadeImpl extends
		CRUDEntityFacade<PujInstitutionEntity> implements PujInstitutionFacade {

	@Override
	public void addUsers(Collection<PujUserEntity> users) {
		throw new WebServiceException("not yet implemented");
	}

	@Override
	public void removeUsers(Collection<PujUserEntity> users) {
		throw new WebServiceException("not yet implemented");
	}

	@Override
	public Collection<PujInstitutionEntity> readAllbyRole(String role,
			int start, int max) throws IllegalStateException,
			IllegalArgumentException {

		if (role == null) {
			return readAll(PujInstitutionEntity.class, 0,
					EntityFacadeConstants.PAGINATION_MAX_SIZE);
		} else {
			PujInstitutionRoles.Role key = PujInstitutionRoles.Role.valueOf(
					PujInstitutionRoles.Role.class, role);
			Query query = manager
					.createNamedQuery(PujInstitutionEntity.FIND_BY_ROLE);
			query.setParameter(PujInstitutionEntity.ROLES, key);
			query.setFirstResult(start);
			query.setMaxResults(max);
			return getResultList(query);
		}
	}

	@Override
	public boolean exists(String acronym) {
		if (acronym == null) {
			return true;
		}
		Query query = null;
		query = manager.createNamedQuery(PujInstitutionEntity.CHECK_IF_EXISTS);
		query.setParameter(PujInstitutionEntity.ACRONYM, acronym);
		return getResultList(query).size() > 0;
	}
}
