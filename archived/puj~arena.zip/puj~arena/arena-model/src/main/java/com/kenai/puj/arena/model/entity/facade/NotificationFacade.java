package com.kenai.puj.arena.model.entity.facade;

import java.util.Map;
import java.util.Properties;

import javax.ejb.Local;
import javax.jms.JMSException;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;

@Local
public interface NotificationFacade {
	void notifyNewUser(PujUserDetailsEntity user, Properties props)
			throws JMSException;

	void postTopicMsg(Map<String, String> params) throws JMSException;
}