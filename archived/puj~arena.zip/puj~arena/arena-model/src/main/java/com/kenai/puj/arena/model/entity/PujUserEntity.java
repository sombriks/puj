package com.kenai.puj.arena.model.entity;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@NamedQueries( { @NamedQuery(name = PujUserEntity.UPDATE_USER_STATUS, query = "UPDATE PujUserEntity as user SET user.status = :userStatus WHERE user.login= :"
		+ PujUserEntity.PARAM_USER_LOGIN
		+ " AND user.email= :"
		+ PujUserEntity.PARAM_USER_EMAIL) })
@XmlRootElement
@Entity
public class PujUserEntity extends PujAbstractEntity {
	public enum UserStatus {
		NEW, ACTIVE, PENDING_APPROVAL, INACTIVE, BLOCKED
	}

	public static final String UPDATE_USER_STATUS = "updateUserStatus";

	/** The user's login. */
	public static final String PARAM_USER_LOGIN = "userLogin";
	/** The user's email. */
	public static final String PARAM_USER_EMAIL = "userEmail";
	/** The user's status. */
	public static final String PARAM_USER_STATUS = "userStatus";

	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlAttribute
	@Id
	@Column(length = 20)
	private String login;

	@XmlTransient
	@Column(length = 32)
	private String password;

	@XmlTransient
	@Column(nullable = false, length = 64)
	private String email;

	@XmlTransient
	@Enumerated(EnumType.STRING)
	@Column(columnDefinition = "VARCHAR(20) DEFAULT 'NEW'")
	private PujUserEntity.UserStatus status;

	@XmlElement
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "USER_ROLES", joinColumns = @JoinColumn(name = "login"), inverseJoinColumns = @JoinColumn(name = "role"))
	private Collection<PujRoleEntity> role;

	public Collection<PujRoleEntity> getRole() {
		return role;
	}

	public void setRole(Collection<PujRoleEntity> role) {
		this.role = role;
	}

	public PujUserEntity.UserStatus getStatus() {
		return status;
	}

	public void setStatus(PujUserEntity.UserStatus status) {
		this.status = status;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
