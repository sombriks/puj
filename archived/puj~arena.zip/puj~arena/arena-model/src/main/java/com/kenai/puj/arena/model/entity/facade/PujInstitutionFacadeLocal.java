package com.kenai.puj.arena.model.entity.facade;

import java.util.Collection;

import javax.ejb.Local;

import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;

@Local
public interface PujInstitutionFacadeLocal extends
		PujEntityFacade<PujInstitutionEntity> {

	/**
	 * Adds an user to an organization. The implementation of this method is
	 * expected to establish the relationship in a more lightweight manner than
	 * loading the entities in the memory. Using a query is the expected
	 * implementation.
	 * 
	 * @param userId
	 *            the user id.
	 */
	void addUsers(Collection<PujUserEntity> users);

	/**
	 * Removes an user to the event. The implementation of this method is
	 * expected to establish the relationship in a more lightweight manner than
	 * loading the entities in the memory. Using a query is the expected
	 * implementation.
	 * 
	 * @param userId
	 *            the user id.
	 */
	void removeUsers(Collection<PujUserEntity> users);

	/**
	 * Read all institutions with a certain ROLE.
	 * 
	 * @param role
	 *            the role of the institution.
	 * @param start
	 *            the start index in the JPA pagination - it is filtered to not
	 *            be negative and not be equals or higher than the maximum
	 *            parameter.
	 * @param max
	 *            the maximum number of records to return - it is filtered to
	 *            not be more than the maximum allowed number of records.
	 * @return
	 * @throws IllegalStateException
	 *             JPA exception.
	 * @throws IllegalArgumentException
	 *             JPA exception.
	 */
	Collection<PujInstitutionEntity> readAllbyRole(String role, int start,
			int max) throws IllegalStateException, IllegalArgumentException;

	/**
	 * Check if an institution already exists in the database.
	 * 
	 * @param acronym
	 *            the institution acronym.
	 * @return if there is an institution with such acronym registered in the
	 *         database.
	 */
	boolean exists(String acronym);
}