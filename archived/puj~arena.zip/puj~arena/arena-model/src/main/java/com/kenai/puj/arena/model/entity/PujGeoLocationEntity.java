package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
public class PujGeoLocationEntity extends PujGeoLocationRef {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@Column
	private double longitude;

	@XmlElement
	@Column
	private double latitude;

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
}
