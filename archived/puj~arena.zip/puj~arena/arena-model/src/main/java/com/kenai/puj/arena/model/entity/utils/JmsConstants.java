package com.kenai.puj.arena.model.entity.utils;

public class JmsConstants {
	public static final String PUJ_REGISTRATION_FACTORY = "jms/PujRegistrationFactory";
	public static final String PUJ_REGISTRATION_QUEUE = "jms/PujRegistration";
	public static final String PUJ_NOTIFICATION_FACTORY = "jms/PujNotificationFactory";
	public static final String PUJ_NOTIFICATION_QUEUE = "jms/PujNotification";
	public static final String PUJ_NOTIFICATION_TOPIC_FACTORY = "jms/PujTopicFactory";
	public static final String PUJ_NOTIFICATION_TOPIC = "jms/PujTopic";
	public static final String PUJ_REGISTRATION_MAIL = "mail/arena";
}
