package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
public class PujEvaluationDetails extends PujEvaluation {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlElement
	@Column(length = 5000, nullable = false)
	private String text;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
