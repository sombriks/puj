package com.kenai.puj.arena.model.entity;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries( { @NamedQuery(name = PujHomeworkEntity.FIND_BY_COMPETITION, query = "SELECT homework FROM PujHomeworkEntity homework WHERE homework.competition.name=:"
		+ PujHomeworkEntity.PARAM_COMPETITION_ACRONYM) })
@XmlRootElement
@Entity
public class PujHomeworkEntity extends PujHomeworkRef {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	public static final String FIND_BY_COMPETITION = "homeworksByCompetition";
	public static final String PARAM_COMPETITION_ACRONYM = "pujAcronym";

	@XmlElement
	@Column
	private String title;

	@XmlElement
	@Column(length = 1000)
	private String summary;

	@XmlElement
	@Column(length = 1000)
	private String statement;

	@XmlElement
	@Column
	private String discipline;

	@XmlElement(nillable = true)
	@Column(nullable = true)
	private String course;

	@XmlElement
	@Column
	public int semester;

	@XmlElement
	@Column
	public String url;

	@XmlElement(nillable = true)
	@Column(nullable = true)
	public String thumbnail;

	@XmlElement(nillable = true)
	@OneToOne(optional = true)
	public PujScoreCard scoreCard;

	@XmlElement(nillable = false)
	@ManyToOne(optional = false)
	private PujInstitutionEntity school;

	/**
	 * An academic homework has at least 2 authors: the Student and his
	 * Professor. A homework may also have other authors in case of a work done
	 * by a group of students.
	 */
	@XmlElement
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "HOMEWORK_AUTHORS", joinColumns = @JoinColumn(name = "homework_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
	private Collection<PujUserDetailsEntity> author;

	public Collection<PujUserDetailsEntity> getAuthor() {
		if (author == null) {
			author = new ArrayList<PujUserDetailsEntity>();
		}
		return author;
	}

	public PujInstitutionEntity getSchool() {
		return school;
	}

	public void setSchool(PujInstitutionEntity school) {
		this.school = school;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getDiscipline() {
		return discipline;
	}

	public void setDiscipline(String discipline) {
		this.discipline = discipline;
	}

	public int getSemester() {
		return semester;
	}

	public void setSemester(int semester) {
		this.semester = semester;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public PujScoreCard getScoreCard() {
		return scoreCard;
	}

	public void setScoreCard(PujScoreCard scoreCard) {
		this.scoreCard = scoreCard;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
}
