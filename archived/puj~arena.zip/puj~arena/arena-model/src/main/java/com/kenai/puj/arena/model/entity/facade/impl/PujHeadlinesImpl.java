package com.kenai.puj.arena.model.entity.facade.impl;

import javax.ejb.Stateless;

import com.kenai.puj.arena.model.entity.PujHeadlinesEntity;
import com.kenai.puj.arena.model.entity.facade.PujHeadlinesFacade;

/** @see CRUDEntityFacade */
@Stateless
public class PujHeadlinesImpl extends CRUDEntityFacade<PujHeadlinesEntity>
		implements PujHeadlinesFacade {
}
