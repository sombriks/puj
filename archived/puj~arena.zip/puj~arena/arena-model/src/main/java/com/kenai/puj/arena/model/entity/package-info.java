@XmlSchema(namespace = "http://kenai.com/projects/puj", elementFormDefault = XmlNsForm.QUALIFIED, xmlns = { @XmlNs(prefix = "puj", namespaceURI = "http://kenai.com/projects/puj") })
@XmlAccessorType(XmlAccessType.FIELD)
package com.kenai.puj.arena.model.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

