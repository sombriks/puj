package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@Entity
public class PujHomeworkRef extends PujAbstractEntity {
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlAttribute
	@Id
	@Column(length = 12)
	public String acronym;

	public String getAcronym() {
		return acronym;
	}

	public void setAcronym(String acronym) {
		this.acronym = acronym;
	}

	@XmlElement
	@JoinColumn(insertable = false, updatable = false)
	@ManyToOne
	public PujCompetitionEntity competition;

	public PujCompetitionEntity getCompetition() {
		return competition;
	}

	public void setCompetition(PujCompetitionEntity competition) {
		this.competition = competition;
	}

}
