package com.kenai.puj.arena.model.atom.facade;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

import javax.persistence.EntityExistsException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;

import com.kenai.puj.arena.model.atom.AbstractAtomElement;

public interface PujAtomFacade<T extends AbstractAtomElement> {

	/**
	 * Allow local interfaces to do queries in the database.
	 * 
	 * @param criteria
	 *            a map between column names and its expected values. In order
	 *            to avoid <a href=
	 *            'http://www.owasp.org/index.php/Preventing_SQL_Injection_in_Ja
	 *            v a ' > S Q l injection</a>, the implementation should of this
	 *            method should apply <em>SQL escaped</em> before to submit the
	 *            query.
	 * @param queryName
	 *            the name of the query.
	 * @return the entity that matches the search criteria. If there is no
	 *         matches, a NoResultException is thrown.
	 */
	public Collection<T> findByCriteria(
			Map<String, ? extends Serializable> parameters, int start, int max)
			throws IllegalStateException, IllegalArgumentException;

	/**
	 * <strong>C</strong><font color='gray'>RUD</font> operation - inserts a new
	 * entity in the database.
	 * 
	 * @param entity
	 *            The entity to be included in the database.
	 * @throws EntityExistsException
	 *             database exception, or incompatible entity.
	 * @throws IllegalStateException
	 *             database exception, or incompatible entity.
	 * @throws IllegalArgumentException
	 *             database exception, or incompatible entity.
	 * @throws TransactionRequiredException
	 *             database exception, or incompatible entity.
	 */
	T create(T entity) throws EntityExistsException, IllegalStateException,
			IllegalArgumentException, TransactionRequiredException;

	/**
	 * <font color='gray'>C</font><strong>R</strong><font color='gray'>UD</font>
	 * operation - inserts a new entity in the database. Read all records
	 * available on database for a certain type of entity.
	 * 
	 * @return A collection of objects of type 'entityClass'
	 * @throws IllegalStateException
	 *             if called for a Java Persistence query language UPDATE or
	 *             DELETE statement. See:
	 *             http://java.sun.com/j2se/1.5/docs/api/java
	 *             /lang/IllegalStateException.html
	 * @throws IllegalArgumentException
	 *             if query string is not valid.
	 */
	Collection<T> readAll(Class<T> type, int startRow, int howMany)
			throws IllegalStateException, IllegalArgumentException;

	/**
	 * TODO: missed comments.
	 * 
	 * @param primaryKey
	 * @return an object of type T
	 * @throws Exception
	 */
	T read(Class<T> type, Object primaryKey) throws IllegalStateException,
			IllegalArgumentException;

	/**
	 * <font color='gray'>CRU</font><strong>D</strong> operation - removes an
	 * entity from the database.
	 * 
	 * @param entity
	 *            The entity to be excluded from the database.
	 * @throws Exception
	 *             database exception, or incompatible entity.
	 */
	void delete(Class<T> type, Object primaryKey) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			PersistenceException;

	void deleteAll(Collection<T> entities) throws IllegalStateException,
			IllegalArgumentException, TransactionRequiredException,
			PersistenceException;

	/**
	 * <font color='gray'>CR</font><strong>U</strong><font color='gray'>D</font>
	 * operation - merges the entity with the database one.
	 * 
	 * @param entity
	 *            The entity to be merged in the database.
	 * @throws IllegalAccessException
	 * @throws Exception
	 *             database exception, or incompatible entity.
	 */
	T update(T entity) throws IllegalStateException, IllegalArgumentException,
			TransactionRequiredException;

	/**
	 * Execute a query against the database and return the result set
	 * (eventually empty).
	 * 
	 * @param query
	 *            the named query.
	 * @return a Collection of entities (eventually empty).
	 * @throws IllegalStateException
	 * @throws IllegalArgumentException
	 */
	Collection<T> getResultList(Query query) throws IllegalStateException,
			IllegalArgumentException;

	/**
	 * Execute a query against the database and return a single result
	 * (eventually null).
	 * 
	 * @param query
	 *            the named query.
	 * @return an Entity reference (eventually null).
	 * @throws IllegalStateException
	 *             JPA exception.
	 * @throws IllegalArgumentException
	 *             JPA exception.
	 */
	T getSingleresult(Query query) throws IllegalStateException,
			IllegalArgumentException;

	/**
	 * Count how many records exists in the database. Useful for pagination.
	 * 
	 * @return the number of records of T entities in the database.
	 * @throws IllegalStateException
	 * @throws IllegalArgumentException
	 */
	long count(Class<T> type) throws IllegalStateException,
			IllegalArgumentException;

	T find(Object pk);
}
