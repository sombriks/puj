package com.kenai.puj.arena.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
public class PujCalendarEntity extends PujAbstractEntity {
	/** Serialization version. */
	@Transient
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@XmlAttribute
	@Id
	@Column(length = 12)
	private String phase;

	@XmlElement
	@Temporal(TemporalType.DATE)
	@Column(nullable = true)
	private Date start;

	@XmlElement
	@Temporal(TemporalType.DATE)
	@Column(nullable = true)
	private Date finish;

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Date getStart() {
		return new Date(start.getTime());
	}

	public void setStart(Date start) {
		this.start = new Date(start.getTime());
	}

	public Date getFinish() {
		return new Date(finish.getTime());
	}

	public void setFinish(Date finish) {
		this.finish = new Date(finish.getTime());
	}
}
