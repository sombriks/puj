package com.kenai.puj.arena.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@IdClass(PujEvaluation_PK.class)
@NamedQueries( { @NamedQuery(name = PujEvaluation.FIND_BY_COMPETITION, query = "SELECT eval FROM PujEvaluation eval WHERE eval.homework.competition.name=:"
		+ PujEvaluation.PARAM_COMPETITION_NAME) })
public class PujEvaluation extends PujAbstractEntity {
	public static final String FIND_BY_COMPETITION = "evalByCompetition";
	public static final String PARAM_COMPETITION_NAME = "name";

	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;
	public static final String HOMEWORK_ID = "HOMEWORK_ID";
	public static final String EVALUATOR_ID = "EVALUATOR_ID";

	@XmlElement
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = HOMEWORK_ID, referencedColumnName = "acronym")
	private PujHomeworkRef homework;

	public PujHomeworkRef getHomework() {
		return homework;
	}

	public void setHomework(PujHomeworkRef homework) {
		this.homework = homework;
	}

	@XmlElement
	@Id
	@ManyToOne
	@PrimaryKeyJoinColumn(name = EVALUATOR_ID, referencedColumnName = "login")
	private PujUserEntity evaluator;

	@XmlAttribute
	@Column(columnDefinition = "FLOAT UNSIGNED NOT NULL CHECK(VALUE BETWEEN 1.00 AND 10.00)")
	private float grade;

	/*
	 * @XmlAttribute
	 * 
	 * @Column(columnDefinition =
	 * "TINYINT UNSIGNED NOT NULL CHECK(WEIGHT >= 1)", nullable = false) private
	 * int weight;
	 */

	public float getGrade() {
		return grade;
	}

	public void setGrade(float grade) {
		this.grade = grade;
	}

	public PujUserEntity getEvaluator() {
		return evaluator;
	}

	public void setEvaluator(PujUserEntity evaluator) {
		this.evaluator = evaluator;
	}
}
