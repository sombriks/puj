drop table GROUPTABLE;
drop view ACTIVEUSERS;
#drop table USERTABLE;
#create table USERTABLE(login varchar(20) not null, password varchar(32) not null, email varchar(64), name varchar(60), status int not null default 5, version int not null, role_login VARCHAR(255), primary key(login)) DEFAULT CHARACTER SET utf8;
create index FK_USERTABLE_ROLE_LOGIN on USERTABLE (ROLE_LOGIN ASC);
create table GROUPTABLE(login varchar(20) not null, groupid varchar(20) not null, version int not null, primary key(login)) DEFAULT CHARACTER SET utf8;
alter table GROUPTABLE add constraint FK_USERID foreign key(login) references USERTABLE(login);
create view ACTIVEUSERS(login, password) as select login,password from arena.USERTABLE where arena.USERTABLE.status=0;



create VIEW GROUPTABLE(id INT NOT NULL AUTO_INCREMENT, login varchar(20) not null, groupid varchar(20) not null, version int not null, primary key(id)) 

as select usr.login,grp.name from USERTABLE usr, PUJGROUPENTITY grp where arena.USERTABLE.status=0;

select grp-name in (select distinct role.name from PUJUSERENTITY usr user.roles .name from  roles

select role.name rid from PUJROLEENTITY role, PUJUSERENTITY pu, USER_ROLES ur where pu.login = ur.login AND role.name=ur.role;

select name,login from GROUP_ROLES gr, USER_ROLES ur where gr.role = ur.role;


#create table USERTABLE(login varchar(20) not null, password varchar(32) not null, email varchar(64), name varchar(60), status int not null default 5, version int not null, role_login VARCHAR(255), primary key(login)) DEFAULT CHARACTER SET utf8;

create view PUJ_AUTH_GROUPTABLE(login, groupid) as select ur.login login, gr.name groupid from GROUP_ROLES gr, USER_ROLES ur where gr.role = ur.role;
create view PUJ_AUTH_USERTABLE(login, password) as select usr.login, usr.password from PUJUSERENTITY usr where usr.status = 0;

@Table(name = "GROUPTABLE")