#!/bin/bash

echo
echo "-------- Deploying DWR Web GUI to Server $GF_VERSION"
asadmin deploy --force=true --name arena-dwr target/arena-dwr*.war
echo
