package com.kenai.puj.arena.web.dwr;

import java.util.Collection;

import com.kenai.puj.arena.model.entity.PujCompetitionDetailsEntity;
import com.kenai.puj.arena.model.entity.PujHomeworkEntity;
import com.kenai.puj.arena.web.ClientBase;
import com.sun.jersey.api.client.GenericType;

/**
 * small controller to send some paged data.
 * 
 * @author leonardo
 */
public class ListHomeworks extends ClientBase {

	public Collection<PujHomeworkEntity> listHomeworks(
			PujCompetitionDetailsEntity competition, int offset, int limit) {
		Collection<PujHomeworkEntity> ret = ARENA//
				.path("homework")//
				.queryParam("competition", competition.getName())//
				// .queryParam("start", Integer.toString(offset))//
				// .queryParam("max", Integer.toString(limit))//
				.get(new GenericType<Collection<PujHomeworkEntity>>() {
				});

		// works nicely, ;)
		// for (PujHomeworkEntity homework : ret) {
		// for (PujUserDetailsEntity user : homework.getAuthor()) {
		// for (PujAnchorEntity anchor : user.getAnchor()) {
		// if (anchor.getAnchorType().equals(
		// PujAnchorEntity.Type.AVATAR)) {
		//
		// String avatarUrl = anchor.getContent();
		// System.out.println(avatarUrl);
		// }
		// }
		// }
		// }
		return ret;
	}
}
