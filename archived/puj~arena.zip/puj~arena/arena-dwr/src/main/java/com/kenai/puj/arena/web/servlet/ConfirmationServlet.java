/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenai.puj.arena.web.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status.Family;

import com.kenai.puj.arena.web.ClientBase;
import com.sun.jersey.api.client.ClientResponse;

/**
 * servlet to confirm registrations
 * 
 * @author leonardo
 */
public class ConfirmationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Handles the HTTP <code>GET</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doGet(final HttpServletRequest request,
			final HttpServletResponse response) throws ServletException,
			IOException {
		try {

			String enc = request.getCharacterEncoding();
			if (enc == null) {
				enc = "UTF-8";
			}
			ClientResponse httpResponse = new ClientBase().ARENA.path("user")
					.type(MediaType.APPLICATION_FORM_URLENCODED).post(
							ClientResponse.class,
							"key="
									+ URLEncoder.encode(request
											.getParameter("key"), enc));
			ClientResponse.Status status = httpResponse
					.getClientResponseStatus();
			if (!Family.SUCCESSFUL.equals(status.getFamily())) {
				throw new Exception(status.getReasonPhrase());
			}

			request.getRequestDispatcher("registersuccess.jsp")//
					.forward(request, response);
		} catch (Exception ex) {
			request.setAttribute("exception", ex);
			request.getRequestDispatcher("registerproblem.jsp")//
					.forward(request, response);
		}
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Servlet used to confirm puj participants";
	}
}
