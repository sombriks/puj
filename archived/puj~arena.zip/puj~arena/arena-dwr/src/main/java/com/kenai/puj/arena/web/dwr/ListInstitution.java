/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenai.puj.arena.web.dwr;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.web.ClientBase;
import com.sun.jersey.api.client.GenericType;

/**
 * 
 * @author leonardo
 */
public class ListInstitution extends ClientBase {

	public Collection<PujInstitutionEntity> listInstitution() {
		Collection<PujInstitutionEntity> insts = ARENA.path("institution")
				.queryParam("role", "PUJ_OWNER").get(
						new GenericType<Collection<PujInstitutionEntity>>() {
						});

		List<PujInstitutionEntity> retr = new LinkedList<PujInstitutionEntity>();
		PujInstitutionEntity e = new PujInstitutionEntity();
		e.setName("-- select institution --");
		e.setAcronym("");
		retr.add(e);
		retr.addAll(insts);
		return retr;

	}
}
