package com.kenai.puj.arena.web.dwr;

import com.kenai.puj.arena.web.ClientBase;

/**
 * i am not about exceptions, that thing is delayed already.
 * 
 * @author sombriks
 * 
 */
public class Login extends ClientBase {

	private boolean logged;

	public void doLogin(String uname, String pwd) throws Exception {
		if (!uname.equals(pwd))
			throw new Exception("wrong username or password");
		logged = uname.equals(pwd);
	}

	public void doLogout() throws Exception {
		if (logged == false)
			throw new Exception("Not logged");
	}
}
