/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenai.puj.arena.web.dwr;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status.Family;

import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.web.ClientBase;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.representation.Form;

/**
 * 
 * @author leonardo
 */
public class RegisterUser extends ClientBase {

	public void verifyAvailability(String login) throws Exception {
		try {
			ARENA.path("user").path(login).get(PujUserDetailsEntity.class);
			// it exists, throw the exception
			throw new Exception("login '" + login + "' already used");
		} catch (WebApplicationException e) {
			// silent death.
			// e.printStackTrace();//XXX log instead
			throw new Exception("error verifying login '" + login
					+ "'; try another one");
		} catch (UniformInterfaceException e) {
			if (204 != e.getResponse().getStatus())// not found is ok
			{
				throw e;
			}
		}
	}

	public void tryRegister(PujUserDetailsEntity newUser) throws Exception {
		Form formData = new Form();
		formData.add(RegistrationConstants.NAME.value(), newUser.getName());
		formData.add(RegistrationConstants.PASSWORD.value(), newUser
				.getPassword());

		formData.add(RegistrationConstants.LOGIN.value(), newUser.getLogin());
		formData.add(RegistrationConstants.EMAIL.value(), newUser.getEmail());
		// XXX find a way to get internet name of the machine
		formData.add(RegistrationConstants.CONFIRMATION_URL.value(),
				"http://fgaucho.dyndns.org:8080/arena-dwr/confirm");
		// Finish it later
		ClientResponse resp = ARENA.path("user")//
				.type("application/x-www-form-urlencoded")//
				.post(ClientResponse.class, formData);
		Status status = resp.getClientResponseStatus();
		if (!Family.SUCCESSFUL.equals(status.getFamily()))
			throw new Exception(status.getReasonPhrase());
		// XXX handle the confirmation url
	}
}
