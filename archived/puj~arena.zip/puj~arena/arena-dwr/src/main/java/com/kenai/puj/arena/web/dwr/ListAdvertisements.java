/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenai.puj.arena.web.dwr;

import com.kenai.puj.arena.web.ClientBase;

/**
 * 
 */
public class ListAdvertisements extends ClientBase {

	/**
	 * TODO: join all rpc package on a single front.
	 */
	// public Collection<PujAdvertisementEntity> listAds(String competitionName,
	// String role) {
	// return ARENA.path("ads").queryParam("role", role).queryParam("comp",
	// competitionName).get(
	// new GenericType<Collection<PujAdvertisementEntity>>() {
	// });
	// }
	/*
	 * sadly dwr have issues with method overload.
	 */

	public String listAds() {
		return ARENA.path("ads").path("html").get(String.class);
	}
}
