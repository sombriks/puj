/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kenai.puj.arena.web;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

/**
 * 
 * @author leonardo
 */
public class ClientBase {

	// TODO allow it to be configured on some other way.
	private static final String BASE_URI = "http://localhost:8080/arena-http";
	// private static final String BaseURI =
	// "http://fgaucho.dyndns.org:8080/arena-http";
	public final WebResource ARENA;

	public ClientBase(String serviceUri) {
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		ARENA = client.resource(serviceUri);
	}

	public ClientBase() {
		this(BASE_URI);
	}
}
