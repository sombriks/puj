/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenai.puj.arena.web.dwr;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.kenai.puj.arena.model.entity.PujCompetitionDetailsEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionDetailsEntity;
import com.kenai.puj.arena.model.entity.PujLinkEntity;
import com.kenai.puj.arena.web.ClientBase;
import com.sun.jersey.api.client.GenericType;

/**
 * 
 * @author leonardo
 */
public class ListCompetitions extends ClientBase {

	public Collection<PujCompetitionDetailsEntity> listCompetitions(
			PujInstitutionDetailsEntity institution) {
		List<PujCompetitionDetailsEntity> lista = new LinkedList<PujCompetitionDetailsEntity>();

		Collection<PujCompetitionDetailsEntity> ret = new ArrayList<PujCompetitionDetailsEntity>();
		for (PujLinkEntity link : institution.getLinks()) {
			if (link.getRel().equalsIgnoreCase("details")) {
				try {
					ret = ARENA
							.uri(URI.create(link.getUri()))
							.get(
									new GenericType<Collection<PujCompetitionDetailsEntity>>() {
									});
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage());
				}
			}
		}
		PujCompetitionDetailsEntity empty = new PujCompetitionDetailsEntity();
		empty.setName("-- select competition --");
		lista.add(empty);
		lista.addAll(ret);
		return lista;
	}
}
