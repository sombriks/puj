function loadregister() {
	function Form() {
		var self = this;// HACK

		// inputs
		var login = document.getElementById("login");// XXX change to $()
		// when we insert DWR
		// there.
		var senha = document.getElementById("senha");
		var confirmasenha = document.getElementById("confirmasenha");
		var nome = document.getElementById("nome");
		var email = document.getElementById("email");

		// buttons
		var verificalogin = document.getElementById("verificalogin");
		var ok = document.getElementById("ok");

		// message spans
		var disponibilidade = new SpanStatus(document
				.getElementById("disponibilidade"));
		var forcasenha = new SpanStatus(document.getElementById("forcasenha"));
		var senhasbatem = new SpanStatus(document.getElementById("senhasbatem"));

		function limpar() {
			login.value = "";
			senha.value = "";
			confirmasenha.value = "";
			nome.value = "";
			email.value = "";
			disponibilidade.clear();
			forcasenha.clear();
			senhasbatem.clear();
		}

		function validate() {
			if (login.value == "")
				throw new Error("Invalid Login");
			if (senha.value == "")
				throw new Error("Invalid Password");
			if (nome.value == "")
				throw new Error("Invalid Name");
			if (email.value == "")
				throw new Error("Invalid Email");
		}
		// making limpar public too (also called 'privileged')
		this.limpar = limpar;

		login.onblur = function() {
			login.value = login.value.trim();
		};

		verificalogin.onclick = function() {
			if ("" != login.value) {
				disponibilidade.setWarning("verifying...");
				RegisterUser.verifyAvailability(login.value, {
					callback : function() {
						disponibilidade.setMessage("available");
					},
					errorHandler : function(e) {
						// console.debug(e);
					disponibilidade.setError(e);
				}
				});
			}
		};

		this.pwdStrength = function() {
			// TODO something with regex to improve it.
			var x = senha.value.length;
			if (x < 3)
				forcasenha.clear();
			if (x >= 3 && x <= 6)
				forcasenha.setWarning("weak password");
			if (x > 6)
				forcasenha.setMessage("strong password :P");
		};

		senha.onkeyup = this.pwdStrength;

		this.pwdMatches = function() {
			if (confirmasenha.value.length > 4 || senha.value.length > 4) {
				if (senha.value == confirmasenha.value)
					senhasbatem.setMessage("passwords matches");
				else
					senhasbatem.setError("passwords does not matches");
			} else
				senhasbatem.clear();
		};

		senha.onblur = function() {
			// Form.this.pwdMatches();//works only on firefox, not in IE
			// Form.this.pwdStrength();
			self.pwdMatches();
			self.pwdStrength();
		};

		confirmasenha.onblur = this.pwdMatches;

		this.sendForm = function() {
			try {
				validate();
				var newuser = {
					"login" : login.value,
					"name" : nome.value,
					"password" : senha.value,
					"email" : email.value
				};
				RegisterUser.tryRegister(newuser, {
					callback : function() {
						alert("done! plase confirm your email later");
						limpar();
					},
					errorHandler : function(e) {
						// for(var x in e)
					// alert("name: "+x+" value: "+e[x]);
					alert(e);
				}
				});
			} catch (e) {
				alert(e.message);
			}
		};

		ok.onclick = this.sendForm;
	}

	// registering it under an well-know context
	document.formRegister = new Form();
}
