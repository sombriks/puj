function loadhomeworkdetails(){
    
}