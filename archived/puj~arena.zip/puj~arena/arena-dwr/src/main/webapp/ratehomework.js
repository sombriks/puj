
function loadratehomework(){
    
}