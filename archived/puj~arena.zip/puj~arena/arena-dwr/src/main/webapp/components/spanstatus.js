/**
 * Small decorator to make a span some kind of message holder
 * 
 * 
 * such thing of class aren't "hot" anymore, :/
 * 
 * i need something more event-based, filled with notification things, something
 * better, stronger, faster, :)
 * 
 */
function SpanStatus(elem, mess, warn, err) {

	var lastmessage = "";
	if (mess) {
		lastmessage = mess;
	}

	var lastwarning = "";
	if (warn) {
		lastwarning = warn;
	}

	var lasterror = "";
	if (err) {
		lasterror = err;
	}

	this.setMessage = function(msg) {
		if (msg) {
			lastmessage = msg;
		}
		elem.style.backgroundColor = "lime";
		elem.innerHTML = lastmessage;
	};

	this.setWarning = function(msg) {
		if (msg) {
			lastwarning = msg;
		}
		elem.style.backgroundColor = "yellow";
		elem.innerHTML = lastwarning;

	};

	this.setError = function(msg) {
		if (msg) {
			lasterror = msg;
		}
		elem.style.backgroundColor = "red";
		elem.innerHTML = lasterror;
	};

	this.clear = function() {
		elem.style.backgroundColor = "";
		elem.innerHTML = "";
	};
}
