/* 
 * runner will execute some work on a background thread. Or something like this.
 *
 * you need at least to pass inside object parameter a run method.
 *
 * if none specified, a delay of 100ms will be used.
 *
 * then you can use start/stop methods and be wise using it.
 * 
 */
function Runner(oparam) {
	if (!oparam) {
		throw new Error("must pass an object parameter");
	}

	var delay = 100;
	if (oparam.delay) {
		delay = oparam.delay;
	}

	if (!oparam.run) {
		throw new Error("mus pass a function uder the run name parameter");
	}

	var running = false;

	function inloop() {
		if (running) {
			oparam.run();
			setTimeout(inloop, delay);
		}
	}

	this.start = function() {
		running = true;
		inloop();
	};

	this.stop = function() {
		running = true;
	};

	this.delay = function(milis) {
		delay = milis;
	};
}
