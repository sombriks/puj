/* 
 * Here we put the nasty tricks to still support ulgy browsers.
 *
 * TODO add some "go download firefox" in the index, ;)
 */

/* creating the attachEvent stinkyness */
try{
    Element.prototype.attachEvent=function(evtype,fnc){
        evtype = evtype.replace(/on/,"");
        this.addEventListener(evtype, fnc, true);
    };
}catch(e){
    //if we came here we're in IE so no need to create attachEvent. it's already
    //there. 
}

