function HomeworkRow(clonedNode, data) {

	clonedNode.id += new Date().getTime();
	clonedNode.style.display = "";

	// gravatar or something like
	var thumbnail = clonedNode.getElementsByTagName("img")[0];
	var studentAvatar = clonedNode.getElementsByTagName("img")[1];
	var professorAvatar = clonedNode.getElementsByTagName("img")[2];
	var faculty = clonedNode.getElementsByTagName("img")[3];

	// title
	var x = clonedNode.getElementsByTagName("span")[0];
	x.innerHTML = data.title;
	thumbnail.title = data.title;
	x = clonedNode.getElementsByTagName("a")[0];
	x.href = data.url;

	// author
	x = clonedNode.getElementsByTagName("span")[1];
	var i = data.author.length;
	if (i > 0)
		x.innerHTML = "";
	while (i-- > 0) {// Let's be brute now, }:[
		var link = document.createElement("a");
		link.href = "viewusers.jsp?login=" + data.author[i].login;
		link.innerHTML = data.author[i].name;
		link.title = data.author[i].role[0].name

		if ("" != data.author[i].avatar) {
			if (link.title == "STUDENT") {
				studentAvatar.src = data.author[i].avatar + "?s=82&r=r"; /* "?s=82&d=wavatar"; */
				studentAvatar.title = data.author[i].name;
			} else if (link.title == "PROFESSOR") {
				professorAvatar.src = data.author[i].avatar + "?s=40&r=r"; /* "?s=40&d=identicon"; */
				professorAvatar.title = data.author[i].login;
			}
		} else {
			professorAvatar.src = "http://www.gravatar.com/avatar/1.jpg?s=40";
		}

		x.appendChild(link);
		if (i == 1)
			link = document.createTextNode(" e ");
		else if (i > 1)
			link = document.createTextNode(", ");
		x.appendChild(link);
	}

	// semester
	x = clonedNode.getElementsByTagName("span")[2];
	x.innerHTML = data.semester;

	// discipline
	x = clonedNode.getElementsByTagName("span")[3];
	if ("" != data.discipline)
		x.innerHTML = data.discipline;

	// course
	x = clonedNode.getElementsByTagName("span")[4];
	if ("" != data.course)
		x.innerHTML = data.course + ", ";

	// faculty
	x = clonedNode.getElementsByTagName("span")[5];
	if ("" != data.school.name) {
		x.innerHTML = data.school.name;
		faculty.title = data.school.name;

		if ("" != data.school.logo) {
			faculty.src = data.school.logo;
		}
	}

	// summary / statement
	x = clonedNode.getElementsByTagName("p")[0];
	if ("" != data.summary)
		x.innerHTML = data.summary;
	else if ("" != data.statement)
		x.innerHTML = data.statement;

	if (data.thumbnail) {
		thumbnail.src = data.thumbnail;
	}

	if (data.school.thumbnail) {
		faculty.src = data.school.thumbnail;
	}

	// url -- moved to here because the author name links being created
	// XXX in long term and layout template variatons such dyamic element
	// creation ca crack that logic. for now we'll just push dow the steps
	// wich creates dynamic elements.
	// /x = clonedNode.getElementsByTagName("a")[0];
	// x.href=data.url;

	// x.innerHTML=data.author[0].name;//FIXME need to became a list of links

	return clonedNode;
}
