

/**
 * For instance this is a really limited and specific version.
 * 
 * it uses some capabilities from DWR's util.js
 *
 * now let's pretend some javadoc, :]
 *
 * @param table
 *      our well-know table containing 2 buttons, 2 images and 1 tbody.
 *
 * @param button
 *      a button that must contain an img inside.
 *
 * @param rowTemplate
 *      our row prototype for retrieved server data.
 *
 */
function TableProjects(table,button,rowTemplate){
	
    var list = [];//here we'll cache some data
	
    //note that it only works because we know the internal table layout.
    var tbody = table.getElementsByTagName("tbody")[0];

    var img = button.getElementsByTagName("img")[0];
    
    //for the sort button
    var dirstud = false;
    
    //internal helper to sane our data
    function update(){
        dwr.util.removeAllRows(tbody);
        dwr.util.addRows(tbody,list,model,{            //special for coloured lines
            rowCreator:function(ops){
                var tr = document.createElement("tr");
                tr.className = ops.rowIndex % 2 == 0 ? "even" : "";
                return tr;
            }
        });
    }

    //it works like a columnmodel.
    var model = [];
    model[0] = function (data){
        return new HomeworkRow(rowTemplate.cloneNode(true), data);
    }

    button.onclick = function(){
        dirstud = !dirstud;
        list = list.sort(function(a,b){
            var r = a.title > b.title;
            return r ? dirstud ? 1 : -1 : dirstud ? -1 : 1;
        });
        setTimeout(update,10);//avoid bad updates on big lists
        img.src = dirstud ? "img/up.png" : "img/down.png";
        img.alt = dirstud ? "up" : "down";
    };

    //public method
    this.listar=function(competition){
        ListHomeworks.listHomeworks(competition,0,10,{
            callback:function(retr){
                list = retr;
                update();
            }
        });
    };		
}