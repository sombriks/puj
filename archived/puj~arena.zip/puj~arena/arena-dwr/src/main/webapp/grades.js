function showGrades() {
	document.getElementById('center').innerHTML = "Your Content Here!<br><b>HTML Allowed!</b>";
}
