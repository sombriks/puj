/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function loadhomeworks(){
    var tabela = new TableProjects(document.getElementById("tbprojects"),document.getElementById("bsort"),document.getElementById("homeworkTemplate"));
    var institution = document.getElementById("institution");
    var competition = document.getElementById("competition");
    var institutions = [];
    var competitions = [];

    function listcomps(){
        ListCompetitions.listCompetitions(institutions[institution.selectedIndex],{
            callback:function(ret){
                competitions = ret;
                dwr.util.removeAllOptions(competition);
                dwr.util.addOptions(competition,competitions,"name","name");
            }
        });
    }

    institution.onchange=function(){
        listcomps();
    };

    competition.onchange=function(){
        var inst = institutions[institution.selectedIndex];
        var comp = competitions[competition.selectedIndex];
        tabela.listar(comp);
    };

    dwr.engine.beginBatch();
    
    //load the institution combo imediately
    ListInstitution.listInstitution({
        callback:function(ret){
            institutions = ret;
            dwr.util.removeAllOptions(institution);
            dwr.util.addOptions(institution,institutions,"acronym","name");
        }
    });
    dwr.engine.endBatch();
}