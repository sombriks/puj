package com.kenai.puj.arena.http;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.ws.WebServiceException;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujHomeworkEntity;
import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkFacade;
import com.kenai.puj.arena.model.entity.facade.PujUserDetailsFacade;
import com.sun.jersey.api.json.JSONWithPadding;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataParam;

@Path("homework")
@ManagedBean
public class PujHomeworkResource {
	@EJB
	private PujHomeworkFacade facade;

	@EJB
	private PujUserDetailsFacade userFacade;
	@EJB
	private PujCompetitionFacade competitionFacade;

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujHomeworkEntity> readAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("acronym") String acronym,
			@QueryParam("title") String title,
			@QueryParam("institution") String institution,
			@QueryParam("competition") String competition) {
		Map<String, Serializable> parameters = new ConcurrentHashMap<String, Serializable>();
		if (acronym != null) {
			parameters.put("acronym", acronym);
		}
		if (title != null) {
			parameters.put("title", title);
		}
		if (institution != null) {
			try {
				parameters.put("institution", institution);
			} catch (Exception error) {
				return new ArrayList<PujHomeworkEntity>();
			}
		}
		if (competition != null) {
			try {
				parameters.put("competition", competitionFacade.read(
						PujCompetitionEntity.class, competition));
			} catch (Exception error) {
				return new ArrayList<PujHomeworkEntity>();
			}
		}

		return facade.findByCriteria(parameters, start, max);
	}

	@GET
	@Path("jsonp")
	@Produces( { "application/x-javascript", MediaType.APPLICATION_JSON,
			MediaType.APPLICATION_XML })
	public JSONWithPadding readAllP(
			@QueryParam("jsoncallback") @DefaultValue("fn") String callback,
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("acronym") String acronym,
			@QueryParam("title") String title,
			@QueryParam("institution") String institution,
			@QueryParam("competition") String competition) {
		Collection<PujHomeworkEntity> competitions = readAll(start, max,
				acronym, title, institution, competition);
		return new JSONWithPadding(
				new GenericEntity<Collection<PujHomeworkEntity>>(competitions) {
				}, callback);
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{id}")
	public PujHomeworkEntity read(@PathParam("id") String id) {
		return facade.read(PujHomeworkEntity.class, id);
	}

	@DELETE
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{id}")
	public void delete(@PathParam("puj") String name, @PathParam("id") String id) {
		facade.delete(PujHomeworkEntity.class, id);
	}

	/**
	 * <code>curl -v -H "Accept: application/json" -H "Content-Type: application/json" -X POST http://fgaucho.dyndns.org:8080/arena-http/PUJCE-08/homework/teste</code>
	 * 
	 * @param name
	 * @param acronym
	 * @return
	 */
	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{acronym}")
	public PujHomeworkEntity create(@PathParam("puj") String name,
			@PathParam("acronym") String acronym) {
		throw new WebServiceException("not yet implemented");
		/*
		 * String login = security.getUserPrincipal().getName();
		 * PujUserDetailsEntity user =
		 * userFacade.read(PujUserDetailsEntity.class, login); PujHomeworkEntity
		 * entity = new PujHomeworkEntity(); entity.setAcronym(acronym);
		 * entity.getAuthor().add(user); return facade.create(entity);
		 */
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{acronym}/author")
	public Collection<PujUserDetailsEntity> readHomeworkStudents(
			@PathParam("acronym") String homeworkAcronym,
			@PathParam("puj") String pujName, @QueryParam("role") String role) {
		return userFacade.readHomeworkAuthors(pujName, homeworkAcronym, role);
	}

	/** ------------ homework attachment --------------- */

	@POST
	@Path("{acronym}/file")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadAttachment(
			@FormDataParam("file") List<FormDataBodyPart> parts,
			@FormDataParam("submit") FormDataBodyPart submit)
			throws IOException, ParseException {

		System.out.println("XXXX: " + submit.getMediaType());
		System.out.println("XXXX: "
				+ submit.getHeaders().getFirst("Content-Type"));

		for (FormDataBodyPart bp : parts) {
			System.out.println(bp.getMediaType());
			System.out.println(bp.getHeaders().get("Content-Disposition"));
			System.out.println(bp.getParameterizedHeaders().getFirst(
					"Content-Disposition").getParameters().get("name"));
			bp.cleanup();
		}

		return Response.ok("file deleted").build();
	}

	@GET
	@Path("{acronym}/file")
	public byte[] downloadAttachment() {
		throw new WebServiceException("not yet implemented");
	}

	@DELETE
	@Path("{acronym}/file")
	public Response deleteAttachment() {
		return Response.ok("file deleted").build();
	}
}