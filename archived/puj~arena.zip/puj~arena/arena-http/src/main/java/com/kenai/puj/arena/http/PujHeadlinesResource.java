package com.kenai.puj.arena.http;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.kenai.puj.arena.model.entity.PujHeadlinesEntity;
import com.kenai.puj.arena.model.entity.PujHeadlinesEntity.HeadlineType;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujHeadlinesFacade;

@Path("headline")
@ManagedBean
public class PujHeadlinesResource {
	@EJB
	private PujHeadlinesFacade facade;

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujHeadlinesEntity> readAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("type") String type) {
		Map<String, Serializable> parameters = new ConcurrentHashMap<String, Serializable>();
		if (type != null) {
			HeadlineType hltype = PujHeadlinesEntity.HeadlineType.valueOf(type);
			if (hltype != null) {
				parameters.put(PujHeadlinesEntity.HEADLINE_TYPE, hltype);
			}
		}

		return facade.findByCriteria(parameters, start, max);
	}
}