package com.kenai.puj.arena.http;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import com.kenai.puj.arena.model.atom.CategoryType;
import com.kenai.puj.arena.model.atom.DateTimeType;
import com.kenai.puj.arena.model.atom.EntryType;
import com.kenai.puj.arena.model.atom.Feed;
import com.kenai.puj.arena.model.atom.IdType;
import com.kenai.puj.arena.model.atom.LinkType;
import com.kenai.puj.arena.model.atom.PersonType;
import com.kenai.puj.arena.model.atom.TextType;
import com.kenai.puj.arena.model.atom.facade.PujAtomCategoryFacade;
import com.kenai.puj.arena.model.atom.facade.PujAtomEntryFacade;
import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujUserDetailsFacade;
import com.sun.servicetag.UnauthorizedAccessException;

/**
 * @see <a href="http://www.atomenabled.org/developers/syndication/">atom
 *      format</a>
 * @see <a href="http://validator.w3.org/feed/">validate</a>
 * @author fgaucho
 * 
 */
@Path("atom")
@ManagedBean
public class PujAtomResource {
	@EJB
	private PujAtomEntryFacade facade;

	@EJB
	private PujUserDetailsFacade userFacade;

	@EJB
	private PujAtomCategoryFacade categoryFacade;

	@GET
	@Produces(MediaType.APPLICATION_ATOM_XML)
	public Feed catalog(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max) {
		Feed feed = createAtomFeed(categoryFacade.find("catalog"));
		Map<String, Serializable> parameters = new HashMap<String, Serializable>();
		CategoryType cat = categoryFacade.find("catalog");
		if (cat != null) {
			parameters.put("category", cat);
			feed.getEntries().addAll(
					facade.findByCriteria(parameters, start, max));
		}

		return feed;
	}

	@GET
	@Produces(MediaType.APPLICATION_ATOM_XML)
	@Path("{category}")
	public Feed readAll(
			@PathParam("category") String category,
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max) {
		Map<String, Serializable> parameters = new HashMap<String, Serializable>();
		CategoryType cat = categoryFacade.find(category);
		Feed feed = null;
		LinkType link = new LinkType();
		link.setRel("self");
		link.setHreflang("pt");
		if (cat != null) {
			feed = createAtomFeed(cat);
			link.setHref("http://fgaucho.dyndns.org:8080/arena-http/atom/"
					+ cat.getTerm());
			parameters.put("category", cat);
			feed.getEntries().addAll(
					facade.findByCriteria(parameters, start, max));
		} else {
			feed = catalog(0, EntityFacadeConstants.PAGINATION_MAX_SIZE);
			link
					.setHref("http://fgaucho.dyndns.org:8080/arena-http/atom/catalog");
		}
		feed.setLink(link);
		return feed;
	}

	@PUT
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public EntryType update(EntryType entity) {
		return facade.update(entity);
	}

	@POST
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{category}")
	public EntryType create(@Context SecurityContext security,
			@PathParam("category") String category, EntryType entry) {
		if (security == null) {
			throw new UnauthorizedAccessException("user unknown");
		}

		CategoryType cat = categoryFacade.find(category);
		entry.setCategory(cat);

		PujUserDetailsEntity user = userFacade.find(security.getUserPrincipal()
				.getName());
		PersonType person = new PersonType();
		person.setEmail(user.getEmail());
		person.setName(user.getName());
		person.setUri(user.getAvatar());
		entry.setContributor(person);

		return facade.create(entry);
	}

	private Feed createAtomFeed(CategoryType category) {
		Feed atomFeed = new Feed();

		// author.
		PersonType author = new PersonType();
		author.setEmail("fgaucho@gmail.com");
		author.setName("Arena PUJ");
		author.setUri("http://kenai.com/projects/puj/pages/Home");
		atomFeed.setAuthor(author);

		DateTimeType updated = new DateTimeType();
		updated.setValue(Calendar.getInstance(TimeZone.getDefault()));
		atomFeed.setUpdated(updated);

		// Title
		TextType title = new TextType();
		title.setContent("Arena PUJ " + category.getTerm());
		title.setType("text");
		atomFeed.setTitle(title);

		// Subtitle
		TextType subtitle = new TextType();
		subtitle.setContent(category.getLabel());
		subtitle.setType("text");
		atomFeed.setSubtitle(subtitle);

		TextType rights = new TextType();
		rights.setContent("2009-2010 (R) Arena PUJ");
		rights.setType("text");
		atomFeed.setRights(rights);

		atomFeed
				.setLogoUrl("http://kenai.com/attachments/wiki_images/puj/logo.png");

		// Fake Feed ID
		IdType id = new IdType();
		id.setValue("http://kenai.com/projects/puj");
		atomFeed.setContentId(id);

		LinkType link = new LinkType();
		link.setHref("http://fgaucho.dyndns.org:8080/arena-http/atom");
		link.setHreflang("pt");
		link.setRel("self");
		atomFeed.setLink(link);

		return atomFeed;
	}
}