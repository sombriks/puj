package com.kenai.puj.arena.http;

import java.util.Collection;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.kenai.puj.arena.model.entity.PujGroupEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujGroupFacade;

@Path("group")
@ManagedBean
public class PujGroupResource {

	@EJB
	private PujGroupFacade facade;

	@PUT
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujGroupEntity insert(PujGroupEntity entity) {
		return facade.create(entity);
	}

	@POST
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujGroupEntity update(PujGroupEntity entity) {
		return facade.update(entity);
	}

	/*
	 * @GET
	 * 
	 * @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	 * 
	 * @Path("{id}") public PujGroupEntity select(@PathParam("id") String login)
	 * { return facade.read(PujGroupEntity.class, (Object) login); }
	 */

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujGroupEntity> selectAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max) {
		return facade.readAll(PujGroupEntity.class, start, max);
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Path("count")
	public String count() {
		return Long.toString(facade.count(PujGroupEntity.class));
	}
}