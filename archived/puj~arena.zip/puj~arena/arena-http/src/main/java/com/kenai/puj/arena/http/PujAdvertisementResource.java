package com.kenai.puj.arena.http;

import java.util.Collection;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;

import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujAdvertisementFacade;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionFacade;
import com.sun.jersey.api.json.JSONWithPadding;

// 
// curl -H "Accept:application/json" -X GET http://fgaucho.dyndns.org:8080/arena-http/institution/ivia

@Path("ads")
@ManagedBean
public class PujAdvertisementResource {
	@EJB
	private PujAdvertisementFacade adsFacade;
	@EJB
	private PujInstitutionFacade instFacade;

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujAdvertisementEntity> selectAllByRole(
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("role") String role,
			@QueryParam("comp") String competition) {
		return adsFacade.getAdvertisement(competition, role, max);
	}

	@GET
	@Path("jsonp")
	@Produces( { "application/x-javascript", MediaType.APPLICATION_JSON,
			MediaType.APPLICATION_XML })
	public JSONWithPadding selectAllByRoleP(
			@QueryParam("jsoncallback") @DefaultValue("loadAds") String callback,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("role") String role,
			@QueryParam("comp") String competition) {

		return new JSONWithPadding(
				new GenericEntity<Collection<PujAdvertisementEntity>>(adsFacade
						.getAdvertisement(competition, role, max)) {
				}, callback);

	}

	@GET
	@Path("html")
	@Produces( { MediaType.TEXT_HTML })
	public String selectAllHtmlByRole(@QueryParam("role") String role) {
		Collection<PujAdvertisementEntity> advSet = adsFacade.getAdvertisement(
				null, role, EntityFacadeConstants.PAGINATION_MAX_SIZE);
		StringBuffer buffer = new StringBuffer();
		// buffer.append("<ul id=\"adv\" class=\"advList\">");
		int i = 0;
		for (PujAdvertisementEntity adv : advSet) {
			buffer.append("<li><a target='ads" + i++ + "' href='"
					+ adv.getUrl() + "'><img alt='ads' src='"
					+ adv.getThumbnail() + "'/></a></li>");
		}
		// buffer.append("</ul>");
		return buffer.toString();
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{acronym}")
	public PujAdvertisementEntity selectByInstitutionAcronym(
			@PathParam("acronym") String acronym) {
		PujInstitutionEntity inst = instFacade.find(acronym);
		if (inst != null) {
			return adsFacade.find(inst.getAcronym());
		} else {
			return null;
		}
	}

	/**
	 * <code>curl -d "acronym=CEJUG&url=http://cejug.silveiraneto.net/&img=http://cejug.silveiraneto.net/wp-content/themes/atahualpa/images/logo.png" http://fgaucho.dyndns.org:8080/arena-http/ads</code>
	 * 
	 * @param info
	 * @param acronym
	 * @param url
	 * @param thumbnail
	 * @return
	 */
	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response create(@Context UriInfo info,
			@FormParam("acronym") String acronym, @FormParam("url") String url,
			@FormParam("img") String thumbnail) {
		if (acronym != null && url != null && thumbnail != null) {
			PujAdvertisementEntity ad = adsFacade.find(acronym);
			PujAdvertisementEntity createdAd = null;
			if (ad == null) {
				ad = new PujAdvertisementEntity();
				ad.setInstitution(instFacade.find(acronym));
				ad.setUrl(url);
				ad.setThumbnail(thumbnail);
				createdAd = adsFacade.create(ad);
			} else {
				ad.setUrl(url);
				ad.setThumbnail(thumbnail);
				createdAd = adsFacade.update(ad);
			}
			return Response.created(
					UriBuilder.fromPath(info.getAbsolutePath().toString())
							.path(createdAd.getInstitution().getAcronym())
							.build()).build();

		} else {
			return Response.status(Status.BAD_REQUEST).build();
		}
	}

	@DELETE
	@Path("{acronym}")
	public Response delete(@PathParam("acronym") String acronym) {
		adsFacade.delete(PujAdvertisementEntity.class, acronym);
		return Response.ok("advertisement " + acronym + " removed").build();
	}
}
