package com.kenai.puj.arena.http;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;

import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujHomeworkEntity;
import com.kenai.puj.arena.model.entity.PujLinkEntity;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.api.json.JSONJAXBContext;

@Provider
public class MyJAXBContextResolver implements ContextResolver<JAXBContext> {

	private JAXBContext context;
	private Class<?>[] types = { PujAdvertisementEntity.class,
			PujCompetitionEntity.class, PujLinkEntity.class,
			PujHomeworkEntity.class };

	public MyJAXBContextResolver() throws Exception {
		this.context = new JSONJAXBContext(JSONConfiguration.natural().build(),
				types);
	}

	public JAXBContext getContext(Class<?> objectType) {
		for (Class<?> c : types) {
			if (c.equals(objectType)) {
				return context;
			}
		}
		return null;
	}
}
