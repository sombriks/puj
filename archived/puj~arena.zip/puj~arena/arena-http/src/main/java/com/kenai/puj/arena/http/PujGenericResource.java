package com.kenai.puj.arena.http;

import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kenai.puj.arena.model.entity.PujAbstractEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujEntityFacade;

public abstract class PujGenericResource<T extends PujAbstractEntity, PK> {
	protected abstract PujEntityFacade<T> getFacade();

	private final Class<T> genericType;

	@SuppressWarnings("unchecked")
	PujGenericResource() {
		super();
		genericType = (Class<T>) ((java.lang.reflect.ParameterizedType) this
				.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}

	@PUT
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public T insert(T entity) {
		return getFacade().create(entity);
	}

	@POST
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public T update(T entity) {
		return getFacade().update(entity);
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{id}")
	public T select(@PathParam("id") String login) {
		return getFacade().read(genericType, (Object) login);
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{offset}/{limit}")
	public Collection<T> selectAll(
			@PathParam(EntityFacadeConstants.PARAM_START) int start,
			@PathParam(EntityFacadeConstants.PARAM_MAX) int max) {
		return getFacade().readAll(genericType, start, max);
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Path("count")
	public String count() {
		return Long.toString(getFacade().count(genericType));
	}
}
