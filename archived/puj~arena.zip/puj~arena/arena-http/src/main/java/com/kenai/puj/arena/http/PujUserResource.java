package com.kenai.puj.arena.http;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.jms.JMSException;
import javax.persistence.EntityExistsException;
import javax.persistence.TransactionRequiredException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;

import com.kenai.puj.arena.model.entity.PujRoleEntity;
import com.kenai.puj.arena.model.entity.PujUserDetailsEntity;
import com.kenai.puj.arena.model.entity.PujUserEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.NotificationFacade;
import com.kenai.puj.arena.model.entity.facade.PujRoleFacade;
import com.kenai.puj.arena.model.entity.facade.PujUserDetailsFacade;
import com.kenai.puj.arena.model.entity.facade.PujUserFacade;
import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.model.entity.utils.AvatarUrlBuilder;

@Path("user")
@ManagedBean
public class PujUserResource {
	private static final String I18N_BUNDLE_NAME = "i18n";

	@EJB
	private PujUserFacade userFacade;

	@EJB
	private PujUserDetailsFacade userDetailsFacade;

	@EJB
	private PujRoleFacade roleFc;

	/** The resource uses double facade. */
	@EJB
	private PujUserDetailsFacade detailsFacade;

	@EJB
	private NotificationFacade notification;

	/**
	 * <code>curl -d "name=Felipe Gaúcho&password=test&login=fgaucho&email=fgaucho@gmail.com&url=http://fgaucho.dyndns.org:8080/arena-dwr/confirm" http://fgaucho.dyndns.org:8080/arena-http/user</code>
	 * 
	 * @param login
	 *            the user's login.
	 * @param password
	 *            the user's password.
	 * @param email
	 *            the user's email.
	 * @param name
	 *            the user's name.
	 * @param url
	 *            the confirmation base URL where the user will confirm his
	 *            registration. This will be included in the email sent to the
	 *            user.
	 * @return One of the following HTTP response codes:
	 *         <ul>
	 *         <li>200 OK if the registration is complete</li>
	 *         <li>409 CONFLICT if a JPA error happens</li>
	 *         <li>400 BAD_REQUEST if the user already exist or the login or the
	 *         email are missed</li>
	 *         </ul>
	 */
	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response insert(@Context UriInfo info, @Context HttpHeaders headers,
			@FormParam("login") String login,
			@FormParam("password") String password,
			@FormParam("email") String email, @FormParam("name") String name,
			@FormParam("confirmationUrl") String url,
			@FormParam("key") String key, @FormParam("locale") String locale) {
		Locale clientLocale = null;
		if (locale == null) {
			clientLocale = headers.getLanguage();
			if (clientLocale == null) {
				clientLocale = Locale.US;
			}
		} else {
			clientLocale = new Locale(locale);
		}

		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle(I18N_BUNDLE_NAME, clientLocale);
		} catch (Exception error) {
			bundle = ResourceBundle.getBundle(I18N_BUNDLE_NAME);

		}
		if (key == null) {
			// REGISTRATION
			if (login != null && email != null
					&& userFacade.isLoginAndEmailAvailable(login, email)) {
				PujUserDetailsEntity newCustomer = new PujUserDetailsEntity();
				newCustomer.setLogin(login);
				newCustomer.setEmail(email);
				newCustomer.setName(name);
				newCustomer.setPassword(password);

				Properties prop = new Properties();
				prop.put("locale", clientLocale);
				prop.put(RegistrationConstants.NAME.value(), newCustomer
						.getName());
				prop.put(RegistrationConstants.LOGIN.value(), newCustomer
						.getLogin());

				prop.put(RegistrationConstants.CONFIRMATION_URL.value(), url);
				prop.put(RegistrationConstants.REGISTRATION_MSG.value(), bundle
						.getString(RegistrationConstants.REGISTRATION_MSG
								.value()));
				prop
						.put(
								RegistrationConstants.REGISTRATION_SUBJECT
										.value(),
								bundle
										.getString(RegistrationConstants.REGISTRATION_SUBJECT
												.value()));

				try {
					newCustomer.setAvatar(AvatarUrlBuilder
							.hashGravatar(newCustomer.getEmail()));
					userFacade.registerAndNotify(newCustomer, prop);
				} catch (EntityExistsException e) {
					return Response.status(Status.CONFLICT).header("error",
							e.getMessage()).build();
				} catch (TransactionRequiredException e) {
					return Response.status(Status.PRECONDITION_FAILED).header(
							"error", e.getMessage()).build();
				} catch (IllegalStateException e) {
					return Response.status(Status.INTERNAL_SERVER_ERROR)
							.header("error", e.getMessage()).build();
				} catch (IllegalArgumentException e) {
					return Response.status(Status.BAD_REQUEST).header("error",
							e.getMessage()).build();
				} catch (JMSException e) {
					return Response.status(Status.INTERNAL_SERVER_ERROR)
							.header("error", e.getMessage()).build();
				}
				return Response.created(
						UriBuilder.fromPath(info.getAbsolutePath().toString())
								.path(login).build()).build();
			} else {
				return Response.status(Status.BAD_REQUEST).build();
			}
		} else {
			// CONFIRMATION
			try {
				PujUserEntity user = userFacade.activate(key);

				Map<String, String> msgParams = new HashMap<String, String>();
				try {
					msgParams
							.put(
									RegistrationConstants.TWITTER_MSG.value(),
									MessageFormat
											.format(
													bundle
															.getString(RegistrationConstants.TWITTER_WELCOME
																	.value()),
													user.getLogin()));
					msgParams.put(RegistrationConstants.TWITTER_USER.value(),
							"pujcejug");

					msgParams.put(RegistrationConstants.TWITTER_PASSWORD
							.value(), "0d310pujj1");
					notification.postTopicMsg(msgParams);
				} catch (Exception error) {
					Logger.getLogger(PujUserResource.class.getName()).warning(
							"Twitter notification failed: "
									+ error.getMessage());
				}
				return Response.ok().build();
			} catch (GeneralSecurityException e) {
				return Response.status(Status.FORBIDDEN).build();
			} catch (IOException e) {
				return Response.status(Status.BAD_REQUEST).build();
			} catch (TransactionRequiredException e) {
				return Response.status(Status.INTERNAL_SERVER_ERROR).build();
			} catch (IllegalStateException e) {
				return Response.status(Status.INTERNAL_SERVER_ERROR).build();
			} catch (IllegalArgumentException e) {
				return Response.status(Status.INTERNAL_SERVER_ERROR).build();
			} catch (JMSException e) {
				return Response.status(Status.INTERNAL_SERVER_ERROR).build();
			}
		}
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujUserDetailsEntity> selectAllByCompetition(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@PathParam("puj") String puj, @QueryParam("role") String role) {
		return detailsFacade.readAll(puj, role, start, max);
	}

	@PUT
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujUserDetailsEntity update(PujUserDetailsEntity entity) {
		return userDetailsFacade.update(entity);
	}

	@DELETE
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{login}")
	public Response delete(@PathParam("login") String login) {
		userFacade.delete(PujUserEntity.class, login);
		return Response.ok().build();
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{login}")
	public PujUserDetailsEntity select(@PathParam("login") String login) {
		return detailsFacade.read(PujUserDetailsEntity.class, login);
	}

	@PUT
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujUserEntity addRole(@PathParam("login") String login,
			@Context UriInfo ui) {
		List<String> roles = ui.getQueryParameters().get("role");
		PujUserDetailsEntity user = userDetailsFacade.read(
				PujUserDetailsEntity.class, login);
		if (!roles.isEmpty()) {
			List<PujRoleEntity> roleEntities = new ArrayList<PujRoleEntity>();
			for (String role : roles) {
				roleEntities.add(roleFc.read(PujRoleEntity.class, role));
			}
			user.getRole().addAll(roleEntities);
			user = update(user);
		}
		return user;
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Path("count")
	public String count() {
		return Long.toString(userFacade.count(PujUserEntity.class));
	}
}