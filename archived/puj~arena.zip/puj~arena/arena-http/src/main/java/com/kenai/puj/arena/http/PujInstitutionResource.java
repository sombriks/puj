package com.kenai.puj.arena.http;

import java.util.Collection;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.kenai.puj.arena.model.entity.PujInstitutionDetailsEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujLinkEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionDetailsFacade;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionFacade;

// 
// curl -H "Accept:application/json" -X GET http://fgaucho.dyndns.org:8080/arena-http/institution/ivia

@Path("institution")
@ManagedBean
public class PujInstitutionResource {
	@EJB
	private PujInstitutionFacade facade;

	@EJB
	private PujInstitutionDetailsFacade detailsFacade;

	@POST
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujInstitutionDetailsEntity update(
			PujInstitutionDetailsEntity institution) {
		return detailsFacade.update(institution);
	}

	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{acronym}")
	public PujInstitutionDetailsEntity create(
			@PathParam("acronym") String acronym) {
		// perhaps to include more semantics in the exceptions- in the case of
		// duplicated acronyms or null acronym, etc.

		PujInstitutionDetailsEntity institution = new PujInstitutionDetailsEntity();
		institution.setAcronym(acronym);
		return detailsFacade.create(institution);
	}

	@DELETE
	@Path("{acronym}")
	public Response delete(@PathParam("acronym") String acronym) {
		facade.delete(PujInstitutionEntity.class, acronym);
		return Response.ok("institution " + acronym + " deleted").build();
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{id}")
	public PujInstitutionDetailsEntity select(@PathParam("id") String login) {
		return detailsFacade.read(PujInstitutionDetailsEntity.class,
				(Object) login);

	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujInstitutionEntity> selectAllByRole(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("role") String role) {
		Collection<PujInstitutionEntity> institutionList = facade
				.readAllbyRole(role, start, max);
		for (PujInstitutionEntity inst : institutionList) {
			applyHypermediaLinks(inst);
		}
		return institutionList;

	}

	private void applyHypermediaLinks(PujInstitutionEntity institution) {
		Collection<PujLinkEntity> links = institution.getLinks();
		PujLinkEntity link = new PujLinkEntity();
		link.setRel("itself");
		link.setUri("institution/" + institution.getAcronym());
		links.add(link);

		PujLinkEntity link2 = new PujLinkEntity();
		link2.setRel("details");
		link2.setUri("competition?institution=" + institution.getAcronym());
		links.add(link2);
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Path("count")
	public String count() {
		return "working";
	}

	/*
	 * @Context UriInfo ui;
	 * 
	 * @PostConstruct public void postConstruct() {
	 * Logger.getLogger(PujInstitutionResource.class.getName()).log( Level.INFO,
	 * "In post construct " + this + "; UriInfo: " + ui); }
	 * 
	 * @PreDestroy public void preDestroy() {
	 * Logger.getLogger(PujInstitutionResource.class.getName()).log( Level.INFO,
	 * "In pre destroy"); }
	 */
}
