package com.kenai.puj.arena.http;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.kenai.puj.arena.model.entity.PujEvaluation;
import com.kenai.puj.arena.model.entity.PujHomeworkRef;
import com.kenai.puj.arena.model.entity.PujUserEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkEvaluationFacade;
import com.kenai.puj.arena.model.entity.facade.PujHomeworkFacade;
import com.kenai.puj.arena.model.entity.facade.PujUserFacade;

@Path("eval")
@ManagedBean
public class PujEvaluationResource {
	@EJB
	private PujHomeworkEvaluationFacade facade;
	@EJB
	private PujUserFacade userFacade;
	@EJB
	private PujHomeworkFacade homeworkFacade;

	// @Context private UriInfo info;

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujEvaluation> readAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("acronym") String acronym,
			@QueryParam("login") String login, @QueryParam("name") String puj) {
		if (puj != null) {
			return facade.readAllByCompetition(puj);
		} else {
			Map<String, Serializable> parameters = new ConcurrentHashMap<String, Serializable>();
			if (acronym != null) {
				PujHomeworkRef homework = homeworkFacade.find(acronym);
				if (homework == null) {
					return new ArrayList<PujEvaluation>();
				} else {
					parameters.put("homework", homework);
				}
			}

			if (login != null) {
				PujUserEntity user = userFacade.find(login);
				if (user == null) {
					return new ArrayList<PujEvaluation>();
				} else {
					parameters.put("evaluator", user);
				}
			}

			return facade.findByCriteria(parameters, start, max);
		}
	}

	@GET
	@Produces( { MediaType.TEXT_HTML, MediaType.TEXT_PLAIN })
	@Path("{competition}/graph")
	public Response graph(@PathParam("competition") String login) {

		try {
			URI uri = new URI(
					"http://chart.apis.google.com/chart?cht=p3&chd=t:60,40&chs=250x100&chl=Hello|World");
			return Response.noContent().header("Location", uri).build();
		} catch (URISyntaxException e) {
			return Response.serverError().header("Error", e.getMessage())
					.build();
		}
	}

}