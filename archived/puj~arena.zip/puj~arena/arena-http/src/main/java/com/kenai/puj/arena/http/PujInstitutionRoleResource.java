package com.kenai.puj.arena.http;

import java.util.Collection;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionRoles;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujInstitutionRoleFacade;

@Path(PujInstitutionRoleResource.PATH)
@ManagedBean
public class PujInstitutionRoleResource {
	public static final String PATH = "institutionroles";

	@EJB
	private PujInstitutionRoleFacade facade;

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujInstitutionRoles> selectAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max) {
		return facade.readAll(PujInstitutionRoles.class, start, max);
	}

	@PUT
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PujInstitutionRoles insert(PujInstitutionRoles entity) {
		return facade.create(entity);
	}

	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public PujInstitutionRoles insert(
			@FormParam(PujInstitutionEntity.ACRONYM) String institution,
			@FormParam(PujCompetitionEntity.NAME) String competition,
			@FormParam(PujInstitutionRoles.ROLE) String role) {
		return facade.create(competition, institution, role);
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{id}")
	public PujInstitutionRoles select(@PathParam("id") String login) {
		return facade.read(PujInstitutionRoles.class, (Object) login);
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Path("count")
	public String count() {
		return Long.toString(facade.count(PujInstitutionRoles.class));
	}
}
