package com.kenai.puj.arena.http;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.kenai.puj.arena.model.entity.PujCompetitionDetailsEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujLinkEntity;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionDetailsFacade;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;
import com.sun.jersey.api.json.JSONWithPadding;

@Path("competition")
@ManagedBean
public class PujCompetitionResource {
	@EJB
	private PujCompetitionFacade facade;

	@EJB
	private PujCompetitionDetailsFacade detailsFacade;

	@OPTIONS
	@Path("{name}")
	public Collection<PujLinkEntity> options(@PathParam("name") String name) {
		Collection<PujLinkEntity> links = new ArrayList<PujLinkEntity>();
		if (name != null) {
			PujLinkEntity link = new PujLinkEntity();
			link.setRel("details");
			link.setUri("/competition/" + name);
			links.add(link);
		}
		return links;
	}

	@DELETE
	@Path("{name}")
	public Response delete(@PathParam("name") String name) {
		try {
			detailsFacade.delete(PujCompetitionDetailsEntity.class, name);
			return Response.ok().build();
		} catch (Exception error) {
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{name}")
	public PujCompetitionDetailsEntity read(@PathParam("name") String name) {
		PujCompetitionDetailsEntity comp = detailsFacade.read(
				PujCompetitionDetailsEntity.class, name);
		if (comp != null) {
			applyHypermediaLinks(comp);
		}
		return comp;
	}

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Collection<PujCompetitionEntity> readAll(
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("name") String name,
			@QueryParam("institution") String institution) {
		Collection<PujCompetitionEntity> competitions = null;
		if (institution == null) {
			Map<String, String> parameters = new HashMap<String, String>();
			if (name != null) {
				parameters.put("name", name);
			}
			competitions = facade.findByCriteria(parameters, start, max);
		} else {
			competitions = facade.findByInstitution(institution, start, max);
		}
		for (PujCompetitionEntity comp : competitions) {
			applyHypermediaLinks(comp);
		}
		return competitions;
	}

	@GET
	@Path("jsonp")
	@Produces( { "application/x-javascript", MediaType.APPLICATION_JSON,
			MediaType.APPLICATION_XML })
	public JSONWithPadding readAllP(
			@QueryParam("jsoncallback") @DefaultValue("fn") String callback,
			@QueryParam(EntityFacadeConstants.PARAM_START) @DefaultValue(EntityFacadeConstants.PARAM_START_DEFAULT_VALUE) int start,
			@QueryParam(EntityFacadeConstants.PARAM_MAX) @DefaultValue(EntityFacadeConstants.PARAM_MAX_DEFAULT_VALUE) int max,
			@QueryParam("name") String name,
			@QueryParam("institution") String institution) {
		Collection<PujCompetitionEntity> competitions = readAll(start, max,
				name, institution);
		return new JSONWithPadding(
				new GenericEntity<Collection<PujCompetitionEntity>>(
						competitions) {
				}, callback);

	}

	private void applyHypermediaLinks(PujCompetitionEntity competition) {
		Collection<PujLinkEntity> links = competition.getLinks();
		PujLinkEntity link = new PujLinkEntity();
		link.setRel("details");
		link.setUri("/competition/" + competition.getName());
		links.add(link);
		// links.add(new PujLinkEntity("/competition/" + competition.getName() +
		// "?mode=details", "details"));
	}

	@POST
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("{name}")
	public PujCompetitionEntity insert(@PathParam("name") String name) {
		PujCompetitionEntity competition = new PujCompetitionDetailsEntity();
		competition.setName(name);
		competition.setStatus(PujCompetitionEntity.CompetitionStatus.NEW);
		return facade.create(competition);
	}
}