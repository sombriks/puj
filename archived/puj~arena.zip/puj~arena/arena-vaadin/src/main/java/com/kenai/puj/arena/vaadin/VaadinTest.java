package com.kenai.puj.arena.vaadin;

import java.util.Collection;

import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.vaadin.Application;
import com.vaadin.ui.Label;
import com.vaadin.ui.Window;

public class VaadinTest extends Application {
	private static final long serialVersionUID = 1L;

	private transient WebResource arena = null;

	public VaadinTest() {
		String BaseURI = "http://fgaucho.dyndns.org:8080/arena-http";
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		arena = client.resource(BaseURI);
	}

	@Override
	public void init() {
		Window window = new Window(
				"This shold be replaced by the real application");
		setMainWindow(window);

		Label label = new Label(
				"Vaadin skeleton is online, waiting the Brazilian developers to work on it...");
		window.addComponent(label);
		window.addComponent(new Label(
				"Loading institutions from the arena RESTful web-service..."));
		window.addComponent(new Label(" "));
		window.addComponent(new Label(" "));

		for (PujInstitutionEntity institution : loadInstitutions()) {
			window.addComponent(new Label(institution.getAcronym() + " - "
					+ institution.getName()));
		}

	}

	private Collection<PujInstitutionEntity> loadInstitutions() {
		return arena.path("institution").get(
				new GenericType<Collection<PujInstitutionEntity>>() {
				});

	}
}
