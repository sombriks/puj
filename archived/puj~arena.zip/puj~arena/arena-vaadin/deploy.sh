#!/bin/bash

echo
echo "-------- Deploying Vaadin Web GUI to Server $GF_VERSION"
asadmin deploy --force=true --name arena-vaadin target/arena-vaadin*.war
echo
