package com.kenai.puj.arena.client.test;

import javax.ws.rs.core.MediaType;

import org.junit.Assert;
import org.junit.Test;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionRoles;
import com.sun.jersey.api.representation.Form;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class InstitutionRolesTestCase extends AbstractIntegrationTest {
	@Test
	public void roundtrip() {
		CompetitionTestCase comp = new CompetitionTestCase();
		PujCompetitionEntity competition = comp.createCompetition();
		Assert.assertNotNull(competition);

		InstitutionIntegrationTest inst = new InstitutionIntegrationTest();
		PujInstitutionEntity institution = inst.createInstitution();
		Assert.assertNotNull(institution);

		PujInstitutionRoles joinTable = createJoinTable(competition.getName(),
				institution.getAcronym(), PujInstitutionRoles.Role.SCHOOL
						.name());
		Assert.assertNotNull(joinTable);
		Assert.assertEquals(institution.getAcronym(), joinTable
				.getInstitution().getAcronym());
		Assert.assertEquals(competition.getName(), joinTable.getCompetition()
				.getName());
	}

	/**
	 * <pre>
	 * curl -d"INSTITUTION_ACRONYM=_988962284&COMPETITION_NAME=_1618622200&ROLE_NAME=SCHOOL" http://fgaucho.dyndns.org:8080/arena-http/instroles
	 * </pre>
	 */
	public PujInstitutionRoles createJoinTable(String name, String acronym,
			String role) {
		Form formData = new Form();
		formData.add(PujInstitutionEntity.ACRONYM, acronym);
		formData.add(PujCompetitionEntity.NAME, name);
		formData.add(PujInstitutionRoles.ROLE, role);
		return arena.path("institutionroles").type(
				MediaType.APPLICATION_FORM_URLENCODED_TYPE).post(
				PujInstitutionRoles.class, formData);
	}
}
