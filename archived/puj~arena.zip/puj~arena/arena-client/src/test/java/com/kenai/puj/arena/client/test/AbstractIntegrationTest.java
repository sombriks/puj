package com.kenai.puj.arena.client.test;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Random;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

/**
 * Superclass used to share resources within the itegration tests, like the HTTP
 * Client.
 */
public abstract class AbstractIntegrationTest {
	public enum ALLOWED_ROLES {
		SYS_ADMIN, SPONSOR, PROFESSOR, STUDENT
	}

	protected final String AUTHENTICATION_HEADER = "Authorization";
	protected static final String BaseURI = "http://localhost:8080/arena-http";
	protected static final String SecureURI = "https://localhost:8181/arena-http";
	protected WebResource arena;
	protected int counter = Math.abs(new Random().nextInt());

	public AbstractIntegrationTest() {
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		arena = client.resource(BaseURI);
		arena.addFilter(new LoggingFilter());
	}

	protected WebResource getSecureArena() {
		ClientConfig config = new DefaultClientConfig();

		SSLContext ctx = null;

		try {
			ctx = SSLContext.getInstance("SSL");
			ctx.init(null, mytm, null);
		} catch (Exception e) {
		}

		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
				new HTTPSProperties(hv, ctx));

		Client client = Client.create(config);
		return client.resource(SecureURI);
	}

	/**
	 * <p>
	 * Convenience string for Base 64 encoding.
	 * </p>
	 */
	private static final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "abcdefghijklmnopqrstuvwxyz" + "0123456789+/";

	/**
	 * <p>
	 * Encode the specified credentials into a String as required by HTTP Basic
	 * Authentication (<a href="http://www.ietf.org/rfc/rfc2617.txt">RFC
	 * 2617</a>).
	 * </p>
	 * 
	 * @param username
	 *            Username to be encoded
	 * @param password
	 *            Password to be encoded
	 */
	protected String encodeCredentialsBasic(String username, String password) {
		String encode = username + ":" + password;
		int paddingCount = (3 - (encode.length() % 3)) % 3;
		encode += "\0\0".substring(0, paddingCount);
		StringBuilder encoded = new StringBuilder();
		for (int i = 0; i < encode.length(); i += 3) {
			int j = (encode.charAt(i) << 16) + (encode.charAt(i + 1) << 8)
					+ encode.charAt(i + 2);
			encoded.append(BASE64_CHARS.charAt((j >> 18) & 0x3f));
			encoded.append(BASE64_CHARS.charAt((j >> 12) & 0x3f));
			encoded.append(BASE64_CHARS.charAt((j >> 6) & 0x3f));
			encoded.append(BASE64_CHARS.charAt(j & 0x3f));
		}

		return encoded.toString();
	}

	X509TrustManager xtm = new X509TrustManager() {

		@Override
		public void checkClientTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
			return;
		}

		@Override
		public void checkServerTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
			return;
		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	};
	TrustManager mytm[] = { xtm };
	HostnameVerifier hv = new HostnameVerifier() {

		@Override
		public boolean verify(String hostname, SSLSession sslSession) {
			return true;
		}
	};

	/**
	 * The mapping between the test users and the roles allowed in the Arena
	 * application.
	 * 
	 * @param role
	 *            the role of the test user.
	 * @return a test users with an specific role.
	 */
	protected String getBasicAuthenticationHeader(
			AbstractIntegrationTest.ALLOWED_ROLES role) {
		switch (role) {
		case SPONSOR:
			// return "Basic " + encodeCredentialsBasic("petertosh", "teste");
			return "Basic " + encodeCredentialsBasic("marley", "teste");
		default:
			throw new NullPointerException("role '" + role + "' not defined");
		}
	}
}
