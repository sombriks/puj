package com.kenai.puj.arena.client.test;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status.Family;

import org.junit.Before;
import org.junit.Test;

import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.representation.Form;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class UserManagementTestCase extends AbstractIntegrationTest {
	private static final Map<String, String> userPassword = new HashMap<String, String>();
	private static int index = 0;

	private void checkResponse(ClientResponse response) {
		Status status = response.getClientResponseStatus();
		assertTrue(status.getReasonPhrase(), Family.SUCCESSFUL.equals(status
				.getFamily()));
	}

	private void cleanup(String login) {
		try {
			if (login != null) {
				removeUser(login);
			}
		} catch (Exception error) {

			System.out.println("cleanup failed for " + login + "("
					+ error.getMessage() + ")");
			error.printStackTrace();
		}
	}

	private ClientResponse removeUser(String login) {
		ClientResponse response = arena.path("user").path(login).accept(
				MediaType.APPLICATION_JSON).delete(ClientResponse.class);
		return response;
	}

	/**
	 * <ol>
	 * <li>register a new user account</li>
	 * <li>Confirm the Registration</li>
	 * <li>reset the password</li>
	 * <li>Change the password</li>
	 * </ol>
	 * 
	 * @throws IOException
	 */
	@Test
	public void registerAndConfirmNewAccount() throws IOException {
		assertTrue(UserManagementTestCase.index < UserManagementTestCase.userPassword
				.keySet().size() - 1);
		String login = "fake" + UserManagementTestCase.index++;
		cleanup(login);
		checkResponse(registerNewUser(login));
		checkResponse(confirmRegistration(login));
		cleanup(login);
	}

	/**
	 * curl -d "name=Felipe Gaúcho&password=test&login=fgaucho&email=fgaucho@gmail.com&confirmationUrl=http://fgaucho.dyndns.org:8080/arena-dwr/confirm" http://fgaucho.dyndns.org:8080/arena-http/user
	 */
	public ClientResponse registerNewUser(String login) {
		Form formData = new Form();
		formData.add(RegistrationConstants.NAME.value(), "JUnit (" + login
				+ ")");
		formData.add(RegistrationConstants.PASSWORD.value(), login);
		formData.add(RegistrationConstants.LOGIN.value(), login);
		formData.add(RegistrationConstants.EMAIL.value(), "fgaucho@gmail.com");
		formData.add(RegistrationConstants.CONFIRMATION_URL.value(),
				"http://localhost:8080/arena-dwr/confirm");
		return arena.path("user").type("application/x-www-form-urlencoded")
				.post(ClientResponse.class, formData);
	}

	/**
	 * @return the code of the HTTP Response for the confirmation of the
	 *         registration.
	 * @throws IOException
	 */
	public ClientResponse confirmRegistration(String login) throws IOException {
		String encodedFormData = UserManagementTestCase.userPassword.get(login);

		ClientResponse response = arena.path("user").type(
				"application/x-www-form-urlencoded").post(ClientResponse.class,
				encodedFormData);
		return response;
	}

	@Before
	public void before() {
		// we use a map instead of a simple array to better controlling the
		// mapping between fake logins and its confirmation URLs.
		if (UserManagementTestCase.userPassword.isEmpty()) {
			UserManagementTestCase.userPassword
					.put("fake0",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BgSMeWuSzu1bQ%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake1",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BiTtJuW7FCxCQ%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake2",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BgKE8npPoFgkQ%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake3",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BhrpxBzVVfN5w%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake4",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bjr9Yxlw48mVQ%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake5",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bh1Q5CJY%2F%2Bv7Q%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake6",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BjJFl4t1OCV7A%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake7",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BiuzZzpYp6%2Ffw%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake8",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BgA98pGWBcNYg%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake9",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bg4WGQ%2BIRMhlA%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake10",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BhIysIj3hJ6ag%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake11",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BiQhM3u81Yhzw%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake12",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BgUE3Nadr6zGA%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake13",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bg9iua5zJ0yfQ%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2BhPgrMl1AhnGA%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake14",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bi0P%2FamMrgs5w%3D%3D");
			UserManagementTestCase.userPassword
					.put("fake15",
							"key=JkOgm11BWssuU3e%2Fnt23GYr4gQeLCHu344VhBQaV3%2Bhvnkx%2FAj9WIw%3D%3D");
		}
	}
}
