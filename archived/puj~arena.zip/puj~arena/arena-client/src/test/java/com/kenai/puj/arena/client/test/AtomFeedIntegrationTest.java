package com.kenai.puj.arena.client.test;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.Assert;
import org.junit.Test;

import com.kenai.puj.arena.model.atom.EntryType;
import com.kenai.puj.arena.model.atom.LinkType;
import com.kenai.puj.arena.model.atom.TextType;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class AtomFeedIntegrationTest extends AbstractIntegrationTest {
	private Calendar c = Calendar.getInstance();

	@Test
	public void wroundtrip() {
		usixVaga2();
		usixVaga1();
		fourLinuxVaga();
		catalog("Jobs");
		catalog("Courses");
		catalog("News");
		sagarana();
		fortes1();
		fortes2();
		Assert.assertTrue(true);
	}

	public EntryType sagarana() {
		EntryType entry = new EntryType();

		TextType title = new TextType();
		title.setContent("<p><strong>Suporte com inglês fluente</strong></p>");
		title.setType("html");
		entry.setTitle(title);

		Calendar t = Calendar.getInstance(TimeZone.getDefault());
		t.set(Calendar.DAY_OF_MONTH, 27);
		t.set(Calendar.MONTH, 11);
		t.set(Calendar.YEAR, 2009);
		entry.setUpdated(t);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<p><img src='https://cejug.dev.java.net/files/documents/859/145681/sagarana_small.jpg' />Contrata-se Suporte com ingl&ecirc;s fluente. Somos uma empresa de TI, que desenvolve produtos na &aacute;rea de log&iacute;stica e tem clientes em v&aacute;rios lugares como Israel, EUA, Austr&aacute;lia e estamos contratando pessoas para nosso time de suporte. Precisamos de pessoas com vontade de aprender, conhecimento de TI e ingl&ecirc;s fluente.</p><p>Enviar curr&iacute;culo para: <strong>job@sagaranatech.com</strong></p><p>&amp;nbsp;</p>");
		entry.setContent(content);
		entry.setSummary(content);

		TextType rights = new TextType();
		rights.setType("text");
		rights.setContent("2009-2010 (C) Arena PUJ");
		entry.setRights(rights);

		LinkType link = new LinkType();
		link
				.setHref("https://cejug.dev.java.net/files/documents/859/145681/sagarana_small.jpg");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Suporte com ingl&ecirc;s fluente");
		link.setType("text/html");
		entry.setLink(link);

		return createEntry(entry, "jobs");
	}

	public EntryType fortes1() {
		EntryType entry = new EntryType();

		TextType title = new TextType();
		title.setContent("Modelagem do Processo de Teste com EPF Composer");
		title.setType("text");
		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<table><tr><td><p><img src='http://www.fortestreinamentos.com.br/v3/i/logo.gif'><p></td><td><ul><li><p><strong>OBJETIVO</strong>: Apresentar conceitos de modelagem de processos de teste e realizar pr&aacute;ticas   atrav&eacute;s da ferramenta EPF Composer (open source).</p></li><li><p><strong>A QUEM SE DESTINA</strong>: Analistas de testes, testadores, analistas de sistemas, gerentes de projeto e   profissionais na &aacute;rea de desenvolvimento de software.</p></li><li><p><strong>PROFESSOR</strong>: Cristiano Caetano</p></li></ul></td></tr></table><p><strong>Vagas Limitadas</strong></p><ul><li><p>Nome do Curso: Modelagem do Processo de Teste com EPF Composer</p></li><li><p>Carga-hor&aacute;ria: 08 horas/aula</p></li><li><p>Per&iacute;odo de Realiza&ccedil;&atilde;o: 02 de Fevereiro 2010 (ter&ccedil;a-feira)</p></li><li><p>Hor&aacute;rio: das 08h30min &agrave;s 12h / de 13h30min &agrave;s 18h</p></li><li><p>Informa&ccedil;&otilde;es: (85) 4005-1170 / 4005-1174</p></li>");

		entry.setContent(content);
		entry.setSummary(content);

		Calendar expire = Calendar.getInstance(TimeZone.getDefault());
		expire.set(Calendar.DAY_OF_MONTH, 01);
		expire.set(Calendar.MONTH, 1);
		expire.set(Calendar.YEAR, 2010);
		entry.setExpire(expire);

		c.add(Calendar.MINUTE, 1);
		entry.setUpdated(c);

		TextType rights = new TextType();
		rights.setType("text");
		rights.setContent("2009-2010 (C) Arena PUJ");
		entry.setRights(rights);

		LinkType link = new LinkType();
		link
				.setHref("http://www.fortestreinamentos.com.br/v3/cursos_view.php?id=542");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Modelagem do Processo de Teste com EPF Composer");
		link.setType("text/html");
		entry.setLink(link);
		return createEntry(entry, "courses");
	}

	public EntryType fortes2() {
		EntryType entry = new EntryType();

		TextType title = new TextType();
		title.setContent("TestComplete");
		title.setType("text");
		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<table><tr><td><p><img src='http://www.fortestreinamentos.com.br/v3/i/logo.gif'><p></td><td><ul><li><p><strong>OBJETIVO</strong>: Apresentar os principais conceitos associados &agrave; automa&ccedil;&atilde;o de testes de software, abordando os principais tipos de automa&ccedil;&atilde;o de testes funcionais, suas vantagens e limita&ccedil;&otilde;es, os custos associados, o retorno de investimento e os principais requisitos para a implanta&ccedil;&atilde;o de uma iniciativa de automa&ccedil;&atilde;o de testes de sucesso. Ser&atilde;o apresentados exemplos pr&aacute;ticos para refor&ccedil;ar os conceitos aprendidos por meio de exerc&iacute;cios utilizando uma ferramenta comercial de automa&ccedil;&atilde;o de testes (TestComplete).</p></li><li><p><strong>A QUEM SE DESTINA</strong>: Testadores, Analistas de testes, Analistas de Sistemas e profissionais na &aacute;rea de desenvolvimento de software.</p></li><li><p><strong>PROFESSOR</strong>: Cristiano Caetano</p></li></ul></td></tr></table><p><strong>Vagas Limitadas</strong></p><ul><li><p>Nome do Curso: Automa&ccedil;&atilde;o de Testes Funcionais com TestComplete</p></li><li><p>Carga-hor&aacute;ria: 16 horas/aula</p></li><li><p>Per&iacute;odo de Realiza&ccedil;&atilde;o: 05 e 06 de Fevereiro 2010 (sexta e s&aacute;bado)</p></li><li><p>Hor&aacute;rio: das 08h30min &agrave;s 12h / de 13h30min &agrave;s 18h</p></li><li><p>Informa&ccedil;&otilde;es: (85) 4005-1170 / 4005-1174</p></li>");

		entry.setContent(content);
		entry.setSummary(content);

		Calendar expire = Calendar.getInstance(TimeZone.getDefault());
		expire.set(Calendar.DAY_OF_MONTH, 5);
		expire.set(Calendar.MONTH, 1);
		expire.set(Calendar.YEAR, 2010);
		entry.setExpire(expire);

		c.add(Calendar.MINUTE, 1);
		entry.setUpdated(c);

		TextType rights = new TextType();
		rights.setType("text");
		rights.setContent("2009-2010 (C) Arena PUJ");
		entry.setRights(rights);

		LinkType link = new LinkType();
		link
				.setHref("http://www.fortestreinamentos.com.br/v3/cursos_view.php?id=540");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Automa&ccedil;&atilde;o de Testes Funcionais com TestComplete");
		link.setType("text/html");
		entry.setLink(link);
		return createEntry(entry, "courses");
	}

	public EntryType fourLinuxVaga() {
		EntryType entry = new EntryType();

		TextType title = new TextType();
		title.setContent("<p><strong>Programador Java - Portais</strong></p>");
		title.setType("html");

		Calendar t = Calendar.getInstance(TimeZone.getDefault());
		t.set(Calendar.DAY_OF_MONTH, 7);
		t.set(Calendar.MONTH, 0);
		t.set(Calendar.YEAR, 2010);
		t.add(Calendar.MINUTE, 1);
		entry.setUpdated(t);

		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<p><img src='http://www.4linux.com.br//sites/4linux.com.br/themes/custom/zen/fourlinux/images/logo-4linux.gif'/><span>O profissional que estamos procurando dever&aacute;  ser um bom programador java ( SCJP )  e conhecer um um pouco de infra java para:</p><ul><li>aprender e customizar o sw livre exo, alfresco, pentaho, dimdim e OpenCRX.</li><li>construir infra java com jboss e tomcat, fazer tuning neste tipo de infra.</li><li>trabalhar na cria&ccedil;&atilde;o dos zimlets do software de colabora&ccedil;&atilde;o zimbra.</li><li>desenvolver portlets.</li></ul><p>Para esta vaga que estamos contratando o candidado deve ter obrigatoriamente experi&ecirc;ncia em:</p><ul><li>Programa&ccedil;&atilde;o de Portlets;</li><li>Uso de JSF em portlets;</li><li>Hibernate;</li><li>JAVA EE;</li></ul><p>S&atilde;o caracter&iacute;sticas desej&aacute;veis:</p><ul><li>SCWCD (Sun Certified Web Component Developer);</li><li>Ingl&ecirc;s fluente;</li><li>Experi&ecirc;ncia com acesso Java a Mainframes;</li><li>Experi&ecirc;ncia com Software Livre;</li><li>Experi&ecirc;ncia com produtos IBM Rational;</li><li>No&ccedil;&otilde;es de gerenciamento de projetos;</li><li>No&ccedil;&otilde;es de trabalho com m&eacute;todos &aacute;geis;</li></ul><p>Enviar curr&iacute;culo para <strong>ombudsman@4linux.com.br</strong></span></p><p>&amp;nbsp;</p>");
		entry.setContent(content);
		entry.setSummary(content);

		TextType rights = new TextType();
		rights.setContent("2009-2010 (R) Arena PUJ");
		rights.setType("text");
		entry.setRights(rights);
		
		LinkType link = new LinkType();
		link
				.setHref("http://www.4linux.com.br/linux_suporte_treinamento_cursos_consultoria");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Programador Java - Portais");
		link.setType("text/html");
		entry.setLink(link);
		
		return createEntry(entry, "jobs");
	}

	public EntryType usixVaga1() {
		EntryType entry = new EntryType();

		TextType title = new TextType();
		title.setContent("Analista Java - Fortaleza");
		title.setType("text");

		Calendar t = Calendar.getInstance(TimeZone.getDefault());
		t.set(Calendar.DAY_OF_MONTH, 13);
		t.set(Calendar.MONTH, 0);
		t.set(Calendar.YEAR, 2010);
		entry.setUpdated(t);

		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<p><img src='http://kenai.com/attachments/wiki_images/cejug/usix.png'/> USIX S/A, empresa brasileira com foco no Mercado Segurador fecha mais uma parceria e INICIA NOVO PROCESSO SELETIVO PARA COMPOSI&Ccedil;&Atilde;O DA EQUIPE DE DESENVOLVIMENTO DA F&Aacute;BRICA DE FORTALEZA.</p><p><strong>PERFIL DESEJADO:</strong></p><ul><li>Experi&ecirc;ncia em an&aacute;lise de sistemas;</li><li>Experi&ecirc;ncia em Desenvolvimento Java para Web;</li><li>Experi&ecirc;ncia em Desenvolvimento com JavaScript;</li><li>Experi&ecirc;ncia em UML e suas diagrama&ccedil;&otilde;es;</li><li>Boa escrita em documentos de requisitos funcionais e n&atilde;o funcionais;</li><li>Experi&ecirc;ncia em Banco de dados relacional (ORACLE, DB2 ou SQL Server) e  diagrama de entidade-relacionamento;</li><li>Conhecimento acerca de orienta&ccedil;&atilde;o a objetos, boas pr&aacute;ticas de programa&ccedil;&atilde;o e padr&otilde;es de projeto.</li><li>Conhecimento da plataforma Java EE 1.3, 1.4 ou 5 (EJB, JMS, JSF, JPA, etc.);</li><li>Desej&aacute;vel conhecimento em frameworks de mercado (Spring, Hibernate, etc.);</li><li>Desej&aacute;vel conhecimento em Servidores de Aplica&ccedil;&atilde;o da plataforma Java EE (Websphere, Glassfish, Jboss AS, etc);</li><li>Desej&aacute;vel conhecimento em Microsoft Project</li><li>Desej&aacute;vel Ingl&ecirc;s T&eacute;cnico</li></ul><p><strong>BENEF&Iacute;CIOS:</strong> A Usix possui um plano de carreiras definido e atrativo, com foco no crescimento profissional. Com uma pol&iacute;tica de valoriza&ccedil;&atilde;o dos seus colaboradores, busca sempre o melhor em benef&iacute;cios:</p><ul><li>Remunera&ccedil;&atilde;o compat&iacute;vel com o mercado (Plano de Cargos e Sal&aacute;rios definido);</li><li>Plano de Sa&uacute;de;</li><li>Plano de Previd&ecirc;ncia Privada;</li><li>Seguro de Vida;</li><li>Vale Refei&ccedil;&atilde;o;</li><li>Vale Alimenta&ccedil;&atilde;o;</li><li>Vale Combust&iacute;vel;</li><li>Plano Odontol&oacute;gico;</li><li>Conv&ecirc;nios com Farm&aacute;cias;</li><li>Conv&ecirc;nios com Universidades;</li><li>Conv&ecirc;nios com Cursos de L&iacute;nguas;</li><li>Financiamento em 100% para Certifica&ccedil;&otilde;es;</li><li>Incentivo &agrave; P&oacute;s-Gradua&ccedil;&atilde;o;</li><li>Incentivo para cursos e treinamentos;</li><li>Oportunidade de crescimento profissional.</li></ul><p>Para maiores informa&ccedil;&otilde;es e envio de curr&iacute;culos, favor entrar em contato com o e-mail: <strong>usixrecrutamento@usix.com.br</strong></span></p><p><strong>IMPORTANTE: Colocar no campo Assunto o nome da Vaga de interesse.</strong><p><p>&amp;nbsp;</p>");
		entry.setContent(content);
		entry.setSummary(content);

		TextType rights = new TextType();
		rights.setContent("2009-2010 (R) Arena PUJ");
		rights.setType("text");
		entry.setRights(rights);

		LinkType link = new LinkType();
		link
				.setHref("http://www.usix.com.br/website2/index.php?option=com_content&view=article&id=198&Itemid=90");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Analista Java - Fortaleza");
		link.setType("text/html");
		entry.setLink(link);

		return createEntry(entry, "jobs");
	}

	public EntryType usixVaga2() {
		EntryType entry = new EntryType();

		TextType summary = new TextType();
		summary
				.setContent("<p><img src='http://kenai.com/attachments/wiki_images/cejug/usix.png'/> USIX S/A, empresa brasileira com foco no Mercado Segurador fecha mais uma parceria e INICIA NOVO PROCESSO SELETIVO PARA COMPOSI&Ccedil;&Atilde;O DA EQUIPE DE DESENVOLVIMENTO DA F&Aacute;BRICA DE FORTALEZA.</p><p><strong>PERFIL DESEJADO:</strong></p><ul><li>Experi&ecirc;ncia em Desenvolvimento Java para Web;</li><li>Conhecer e utilizar algum sistema de controle de Vers&atilde;o (CVS, SVN, etc);</li><li>Conhecer e utilizar servidores de aplica&ccedil;&atilde;o (Tomcat, Jetty, etc);</li><li>Desej&aacute;vel conhecimento na constru&ccedil;&atilde;o de Web Services;</li><li>Desej&aacute;vel conhecimentos em relat&oacute;rios (IReport + Jasper, etc);</li><li>Conhecimento acerca de MVC, orienta&ccedil;&atilde;o a objetos e boas pr&aacute;ticas de programa&ccedil;&atilde;o;</li><li>Conhecimento sobre Padr&otilde;es de Projetos;</li><li>Bom conhecimento em Javascript;</li><li>Saber criar, interpretar e criticar instru&ccedil;&atilde;o DML do SQL;</li><li>Achar os diagramas da UML muito &uacute;til, saber l&ecirc;-la, interpret&aacute;-la e at&eacute; mesmo critic&aacute;-la;</li><li>Desej&aacute;vel ingl&ecirc;s t&eacute;cnico.</li></ul><p><strong>BENEF&Iacute;CIOS:</strong> A Usix possui um plano de carreiras definido e atrativo, com foco no crescimento profissional. Com uma pol&iacute;tica de valoriza&ccedil;&atilde;o dos seus colaboradores, busca sempre o melhor em benef&iacute;cios:</p><ul><li>Remunera&ccedil;&atilde;o compat&iacute;vel com o mercado (Plano de Cargos e Sal&aacute;rios definido);</li><li>Plano de Sa&uacute;de;</li><li>Plano de Previd&ecirc;ncia Privada;</li><li>Seguro de Vida;</li><li>Vale Refei&ccedil;&atilde;o;</li><li>Vale Alimenta&ccedil;&atilde;o;</li><li>Vale Combust&iacute;vel;</li><li>Plano Odontol&oacute;gico;</li><li>Conv&ecirc;nios com Farm&aacute;cias;</li><li>Conv&ecirc;nios com Universidades;</li><li>Conv&ecirc;nios com Cursos de L&iacute;nguas;</li><li>Financiamento em 100% para Certifica&ccedil;&otilde;es;</li><li>Incentivo &agrave; P&oacute;s-Gradua&ccedil;&atilde;o;</li><li>Incentivo para cursos e treinamentos;</li><li>Oportunidade de crescimento profissional.</li></ul><p>Para maiores informa&ccedil;&otilde;es e envio de curr&iacute;culos, favor entrar em contato com o e-mail: <strong>usixrecrutamento@usix.com.br</strong></span></p><p><strong>IMPORTANTE: Colocar no campo Assunto o nome da Vaga de interesse.</strong><p><p>&amp;nbsp;</p>");
		summary.setType("html");
		entry.setSummary(summary);

		TextType title = new TextType();
		title
				.setContent("Programador Java - Fortaleza");
		title.setType("text");

		Calendar t = Calendar.getInstance(TimeZone.getDefault());
		t.set(Calendar.DAY_OF_MONTH, 14);
		t.set(Calendar.MONTH, 0);
		t.set(Calendar.YEAR, 2010);
		t.add(Calendar.MINUTE, 1);
		entry.setUpdated(t);

		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content
				.setContent("<p><img src='http://kenai.com/attachments/wiki_images/cejug/usix.png'/>USIX S/A, empresa brasileira com foco no Mercado Segurador fecha mais uma parceria e INICIA NOVO PROCESSO SELETIVO PARA COMPOSI&Ccedil;&Atilde;O DA EQUIPE DE DESENVOLVIMENTO DA F&Aacute;BRICA DE FORTALEZA.</p><ul><li>Experi&ecirc;ncia em Desenvolvimento Java para Web;</li><li>Conhecer e utilizar algum sistema de controle de Vers&atilde;o (CVS, SVN, etc);</li><li>Conhecer e utilizar servidores de aplica&ccedil;&atilde;o (Tomcat, Jetty, etc);</li><li>Desej&aacute;vel conhecimento na constru&ccedil;&atilde;o de Web Services;</li><li>Desej&aacute;vel conhecimentos em relat&oacute;rios (IReport + Jasper, etc);</li><li>Conhecimento acerca de MVC, orienta&ccedil;&atilde;o a objetos e boas pr&aacute;ticas de programa&ccedil;&atilde;o;</li><li>Conhecimento sobre Padr&otilde;es de Projetos;</li><li>Bom conhecimento em Javascript;</li><li>Saber criar, interpretar e criticar instru&ccedil;&atilde;o DML do SQL;</li><li>Achar os diagramas da UML muito &uacute;til, saber l&ecirc;-la, interpret&aacute;-la e at&eacute; mesmo critic&aacute;-la;</li><li>Desej&aacute;vel ingl&ecirc;s t&eacute;cnico.</li></ul><p><strong>BENEF&Iacute;CIOS:</strong> A Usix possui um plano de carreiras definido e atrativo, com foco no crescimento profissional. Com uma pol&iacute;tica de valoriza&ccedil;&atilde;o dos seus colaboradores, busca sempre o melhor em benef&iacute;cios:</p><ul><li>Remunera&ccedil;&atilde;o compat&iacute;vel com o mercado (Plano de Cargos e Sal&aacute;rios definido);</li><li>Plano de Sa&uacute;de;</li><li>Plano de Previd&ecirc;ncia Privada;</li><li>Seguro de Vida;</li><li>Vale Refei&ccedil;&atilde;o;</li><li>Vale Alimenta&ccedil;&atilde;o;</li><li>Vale Combust&iacute;vel;</li><li>Plano Odontol&oacute;gico;</li><li>Conv&ecirc;nios com Farm&aacute;cias;</li><li>Conv&ecirc;nios com Universidades;</li><li>Conv&ecirc;nios com Cursos de L&iacute;nguas;</li><li>Financiamento em 100% para Certifica&ccedil;&otilde;es;</li><li>Incentivo &agrave; P&oacute;s-Gradua&ccedil;&atilde;o;</li><li>Incentivo para cursos e treinamentos;</li><li>Oportunidade de crescimento profissional.</li></ul><p>Para maiores informa&ccedil;&otilde;es e envio de curr&iacute;culos, favor entrar em contato com o e-mail: <strong>usixrecrutamento@usix.com.br</strong></span></p><p>&amp;nbsp;</p><p><strong>IMPORTANTE: Colocar no campo Assunto o nome da Vaga de interesse.</strong><p>");
		entry.setContent(content);

		TextType rights = new TextType();
		rights.setContent("2009-2010 (R) Arena PUJ");
		rights.setType("text");
		entry.setRights(rights);

		LinkType link = new LinkType();
		link
				.setHref("http://www.usix.com.br/website2/index.php?option=com_content&view=article&id=198&Itemid=90");
		link.setHreflang("pt");
		link.setRel("alternate");
		link.setTitle("Programador Java - Fortaleza");
		link.setType("text/html");
		entry.setLink(link);

		return createEntry(entry, "jobs");
	}

	public EntryType createEntry(EntryType entry, String category) {
		String authentication = getBasicAuthenticationHeader(AbstractIntegrationTest.ALLOWED_ROLES.SPONSOR);
		return getSecureArena().path("atom").path(category).header(
				AUTHENTICATION_HEADER, authentication)
				.accept("application/xml").post(EntryType.class, entry);
	}

	public EntryType catalog(String category) {
		String uri = "http://fgaucho.dyndns.org:8080/arena-http/atom/"
				+ category.toLowerCase();
		EntryType entry = new EntryType();
		TextType title = new TextType();
		title.setContent("<p><a href='" + uri + "'>" + category + "</a></p>");
		title.setType("html");
		entry.setTitle(title);

		TextType content = new TextType();
		content.setType("html");
		content.setContent("<a href='" + uri + "'>" + uri + "</a>");
		entry.setContent(content);
		entry.setSummary(content);

		TextType rights = new TextType();
		rights.setType("text");
		rights.setContent("2009-2010 (C) Arena PUJ");
		entry.setRights(rights);

		c.add(Calendar.MINUTE, 1);
		entry.setUpdated(c);

		LinkType link = new LinkType();
		link.setHref(uri);
		link.setHreflang("pt");
		link.setRel("self");
		// link.setType("application/atom+xml");
		entry.setLink(link);

		return createEntry(entry, "catalog");
	}
}
