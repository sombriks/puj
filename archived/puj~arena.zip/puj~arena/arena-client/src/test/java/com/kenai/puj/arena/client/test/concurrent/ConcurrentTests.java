package com.kenai.puj.arena.client.test.concurrent;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.notification.Failure;
import org.junit.runners.Suite;
import org.junit.runners.model.InitializationError;

public class ConcurrentTests {
	private transient static final DefaultJUnitNotifier notifier = new DefaultJUnitNotifier();
	private transient static final int NUMBER_OF_CONCURRENT_CLIENTS = 10;

	@Test
	public void concurrent() {

		Suite.SuiteClasses annos = ConcurrentTestSuite.class
				.getAnnotation(Suite.SuiteClasses.class);
		List<Failure> failures = runAll(annos);

		if (!failures.isEmpty()) {
			Assert.fail(failures.get(0).getTrace());
		} else {
			Assert.assertTrue(failures.isEmpty());
		}
	}

	/** Synchronization flag. */
	private static final Object lock = new Object();

	private List<Failure> runAll(Suite.SuiteClasses annos) {

		try {
			synchronized (lock) {
				Class<?>[] testSuite = annos.value();
				Thread[] processes = new Thread[testSuite.length
						* NUMBER_OF_CONCURRENT_CLIENTS];

				for (int i = 0; i < testSuite.length; i++) {
					for (int j = 0; j < NUMBER_OF_CONCURRENT_CLIENTS; j++) {
						processes[i * NUMBER_OF_CONCURRENT_CLIENTS + j] = new Thread(
								new JUnitRunnable(testSuite[i], notifier));
						notifier.incrementThreadsCounter();
					}
				}

				for (Thread t : processes) {
					t.start();
				}

				// TODO: include a decent timer here instead of this blatant
				// counter.
				while (notifier.getThreadCounter() > 0) {
					Thread.yield();
				}
				return notifier.getFailures();
			}
		} catch (InitializationError e) {
			return null;
		}
	}
}
