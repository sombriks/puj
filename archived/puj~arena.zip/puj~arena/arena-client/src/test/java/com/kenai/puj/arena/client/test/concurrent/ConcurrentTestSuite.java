package com.kenai.puj.arena.client.test.concurrent;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.kenai.puj.arena.client.test.AdvertisementTestCase;
import com.kenai.puj.arena.client.test.AtomFeedIntegrationTest;
import com.kenai.puj.arena.client.test.CompetitionTestCase;
import com.kenai.puj.arena.client.test.InstitutionIntegrationTest;

@RunWith(Suite.class)
@Suite.SuiteClasses( { AtomFeedIntegrationTest.class,
		AdvertisementTestCase.class, CompetitionTestCase.class,
		InstitutionIntegrationTest.class })
// , UserManagementTestCase.class })
public class ConcurrentTestSuite {

}
