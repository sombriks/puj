package com.kenai.puj.arena.client.test;

import java.util.Collection;

import javax.ws.rs.core.MediaType;

import org.junit.Assert;
import org.junit.Test;

import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.UniformInterfaceException;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class InstitutionIntegrationTest extends AbstractIntegrationTest {

	@Test
	public void roundtrip() {
		PujInstitutionEntity institution = createInstitution();
		Assert.assertNotNull(institution);
		PujInstitutionEntity read = readInstitution(institution.getAcronym());
		Assert.assertNotNull(read);

		Assert.assertEquals(institution.getVersion(), read.getVersion());
		Assert.assertEquals(institution.getAcronym(), read.getAcronym());

		deleteInstitution(institution.getAcronym());

		boolean stillExists = true;
		try {
			readInstitution(institution.getAcronym());
		} catch (UniformInterfaceException noContentException) {
			stillExists = false;
		}
		Assert.assertFalse(
				"A deleted institution remains available in the service interface (acronym='"
						+ institution.getAcronym() + "').", stillExists);
	}

	private void deleteInstitution(String acronym) {
		arena.path("institution").path(acronym).delete();
	}

	public PujInstitutionEntity createInstitution() {
		String institutionName = "_" + counter++;
		return arena.path("institution").path(institutionName).accept(
				MediaType.APPLICATION_JSON).post(PujInstitutionEntity.class,
				null);
	}

	public PujInstitutionEntity readInstitution(String acronym) {
		return arena.path("institution").path(acronym).accept(
				MediaType.APPLICATION_JSON).get(PujInstitutionEntity.class);
	}

	public Collection<PujInstitutionEntity> readAllInstitutions() {
		return arena.path("institution").get(
				new GenericType<Collection<PujInstitutionEntity>>() {
				});
	}
}
