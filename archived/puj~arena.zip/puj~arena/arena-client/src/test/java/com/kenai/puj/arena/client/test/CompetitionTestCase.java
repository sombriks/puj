package com.kenai.puj.arena.client.test;

import javax.ws.rs.core.MediaType;

import org.junit.Assert;
import org.junit.Test;

import com.kenai.puj.arena.model.entity.PujCompetitionEntity;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class CompetitionTestCase extends AbstractIntegrationTest {
	private void deleteCompetition(String competitionName) {
		arena.path("competition").path(competitionName).delete();
	}

	@Test
	public void roundtrip() {
		PujCompetitionEntity competition = createCompetition();
		Assert.assertNotNull(competition);
		Assert
				.assertEquals(competition, readCompetition(competition
						.getName()));
		deleteCompetition(competition.getName());
	}

	public PujCompetitionEntity createCompetition() {
		String competitionName = "_" + counter++;
		return arena.path("competition").path(competitionName).accept(
				MediaType.APPLICATION_JSON).post(PujCompetitionEntity.class,
				null);
	}

	public PujCompetitionEntity readCompetition(String name) {
		return arena.path("competition").path(name).accept(
				MediaType.APPLICATION_JSON).get(PujCompetitionEntity.class);
	}
}
