package com.kenai.puj.arena.client.test;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status.Family;

import org.junit.Assert;
import org.junit.Test;

import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;
import com.kenai.puj.arena.model.entity.PujInstitutionEntity;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.representation.Form;

/**
 * Integration tests for the PujUserEntity resources.
 */
public class AdvertisementTestCase extends AbstractIntegrationTest {
	private void deleteAdvertisement(String acronym) {
		arena.path("ads").path(acronym).delete();
	}

	private PujInstitutionEntity institution = null;

	@Test
	public void roundtrip() {
		InstitutionIntegrationTest inst = new InstitutionIntegrationTest();
		institution = inst.createInstitution();
		Assert.assertNotNull(institution);
		String url = "http://cejug.silveiraneto.net/";
		String img = "http://cejug.silveiraneto.net/wp-content/themes/atahualpa/images/logo.png";
		ClientResponse response = addNewAdvertisement(institution.getAcronym(),
				url, img);
		Status registrationStatus = response.getClientResponseStatus();
		Assert.assertTrue(registrationStatus.getReasonPhrase(),
				Family.SUCCESSFUL.equals(registrationStatus.getFamily()));

		PujAdvertisementEntity read = readAdvertisement(institution
				.getAcronym());
		Assert.assertEquals(read.getThumbnail(), img);

		Assert.assertEquals(read.getUrl(), url);
		// Assert.assertEquals(read.getInstitution().getAcronym(),
		// institution.getAcronym());

		deleteAdvertisement(institution.getAcronym());

	}

	public ClientResponse addNewAdvertisement(String acronym, String url,
			String img) {
		Form formData = new Form();
		formData.add("acronym", acronym);
		formData.add("url", url);
		formData.add("img", img);

		return arena.path("ads").type("application/x-www-form-urlencoded")
				.post(ClientResponse.class, formData);
	}

	public PujAdvertisementEntity readAdvertisement(String acronym) {
		return arena.path("ads").path(acronym)
				.accept(MediaType.APPLICATION_XML).get(
						PujAdvertisementEntity.class);
	}
}
