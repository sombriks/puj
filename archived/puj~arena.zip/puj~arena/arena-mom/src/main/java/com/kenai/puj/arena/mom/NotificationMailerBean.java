package com.kenai.puj.arena.mom;

import java.text.MessageFormat;
import java.util.Properties;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.model.entity.utils.JmsConstants;

/**
 * The goal of this bean is to send emails with the status of an operation or a
 * customer resource (like account activation notification). It depends on a
 * Mail API resource provided by the Java EE container.
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "endpointExceptionRedeliveryAttempts", propertyValue = "3") }, mappedName = JmsConstants.PUJ_NOTIFICATION_QUEUE)
public class NotificationMailerBean implements MessageListener {
	/**
	 * JavaMail resource is injected by the container and have everything we
	 * need to send/receive emails.
	 * 
	 * @see <a href='http://docs.sun.com/app/docs/doc/820-4335/ablkr?a=view'>
	 *      Glassfish instructions about Configuring JavaMail Resources</a>
	 */
	@Resource(name = JmsConstants.PUJ_REGISTRATION_MAIL)
	private transient Session notificationSession;

	/**
	 * the global log manager, used to allow third party services to override
	 * the default logger.
	 */
	private final static Logger logger = Logger
			.getLogger(NotificationMailerBean.class.getName());

	// @EJB private URLObfuscator urlObfuscator;

	/**
	 * Each time a message arrives in the Notification queue, this listener will
	 * send an email to the addressee. The prime purpose of this bean is to
	 * notify new customer about the link they should click in order to activate
	 * their accounts, but in the future it can be expanded for other uses.
	 * 
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message message) {
		if (message instanceof MapMessage) {
			MapMessage registration = (MapMessage) message;
			try {
				String login = registration
						.getStringProperty(RegistrationConstants.LOGIN.value());
				String email = registration
						.getStringProperty(RegistrationConstants.EMAIL.value());

				String confirmationUrl = registration
						.getStringProperty(RegistrationConstants.CONFIRMATION_URL
								.value());

				String subject = registration
						.getStringProperty(RegistrationConstants.REGISTRATION_SUBJECT
								.value());

				String name = registration
						.getStringProperty(RegistrationConstants.NAME.value());

				String content = MessageFormat
						.format(
								registration
										.getStringProperty(RegistrationConstants.REGISTRATION_MSG
												.value()), name,
								confirmationUrl, name, login);

				MimeMessage msg = new MimeMessage(notificationSession);
				// msg.setFrom(new InternetAddress(from));

				InternetAddress[] address = { new InternetAddress(email) };
				msg.setRecipients(javax.mail.Message.RecipientType.TO, address);
				msg.setSubject(subject);
				msg.setSentDate(new java.util.Date());
				msg.setContent(content,
						RegistrationConstants.MAIL_FORMAT_TEXT_PLAIN.value());

				Properties sessionProps = notificationSession.getProperties();
				String username = sessionProps
						.getProperty(RegistrationConstants.MAIL_SMTP_USER
								.value());
				String password = sessionProps
						.getProperty(RegistrationConstants.MAIL_SMTP_PASSWORD
								.value());
				String host = sessionProps
						.getProperty(RegistrationConstants.MAIL_HOST.value());
				Transport t = notificationSession.getTransport();
				try {
					t.connect(host, username, password);
					t.sendMessage(msg, msg.getAllRecipients());
				} finally {
					t.close();
				}
				logger.info("Arena-PUJ notification email sent to " + login);
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchProviderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			logger.severe("Invalid message type, expected " + MapMessage.class
					+ " but received " + message.getClass());
		}

	}
}
