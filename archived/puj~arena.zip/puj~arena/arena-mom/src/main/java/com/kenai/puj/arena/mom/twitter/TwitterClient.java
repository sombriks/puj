package com.kenai.puj.arena.mom.twitter;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.logging.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * Simple Jersey ({@link http://jersey.dev.java.net}) based command line Twitter
 * ({@link http://twitter.com}) client application. Needs Java 1.6!
 * 
 * @author Jakub.Podlesak@Sun.COM, Craig.McClanahan@Sun.COM
 */
public class TwitterClient {
	private static final String AUTHENTICATION_HEADER = "Authorization";
	private static final String TWITTER_URI = "https://twitter.com";
	private final String authentication;
	private final WebResource wr;

	private static final Logger LOGGER = Logger.getLogger(TwitterClient.class
			.getName());

	/**
	 * Creates a new client instance with given user credentials
	 * 
	 * @param username
	 * @param password
	 */
	public TwitterClient(String username, String password) {
		authentication = "Basic " + encodeCredentialsBasic(username, password);
		ClientConfig config = new DefaultClientConfig();

		SSLContext ctx = null;

		try {
			ctx = SSLContext.getInstance("SSL");
			ctx.init(null, mytm, null);
		} catch (NoSuchAlgorithmException error) {
			LOGGER.warning("Twitter SSL connection failed: "
					+ error.getMessage());
		} catch (KeyManagementException error) {
			LOGGER.warning("Twitter SSL connection failed: "
					+ error.getMessage());
		}

		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
				new HTTPSProperties(hv, ctx));
		config.getClasses().add(JAXBContextResolver.class);

		Client client = Client.create(config);
		wr = client.resource(TWITTER_URI);
	}

	/**
	 * Posts a new message on twitter web site
	 * 
	 * @param message
	 *            to be sent
	 * @param notification
	 *            a list of other twitter user to include in the message in the
	 *            format @twitterUser
	 */
	public void postUpdate(String message, Collection<String> notification) {
		MultivaluedMap<String, String> fp = new MultivaluedMapImpl();
		fp.add("status", message);

		wr.path("statuses/update.xml").header(AUTHENTICATION_HEADER,
				authentication)
				.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE).accept(
						MediaType.APPLICATION_XML_TYPE).post(
						TwitterStatusBean.class, fp);
	}

	/**
	 * Main entry point for the client app
	 * 
	 * @param args
	 *            could specify twitter username and password
	 * @throws java.io.IOException
	 */
	public static void main(String[] args) throws IOException {
		String username = "pujcejug";
		String password = "";

		final TwitterClient c = new TwitterClient(username, password);
		c.postUpdate("teste", null);
	}

	/**
	 * <p>
	 * Convenience string for Base 64 encoding.
	 * </p>
	 */
	private static final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "abcdefghijklmnopqrstuvwxyz" + "0123456789+/";

	/**
	 * <p>
	 * Encode the specified credentials into a String as required by HTTP Basic
	 * Authentication (<a href="http://www.ietf.org/rfc/rfc2617.txt">RFC
	 * 2617</a>).
	 * </p>
	 * 
	 * @param username
	 *            Username to be encoded
	 * @param password
	 *            Password to be encoded
	 */
	public String encodeCredentialsBasic(String username, String password) {

		String encode = username + ":" + password;
		int paddingCount = (3 - (encode.length() % 3)) % 3;
		encode += "\0\0".substring(0, paddingCount);
		StringBuilder encoded = new StringBuilder();
		for (int i = 0; i < encode.length(); i += 3) {
			int j = (encode.charAt(i) << 16) + (encode.charAt(i + 1) << 8)
					+ encode.charAt(i + 2);
			encoded.append(BASE64_CHARS.charAt((j >> 18) & 0x3f));
			encoded.append(BASE64_CHARS.charAt((j >> 12) & 0x3f));
			encoded.append(BASE64_CHARS.charAt((j >> 6) & 0x3f));
			encoded.append(BASE64_CHARS.charAt(j & 0x3f));
		}

		return encoded.toString();
	}

	X509TrustManager xtm = new X509TrustManager() {
		@Override
		public void checkClientTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
		}

		@Override
		public void checkServerTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
		}
	};
	TrustManager mytm[] = { xtm };
	HostnameVerifier hv = new HostnameVerifier() {

		@Override
		public boolean verify(String hostname, SSLSession sslSession) {
			return true;
		}
	};
}
