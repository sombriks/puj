/*
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://jersey.dev.java.net/CDDL+GPL.html
 * or jersey/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at jersey/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package com.kenai.puj.arena.mom.twitter;

import java.net.URI;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * JAXB bean representing a twitter user entity
 * 
 * @author Jakub.Podlesak@Sun.COM
 */
@XmlRootElement(name = "user")
public class TwitterUserBean {
	public long id;
	public String name;
	@XmlElement(name = "screen_name")
	public String screenName;
	public String location;
	public String description;
	@XmlElement(name = "profile_image_url")
	public URI profileImageUrl;
	public URI url;
	@XmlElement(name = "protected")
	public boolean protectedFlag;
	@XmlElement(name = "followers_count")
	public int followersCount;

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final TwitterUserBean other = (TwitterUserBean) obj;
		if (this.id != other.id) {
			return false;
		}
		if ((this.name == null) ? (other.name != null) : !this.name
				.equals(other.name)) {
			return false;
		}
		if ((this.screenName == null) ? (other.screenName != null)
				: !this.screenName.equals(other.screenName)) {
			return false;
		}
		if ((this.location == null) ? (other.location != null) : !this.location
				.equals(other.location)) {
			return false;
		}
		if ((this.description == null) ? (other.description != null)
				: !this.description.equals(other.description)) {
			return false;
		}
		if (this.profileImageUrl != other.profileImageUrl
				&& (this.profileImageUrl == null || !this.profileImageUrl
						.equals(other.profileImageUrl))) {
			return false;
		}
		if (this.url != other.url
				&& (this.url == null || !this.url.equals(other.url))) {
			return false;
		}
		if (this.protectedFlag != other.protectedFlag) {
			return false;
		}
		if (this.followersCount != other.followersCount) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		int hash = 3;
		hash = 79 * hash + (int) (this.id ^ (this.id >>> 32));
		hash = 79 * hash + (this.name != null ? this.name.hashCode() : 0);
		hash = 79 * hash
				+ (this.screenName != null ? this.screenName.hashCode() : 0);
		hash = 79 * hash
				+ (this.location != null ? this.location.hashCode() : 0);
		hash = 79 * hash
				+ (this.description != null ? this.description.hashCode() : 0);
		hash = 79
				* hash
				+ (this.profileImageUrl != null ? this.profileImageUrl
						.hashCode() : 0);
		hash = 79 * hash + (this.url != null ? this.url.hashCode() : 0);
		hash = 79 * hash + (this.protectedFlag ? 1 : 0);
		hash = 79 * hash + this.followersCount;
		return hash;
	}
}
