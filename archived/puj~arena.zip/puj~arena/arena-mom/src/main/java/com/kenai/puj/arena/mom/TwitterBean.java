package com.kenai.puj.arena.mom;

import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import com.kenai.puj.arena.model.entity.facade.RegistrationConstants;
import com.kenai.puj.arena.model.entity.utils.JmsConstants;
import com.kenai.puj.arena.mom.twitter.TwitterClient;

/**
 * The goal of this bean is to send emails with the status of an operation or a
 * customer resource (like account activation notification). It depends on a
 * Mail API resource provided by the Java EE container.
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
		@ActivationConfigProperty(propertyName = "endpointExceptionRedeliveryAttempts", propertyValue = "3") }, mappedName = JmsConstants.PUJ_NOTIFICATION_TOPIC)
public class TwitterBean implements MessageListener {
	/**
	 * the global log manager, used to allow third party services to override
	 * the default logger.
	 */
	private final static Logger LOGGER = Logger.getLogger(TwitterBean.class
			.getName());

	/**
	 * Each time a message arrives in the Notification queue, this listener will
	 * send an email to the addressee. The prime purpose of this bean is to
	 * notify new customer about the link they should click in order to activate
	 * their accounts, but in the future it can be expanded for other uses.
	 * 
	 * @see MessageListener#onMessage(Message)
	 */
	@SuppressWarnings("unchecked")
	public void onMessage(Message message) {
		if (message instanceof MapMessage) {
			MapMessage tweets = (MapMessage) message;
			try {
				String update = tweets
						.getStringProperty(RegistrationConstants.TWITTER_MSG
								.value());
				if (update == null) {
					return;
				}
				String username = tweets
						.getStringProperty(RegistrationConstants.TWITTER_USER
								.value());
				if (username == null || username.trim().length() == 0) {
					return;
				}
				String password = tweets
						.getStringProperty(RegistrationConstants.TWITTER_PASSWORD
								.value());

				if (password == null || password.trim().length() == 0) {
					return;
				}

				Object notificationObj = tweets
						.getObjectProperty(RegistrationConstants.TWITTER_NOTIFICATION
								.value());

				Collection<String> notification = new ArrayList<String>();

				if (notificationObj != null
						&& notificationObj.getClass().isAssignableFrom(
								notification.getClass())) {
					notification.addAll((Collection<String>) notificationObj);
				}

				TwitterClient twitter = new TwitterClient(username, password);
				twitter.postUpdate(update, notification);

			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage());
			}
		} else {
			LOGGER.severe("Invalid message type, expected " + MapMessage.class
					+ " but received " + message.getClass());
		}

	}
}
