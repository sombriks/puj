/*
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://jersey.dev.java.net/CDDL+GPL.html
 * or jersey/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at jersey/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package com.kenai.puj.arena.mom.twitter;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * JAXB bean representing a twitter status update entity
 * 
 * @author Jakub.Podlesak@Sun.COM
 */
@XmlRootElement(name = "status")
public class TwitterStatusBean {
	@XmlElement(name = "created_at")
	public String createdAt;
	public long id;
	public String text;
	public String source;
	public boolean truncated;
	@XmlElement(name = "in_reply_to_status_id")
	public String inReplyToStatusId;
	@XmlElement(name = "in_reply_to_user_id")
	public String inReplyToUserId;
	public boolean favorited;
	@XmlElement(name = "in_reply_to_screen_name")
	public String inReplyToScreenName;
	public TwitterUserBean user;

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final TwitterStatusBean other = (TwitterStatusBean) obj;
		if ((this.createdAt == null) ? (other.createdAt != null)
				: !this.createdAt.equals(other.createdAt)) {
			return false;
		}
		if ((this.text == null) ? (other.text != null) : !this.text
				.equals(other.text)) {
			return false;
		}
		if ((this.source == null) ? (other.source != null) : !this.source
				.equals(other.source)) {
			return false;
		}
		if (this.truncated != other.truncated) {
			return false;
		}
		if ((this.inReplyToStatusId == null) ? (other.inReplyToStatusId != null)
				: !this.inReplyToStatusId.equals(other.inReplyToStatusId)) {
			return false;
		}
		if ((this.inReplyToUserId == null) ? (other.inReplyToUserId != null)
				: !this.inReplyToUserId.equals(other.inReplyToUserId)) {
			return false;
		}
		if (this.favorited != other.favorited) {
			return false;
		}
		if ((this.inReplyToScreenName == null) ? (other.inReplyToScreenName != null)
				: !this.inReplyToScreenName.equals(other.inReplyToScreenName)) {
			return false;
		}
		if (this.user != other.user
				&& (this.user == null || !this.user.equals(other.user))) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		int hash = 5;
		hash = 97 * hash
				+ (this.createdAt != null ? this.createdAt.hashCode() : 0);
		hash = 97 * hash + (this.text != null ? this.text.hashCode() : 0);
		hash = 97 * hash + (this.source != null ? this.source.hashCode() : 0);
		hash = 97 * hash + (this.truncated ? 1 : 0);
		hash = 97
				* hash
				+ (this.inReplyToStatusId != null ? this.inReplyToStatusId
						.hashCode() : 0);
		hash = 97
				* hash
				+ (this.inReplyToUserId != null ? this.inReplyToUserId
						.hashCode() : 0);
		hash = 97 * hash + (this.favorited ? 1 : 0);
		hash = 97
				* hash
				+ (this.inReplyToScreenName != null ? this.inReplyToScreenName
						.hashCode() : 0);
		hash = 97 * hash + (this.user != null ? this.user.hashCode() : 0);
		return hash;
	}
}
