package com.kenai.puj.arena.jsf20.bean;

import java.io.Serializable;
import java.util.Collection;

import javax.ejb.EJB;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

import com.kenai.puj.arena.model.entity.PujAbstractEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity;
import com.kenai.puj.arena.model.entity.PujCompetitionEntity.CompetitionStatus;
import com.kenai.puj.arena.model.entity.facade.EntityFacadeConstants;
import com.kenai.puj.arena.model.entity.facade.PujCompetitionFacade;

@Named("competitions")
@RequestScoped
public class CompetitionBean implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@EJB
	private transient PujCompetitionFacade competitionFacade;

	public String getModuleName() {
		return "arena-jsf20";
	}

	public Collection<PujCompetitionEntity> getCompetitions() {
		competitionFacade.findByStatus(CompetitionStatus.CALL_FOR_PAPERS, 1);
		return competitionFacade.readAll(PujCompetitionEntity.class, 0,
				EntityFacadeConstants.PAGINATION_MAX_SIZE);
	}
}