package com.kenai.puj.arena.jsf20.bean;

import java.io.Serializable;

import javax.faces.bean.RequestScoped;
import javax.inject.Named;

import com.kenai.puj.arena.model.entity.PujAbstractEntity;

@Named("headlines")
@RequestScoped
public class HeadlineBean implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}