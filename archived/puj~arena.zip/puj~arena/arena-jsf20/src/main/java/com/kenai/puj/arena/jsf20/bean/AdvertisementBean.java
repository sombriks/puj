package com.kenai.puj.arena.jsf20.bean;

import java.io.Serializable;
import java.util.Collection;

import javax.ejb.EJB;
import javax.faces.bean.ApplicationScoped;
import javax.inject.Named;

import com.kenai.puj.arena.model.entity.PujAbstractEntity;
import com.kenai.puj.arena.model.entity.PujAdvertisementEntity;
import com.kenai.puj.arena.model.entity.facade.PujAdvertisementFacade;

@Named("advertisements")
@ApplicationScoped
public class AdvertisementBean implements Serializable {
	private static final long serialVersionUID = PujAbstractEntity.serialVersionUID;

	@EJB
	private transient PujAdvertisementFacade adsFacade;

	public String getModuleName() {
		return "arena-jsf20";
	}

	public Collection<PujAdvertisementEntity> getPujAds() {
		return adsFacade.getAdvertisement(null, null, 4);
	}
}