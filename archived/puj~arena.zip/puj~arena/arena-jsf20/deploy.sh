#!/bin/bash
echo
echo "-------- Deploying JSF 2.0 Web GUI to Server $GF_VERSION"
asadmin --user=admin deploy --force=true target/arena-jsf20*.war
echo
