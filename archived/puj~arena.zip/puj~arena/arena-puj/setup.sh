#!/bin/bash

if [ -n "$1" -a -f $1 ]; then
    . $1;export PASS_FILE="$1";
    if [ -n "$2" -a "$2" = "/clean" ]; then
        export CLEAN="/clean"
    fi
else
    . $HOME/.passwords;export PASS_FILE="$HOME/.passwords";
fi

GF_VERSION=$(asadmin version -t)

echo "$GF_VERSION" | grep -q 'v2.'
if [ $? -eq 0 ] ; then
    echo "Sorry, you need to install and configure the Glassfish V3 before to run this project.";
    echo "You can get the newest Glassfish version here: http://download.java.net/glassfish/v3/promoted/";
    exit 1;
else
    #echo "Shell Script for Glassfish v3.x"
    echo
    echo "-------- JDBC Connection Pool jdbc/arenaPool"
    asadmin --user=$ASADMIN_USER delete-jdbc-connection-pool --cascade=true jdbc/arenaPool   
    if [ -z "$CLEAN" ]; then jdbc/arenaPool
        asadmin create-jdbc-connection-pool --datasourceclassname com.mysql.jdbc.jdbc2.optional.MysqlDataSource --restype javax.sql.ConnectionPoolDataSource --property "User=$MYSQL_USER:Password=$MYSQL_PASSWORD:URL=$DB_URL" jdbc/arenaPool
    fi
    echo
    echo "-------- JDBC Data Source jdbc/arena"
    asadmin --user=$ASADMIN_USER delete-jdbc-resource jdbc/arena
    if [ -z "$CLEAN" ]; then
        asadmin --user=$ASADMIN_USER create-jdbc-resource --connectionpoolid jdbc/arenaPool jdbc/arena
    fi
    echo
    echo "-------- JDBC Realm arena-realm"
    asadmin delete-auth-realm arena-realm
    if [ -z "$CLEAN" ]; then
        asadmin create-auth-realm --classname=com.sun.enterprise.security.auth.realm.jdbc.JDBCRealm --property group-table=PUJ_AUTH_GROUPTABLE:user-table=PUJ_AUTH_USERTABLE:user-name-column=LOGIN:password-column=PASSWORD:group-name-column=GROUPID:jaas-context=jdbcRealm:datasource-jndi=jdbc/arena:digest-algorithm=MD5:charset=utf8 arena-realm
    fi
    echo
    echo "-------- JMS Connection Factory jms/PujNotificationFactory"
    asadmin --passwordfile=$PASS_FILE delete-jms-resource jms/PujNotificationFactory
    if [ -z "$CLEAN" ]; then
        asadmin create-jms-resource --restype=javax.jms.QueueConnectionFactory --description="Arena PUJ JMS Notification Connection Factory." jms/PujNotificationFactory
    fi
    echo
    echo "-------- JMS Queue jms/PujNotification"
    asadmin --passwordfile=$PASS_FILE delete-jms-resource jms/PujNotification
    if [ -z "$CLEAN" ]; then
        asadmin create-jms-resource --restype=javax.jms.Queue --description="Queue used to notify PUJ users about PUJ events (like registration and grades)." jms/PujNotification
    fi

    echo
    echo "-------- JMS Connection Factory jms/PujTopicFactory"
    asadmin --passwordfile=$PASS_FILE delete-jms-resource jms/PujTopicFactory
    if [ -z "$CLEAN" ]; then
        asadmin create-jms-resource --restype=javax.jms.TopicConnectionFactory --description="Arena PUJ JMS Topic Connection Factory." jms/PujTopicFactory
    fi
    echo
    echo "-------- JMS Queue jms/PujNotification"
    asadmin --passwordfile=$PASS_FILE delete-jms-resource jms/PujTopic
    if [ -z "$CLEAN" ]; then
        asadmin create-jms-resource --restype=javax.jms.Topic --description="Queue used to notify PUJ users about PUJ events (like registration and grades)." jms/PujTopic
    fi

    echo
    echo "-------- JavaMail mail/arena"
    asadmin --passwordfile=$PASS_FILE delete-javamail-resource mail/arena
    if [ -z "$CLEAN" ]; then
        asadmin --interactive=false create-javamail-resource --mailhost=$MAIL_HOST --mailuser=$MAIL_USER --fromaddress=$MAIL_FROM --enabled=true --description="e-Mail account used to confirm the registration of the Arena PUJ users" --storeprotocol=imap --storeprotocolclass=com.sun.mail.imap.IMAPStore --transprotocol smtp --transprotocolclass com.sun.mail.smtp.SMTPSSLTransport --property mail-smtp.user=$MAIL_SMTP_USER:mail-smtp.port=465:mail-smtp.password=$MAIL_SMTP_PASSWORD:mail-smtp.auth=true:mail-smtp.socketFactory.fallback=false:mail-smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory:mail-smtp.socketFactory.port=$MAIL_SMTP_PORT:mail-smtp.starttls.enable=true mail/arena
    fi

    
    echo
    mysql -v -u$MYSQL_USER -hlocalhost -P3306 -p$MYSQL_PASSWORD -e "drop database IF EXISTS arena;"
    mysql -v -u$MYSQL_USER -hlocalhost -P3306 -p$MYSQL_PASSWORD -e "create database IF NOT EXISTS  arena;"

    echo
    echo "-------- Deploying to Server $GF_VERSION"
    asadmin --user $ASADMIN_USER deploy --force=true --name arena-puj target/arena-puj.ear
fi

echo
echo loading the test data in the database 'arena' 
mysql -u$MYSQL_USER -hlocalhost -P3306 -Darena -p$MYSQL_PASSWORD < ../arena-model/src/main/resources/test_data.sql
echo
